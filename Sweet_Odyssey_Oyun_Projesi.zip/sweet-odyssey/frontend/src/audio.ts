type Sound = 'tap' | 'swap' | 'clear' | 'power' | 'win' | 'lose';

/** Tiny, original synthesizer; no remote music or audio downloads. */
class Soundscape {
  private context: AudioContext | null = null;
  private sound = true;
  private music = false;
  private timer: ReturnType<typeof setInterval> | null = null;
  private noteIndex = 0;

  unlock() {
    try {
      if (!this.context) this.context = new AudioContext();
      if (this.context.state === 'suspended') void this.context.resume();
      this.updateMusic();
    } catch {
      /* Audio is optional on browsers without Web Audio. */
    }
  }

  setSettings(sound: boolean, music: boolean) {
    this.sound = sound;
    this.music = music;
    this.updateMusic();
  }

  private tone(
    frequency: number,
    delay = 0,
    duration = 0.2,
    volume = 0.035,
    type: OscillatorType = 'sine',
  ) {
    const ctx = this.context;
    if (!ctx || ctx.state !== 'running') return;
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    const start = ctx.currentTime + delay;
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, start);
    gain.gain.setValueAtTime(0, start);
    gain.gain.linearRampToValueAtTime(volume, start + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    oscillator.connect(gain);
    gain.connect(ctx.destination);
    oscillator.start(start);
    oscillator.stop(start + duration + 0.03);
  }

  play(kind: Sound) {
    if (!this.sound) return;
    const melodies: Record<Sound, number[]> = {
      tap: [523.25],
      swap: [392, 523.25],
      clear: [659.25, 783.99],
      power: [392, 523.25, 659.25, 1046.5],
      win: [523.25, 659.25, 783.99, 1046.5, 1318.5],
      lose: [392, 349.23, 293.66],
    };
    melodies[kind].forEach((frequency, i) =>
      this.tone(frequency, i * 0.065, kind === 'win' ? 0.42 : 0.18),
    );
  }

  private updateMusic() {
    if ((!this.music || !this.context) && this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (this.music && this.context && !this.timer) {
      const melody = [
        523.25, 659.25, 783.99, 659.25, 587.33, 698.46, 880, 698.46, 493.88, 587.33, 783.99, 587.33,
        523.25, 659.25, 1046.5, 783.99,
      ];
      this.timer = setInterval(() => {
        if (document.hidden) return;
        const frequency = melody[this.noteIndex++ % melody.length];
        this.tone(frequency, 0, 1.15, 0.013);
        if (this.noteIndex % 4 === 1) this.tone(frequency / 2, 0, 1.75, 0.012, 'triangle');
      }, 470);
    }
  }
}

export const soundscape = new Soundscape();
