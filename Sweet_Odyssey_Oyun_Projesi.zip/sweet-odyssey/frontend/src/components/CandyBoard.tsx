import { useEffect, useRef } from 'react';
import Phaser from 'phaser';
import { CandyScene } from '../game/CandyScene';
import type { Action, GameState, Position } from '../game/engine';

export const CANDY_NAMES = [
  'Ahududu kalbi',
  'Turkuaz kristal',
  'Altın damla',
  'Lavanta makaronu',
  'Mercan şekeri',
  'Nane çiçeği',
];

type Props = {
  attemptKey: number;
  state: GameState;
  locked: boolean;
  hammer: boolean;
  reduced: boolean;
  onAction: (action: Action) => void;
  onScene: (scene: CandyScene | null) => void;
  onClear: () => void;
};

export function CandyBoard(props: Props) {
  const host = useRef<HTMLDivElement>(null);
  const current = useRef(props);
  current.current = props;
  const sceneRef = useRef<CandyScene | null>(null);
  const keyboard = useRef<Position>([0, 0]);

  useEffect(() => {
    if (!host.current) return;
    const scene = new CandyScene({
      state: current.current.state,
      onAction: (action) => current.current.onAction(action),
      isLocked: () => current.current.locked,
      hammerMode: () => current.current.hammer,
      reducedMotion: () => current.current.reduced,
      onClear: () => current.current.onClear(),
      onReady: (ready) => {
        sceneRef.current = ready;
        current.current.onScene(ready);
      },
    });
    const game = new Phaser.Game({
      type: Phaser.AUTO,
      width: 640,
      height: 640,
      parent: host.current,
      transparent: true,
      antialias: true,
      roundPixels: false,
      audio: { noAudio: true },
      scene,
      scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
      input: { activePointers: 2 },
      render: { powerPreference: 'low-power' },
    });
    return () => {
      current.current.onScene(null);
      sceneRef.current = null;
      game.destroy(true);
    };
  }, [props.attemptKey]);

  const state = props.state;
  const boardDescription = state.board
    .map(
      (row, r) =>
        `Satır ${r + 1}: ${row.map((candy) => (candy ? CANDY_NAMES[candy.color] : 'boş')).join(', ')}`,
    )
    .join('. ');

  return (
    <div className={`board-shell ${props.hammer ? 'hammer-active' : ''}`}>
      <span className="board-rivet rivet-tl" />
      <span className="board-rivet rivet-tr" />
      <span className="board-rivet rivet-bl" />
      <span className="board-rivet rivet-br" />
      <div
        ref={host}
        className="phaser-board"
        data-testid="game-board"
        role="application"
        tabIndex={0}
        aria-label="Şeker tahtası. Ok tuşlarıyla hücre seçin, Enter ile bir şekeri ve sonra komşusunu seçin. Fareyle tıklayabilir veya kaydırabilirsiniz."
        aria-describedby="board-accessible-state"
        onFocus={() => sceneRef.current?.setKeyboardCursor(keyboard.current)}
        onBlur={() => sceneRef.current?.setKeyboardCursor(null)}
        onKeyDown={(event) => {
          if (props.locked) return;
          const [r, c] = keyboard.current;
          const directions: Record<string, Position> = {
            ArrowUp: [r - 1, c],
            ArrowDown: [r + 1, c],
            ArrowLeft: [r, c - 1],
            ArrowRight: [r, c + 1],
          };
          if (directions[event.key]) {
            event.preventDefault();
            const [nr, nc] = directions[event.key];
            keyboard.current = [
              Math.max(0, Math.min(state.board.length - 1, nr)),
              Math.max(0, Math.min(state.board[0].length - 1, nc)),
            ];
            sceneRef.current?.setKeyboardCursor(keyboard.current);
          } else if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            sceneRef.current?.selectCell(keyboard.current);
          } else if (event.key === 'Escape') {
            sceneRef.current?.clearSelection();
          }
        }}
      />
      <p id="board-accessible-state" className="sr-only">
        {boardDescription}
      </p>
    </div>
  );
}
