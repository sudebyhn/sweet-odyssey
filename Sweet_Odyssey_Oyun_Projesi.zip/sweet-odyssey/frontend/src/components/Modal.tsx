import { useEffect, useId, useRef, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

type Props = {
  title: string;
  onClose?: () => void;
  children: ReactNode;
  className?: string;
  testId?: string;
  reduced?: boolean;
};

let openDialogs = 0;
let originalOverflow = '';

export function Modal({
  title,
  onClose,
  children,
  className = '',
  testId,
  reduced = false,
}: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const id = useId();
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const dialog = ref.current;
    const focusables = () =>
      Array.from(
        dialog?.querySelectorAll<HTMLElement>(
          'button:not([disabled]), input:not([disabled]), [tabindex="0"]',
        ) || [],
      );
    const focusTimer = setTimeout(() => (focusables()[0] || dialog)?.focus(), 30);
    const handle = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && closeRef.current) {
        event.preventDefault();
        event.stopPropagation();
        closeRef.current();
      }
      if (event.key !== 'Tab') return;
      const items = focusables();
      if (!items.length) {
        event.preventDefault();
        dialog?.focus();
        return;
      }
      if (
        event.shiftKey &&
        (document.activeElement === items[0] || document.activeElement === dialog)
      ) {
        event.preventDefault();
        items[items.length - 1].focus();
      } else if (!event.shiftKey && document.activeElement === items[items.length - 1]) {
        event.preventDefault();
        items[0].focus();
      }
    };
    document.addEventListener('keydown', handle);
    if (openDialogs === 0) originalOverflow = document.body.style.overflow;
    openDialogs += 1;
    document.body.style.overflow = 'hidden';
    return () => {
      clearTimeout(focusTimer);
      document.removeEventListener('keydown', handle);
      openDialogs = Math.max(0, openDialogs - 1);
      if (openDialogs === 0) document.body.style.overflow = originalOverflow;
      if (previous?.isConnected && openDialogs === 0) previous.focus();
    };
  }, []);
  return (
    <motion.div
      className="modal-backdrop"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: reduced ? 0 : 0.18 }}
    >
      <motion.div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-labelledby={id}
        tabIndex={-1}
        className={`modal-card ${className}`}
        data-testid={testId}
        initial={{ opacity: 0, y: reduced ? 0 : 22, scale: reduced ? 1 : 0.94 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: reduced ? 0 : 10 }}
        transition={{ type: 'spring', stiffness: 330, damping: 28 }}
      >
        {onClose && (
          <button
            className="icon-button modal-close"
            onClick={onClose}
            aria-label="Pencereyi kapat"
          >
            <X size={21} />
          </button>
        )}
        <h2 id={id} className="sr-only">
          {title}
        </h2>
        {children}
      </motion.div>
    </motion.div>
  );
}
