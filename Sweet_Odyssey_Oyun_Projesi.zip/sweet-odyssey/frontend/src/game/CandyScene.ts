import Phaser from 'phaser';
import {
  findValidMoves,
  type Action,
  type Board,
  type Candy,
  type Frame,
  type GameState,
  type Position,
} from './engine';

const SIZE = 640;
const PAD = 13;
const PALETTE = [0xf994b8, 0x86dfe3, 0xffdb7c, 0xc4a2ff, 0xffb374, 0xade4a3];

type CandySprite = { container: Phaser.GameObjects.Container; candy: Candy };
export type SceneOptions = {
  state: GameState;
  onAction: (action: Action) => void;
  isLocked: () => boolean;
  hammerMode: () => boolean;
  reducedMotion: () => boolean;
  onClear: () => void;
  onReady: (scene: CandyScene) => void;
};

export class CandyScene extends Phaser.Scene {
  private options: SceneOptions;
  private candies = new Map<number, CandySprite>();
  private state!: GameState;
  private selection: Position | null = null;
  private selectionInk!: Phaser.GameObjects.Graphics;
  private frostInk!: Phaser.GameObjects.Graphics;
  private hintInk!: Phaser.GameObjects.Graphics;
  private cursorInk!: Phaser.GameObjects.Graphics;
  private dragStart: { x: number; y: number; cell: Position; used: boolean } | null = null;
  private alive = true;
  private idleAt = 0;
  private lastHint = 0;
  private keyboardCell: Position | null = null;

  constructor(options: SceneOptions) {
    super({ key: 'SweetOdyssey' });
    this.options = options;
    this.state = options.state;
  }

  preload() {
    for (let i = 0; i < 6; i += 1)
      this.load.svg(`candy${i}`, `/assets/candy-${i}.svg`, { width: 160, height: 160 });
  }

  create() {
    this.alive = true;
    const bg = this.add.graphics();
    bg.fillStyle(0x382141, 1);
    bg.fillRoundedRect(0, 0, SIZE, SIZE, 28);
    bg.lineStyle(2, 0xf6caef, 0.09);
    bg.strokeRoundedRect(2, 2, SIZE - 4, SIZE - 4, 26);
    const cell = this.cellSize;
    for (let r = 0; r < this.state.board.length; r += 1) {
      for (let c = 0; c < this.state.board[0].length; c += 1) {
        bg.fillStyle((r + c) % 2 ? 0x4b3057 : 0x44294f, 1);
        bg.fillRoundedRect(PAD + c * cell + 2, PAD + r * cell + 2, cell - 4, cell - 4, 15);
        bg.lineStyle(1, 0xf9ddff, 0.035);
        bg.strokeRoundedRect(PAD + c * cell + 2, PAD + r * cell + 2, cell - 4, cell - 4, 15);
      }
    }
    this.frostInk = this.add.graphics().setDepth(7);
    this.selectionInk = this.add.graphics().setDepth(12);
    this.hintInk = this.add.graphics().setDepth(11);
    this.cursorInk = this.add.graphics().setDepth(13);
    this.syncBoard(this.state.board, false, 0);
    this.drawFrost(this.state.blockers);
    this.idleAt = this.time.now;
    this.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      if (this.options.isLocked()) return;
      const cellAt = this.cellAt(pointer.x, pointer.y);
      if (!cellAt) return;
      this.dragStart = { x: pointer.x, y: pointer.y, cell: cellAt, used: false };
      this.resetHint();
    });
    this.input.on('pointermove', (pointer: Phaser.Input.Pointer) => {
      const start = this.dragStart;
      if (
        !pointer.isDown ||
        !start ||
        start.used ||
        this.options.isLocked() ||
        this.options.hammerMode()
      )
        return;
      const dx = pointer.x - start.x;
      const dy = pointer.y - start.y;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < this.cellSize * 0.34) return;
      start.used = true;
      const to: Position =
        Math.abs(dx) > Math.abs(dy)
          ? [start.cell[0], start.cell[1] + Math.sign(dx)]
          : [start.cell[0] + Math.sign(dy), start.cell[1]];
      this.clearSelection();
      this.options.onAction({ kind: 'swap', from: start.cell, to });
    });
    this.input.on('pointerup', () => {
      const start = this.dragStart;
      this.dragStart = null;
      if (!start || start.used || this.options.isLocked()) return;
      this.selectCell(start.cell);
    });
    this.input.on('pointerupoutside', () => {
      this.dragStart = null;
    });
    this.events.once('shutdown', () => {
      this.alive = false;
    });
    this.options.onReady(this);
  }

  get cellSize() {
    return (SIZE - PAD * 2) / this.state.board[0].length;
  }

  private xy(cell: Position) {
    return { x: PAD + (cell[1] + 0.5) * this.cellSize, y: PAD + (cell[0] + 0.5) * this.cellSize };
  }

  private cellAt(x: number, y: number): Position | null {
    const row = Math.floor((y - PAD) / this.cellSize);
    const col = Math.floor((x - PAD) / this.cellSize);
    if (row < 0 || col < 0 || row >= this.state.board.length || col >= this.state.board[0].length)
      return null;
    return [row, col];
  }

  selectCell(cell: Position) {
    if (!this.alive || this.options.isLocked()) return;
    this.resetHint();
    if (this.options.hammerMode()) {
      this.clearSelection();
      this.options.onAction({ kind: 'hammer', at: cell });
      return;
    }
    if (
      this.selection &&
      Math.abs(this.selection[0] - cell[0]) + Math.abs(this.selection[1] - cell[1]) === 1
    ) {
      const from = this.selection;
      this.clearSelection();
      this.options.onAction({ kind: 'swap', from, to: cell });
      return;
    }
    if (this.selection?.[0] === cell[0] && this.selection?.[1] === cell[1]) this.clearSelection();
    else {
      this.selection = cell;
      this.selectionInk.clear();
      this.drawRing(this.selectionInk, cell, 0xffe4a2, 5);
    }
  }

  setKeyboardCursor(cell: Position | null) {
    this.keyboardCell = cell;
    if (!this.cursorInk) return;
    this.cursorInk.clear();
    if (cell) this.drawRing(this.cursorInk, cell, 0xffffff, 2);
  }

  clearSelection() {
    this.selection = null;
    this.selectionInk?.clear();
  }

  private drawRing(ink: Phaser.GameObjects.Graphics, cell: Position, color: number, width: number) {
    const p = this.xy(cell);
    const size = this.cellSize - 7;
    ink.lineStyle(width, color, 0.94);
    ink.strokeRoundedRect(p.x - size / 2, p.y - size / 2, size, size, 16);
  }

  private makeCandy(candy: Candy, x: number, y: number) {
    const container = this.add.container(x, y).setDepth(5);
    const image = this.add.image(0, 0, `candy${candy.color}`);
    image.setDisplaySize(this.cellSize * 0.85, this.cellSize * 0.85);
    container.add(image);
    const glint = this.add.graphics();
    if (candy.special === 'row' || candy.special === 'column') {
      glint.lineStyle(3.3, 0xfffbdf, 0.96);
      for (let offset = -10; offset <= 10; offset += 10) {
        if (candy.special === 'row') glint.lineBetween(-23, offset, 23, offset);
        else glint.lineBetween(offset, -23, offset, 23);
      }
      glint.lineStyle(1.5, 0xffffff, 0.8);
      glint.strokeCircle(0, 0, 29);
    } else if (candy.special === 'color') {
      glint.fillStyle(0x44234f, 0.72);
      glint.fillCircle(0, 0, 23);
      PALETTE.forEach((color, i) => {
        const angle = (i * Math.PI) / 3;
        glint.fillStyle(color);
        glint.fillCircle(Math.cos(angle) * 16, Math.sin(angle) * 16, 6.5);
      });
      glint.fillStyle(0xfff9d1);
      glint.fillCircle(0, 0, 6);
      glint.lineStyle(2.5, 0xfff6c9, 0.9);
      glint.strokeCircle(0, 0, 29);
    }
    container.add(glint);
    this.candies.set(candy.id, { container, candy: { ...candy } });
    return container;
  }

  private syncBoard(board: Board, falling: boolean, duration: number) {
    if (!this.alive) return;
    const wanted = new Set<number>();
    board.forEach((row, r) =>
      row.forEach((candy, c) => {
        if (!candy) return;
        wanted.add(candy.id);
        const p = this.xy([r, c]);
        let sprite = this.candies.get(candy.id);
        if (
          sprite &&
          (sprite.candy.special !== candy.special || sprite.candy.color !== candy.color)
        ) {
          sprite.container.destroy();
          this.candies.delete(candy.id);
          sprite = undefined;
        }
        if (!sprite) {
          const container = this.makeCandy(
            candy,
            p.x,
            falling && duration ? p.y - SIZE * 0.5 - r * 10 : p.y,
          );
          if (duration && !falling) container.setScale(0.4);
          sprite = this.candies.get(candy.id)!;
        }
        this.tweens.killTweensOf(sprite.container);
        if (duration)
          this.tweens.add({
            targets: sprite.container,
            x: p.x,
            y: p.y,
            scale: 1,
            alpha: 1,
            duration,
            ease: falling ? 'Back.easeOut' : 'Sine.easeInOut',
          });
        else sprite.container.setPosition(p.x, p.y).setScale(1).setAlpha(1);
      }),
    );
    for (const [id, sprite] of this.candies) {
      if (!wanted.has(id)) {
        sprite.container.destroy();
        this.candies.delete(id);
      }
    }
  }

  private drawFrost(blockers: number[][]) {
    if (!this.alive || !this.frostInk) return;
    this.frostInk.clear();
    blockers.forEach((row, r) =>
      row.forEach((layers, c) => {
        if (!layers) return;
        const p = this.xy([r, c]);
        const half = this.cellSize / 2 - 5;
        this.frostInk.fillStyle(0xfff0df, layers > 1 ? 0.23 : 0.13);
        this.frostInk.fillRoundedRect(p.x - half, p.y - half, half * 2, half * 2, 14);
        this.frostInk.lineStyle(layers > 1 ? 4 : 3, 0xffedda, 0.88);
        this.frostInk.strokeRoundedRect(p.x - half, p.y - half, half * 2, half * 2, 14);
        for (let i = 0; i < layers; i++) {
          this.frostInk.fillStyle(0xfff5de, 1);
          this.frostInk.fillCircle(p.x + half - 10 - i * 9, p.y + half - 9, 3);
        }
      }),
    );
  }

  private resetHint() {
    this.idleAt = this.time.now;
    if (this.hintInk) {
      this.tweens.killTweensOf(this.hintInk);
      this.hintInk.clear().setAlpha(1);
    }
  }

  update(time: number) {
    if (
      !this.hintInk ||
      this.options.isLocked() ||
      this.options.hammerMode() ||
      this.state.status !== 'playing'
    )
      return;
    if (time - this.idleAt > 6500 && time - this.lastHint > 5500) {
      this.lastHint = time;
      const move = findValidMoves(this.state.board)[0];
      if (!move) return;
      this.hintInk.clear();
      this.drawRing(this.hintInk, move.from, 0xf7d996, 2.5);
      this.drawRing(this.hintInk, move.to, 0xf7d996, 2.5);
      this.tweens.add({
        targets: this.hintInk,
        alpha: 0.12,
        duration: this.options.reducedMotion() ? 450 : 650,
        yoyo: true,
        repeat: 2,
        onComplete: () => this.hintInk?.clear().setAlpha(1),
      });
    }
  }

  private sleep(ms: number) {
    return new Promise<void>((resolve) => setTimeout(resolve, ms));
  }

  private burst(cell: Position, color: number, strong = false) {
    if (this.options.reducedMotion() || !this.alive) return;
    const p = this.xy(cell);
    const amount = strong ? 12 : 6;
    for (let i = 0; i < amount; i++) {
      const particle = this.add
        .circle(p.x, p.y, 2 + Math.random() * 4, i % 3 === 0 ? 0xfff6d9 : color)
        .setDepth(20);
      const angle = (Math.PI * 2 * i) / amount;
      const distance = 25 + Math.random() * (strong ? 100 : 45);
      this.tweens.add({
        targets: particle,
        x: p.x + Math.cos(angle) * distance,
        y: p.y + Math.sin(angle) * distance,
        alpha: 0,
        scale: 0.3,
        duration: 380,
        ease: 'Cubic.easeOut',
        onComplete: () => particle.destroy(),
      });
    }
  }

  async invalidSwap(from: Position, to: Position) {
    this.clearSelection();
    this.resetHint();
    if (!this.alive) return;
    const a = this.state.board[from[0]]?.[from[1]];
    const b = this.state.board[to[0]]?.[to[1]];
    if (!a || !b) return;
    const sa = this.candies.get(a.id)?.container;
    const sb = this.candies.get(b.id)?.container;
    const p1 = this.xy(from),
      p2 = this.xy(to);
    const duration = this.options.reducedMotion() ? 50 : 110;
    if (sa)
      this.tweens.add({
        targets: sa,
        x: p2.x,
        y: p2.y,
        duration,
        yoyo: true,
        ease: 'Sine.easeInOut',
      });
    if (sb)
      this.tweens.add({
        targets: sb,
        x: p1.x,
        y: p1.y,
        duration,
        yoyo: true,
        ease: 'Sine.easeInOut',
      });
    await this.sleep(duration * 2 + 10);
    if (this.alive) this.syncBoard(this.state.board, false, 0);
  }

  async playFrames(frames: Frame[], finalState: GameState) {
    this.clearSelection();
    this.resetHint();
    const reduced = this.options.reducedMotion();
    for (const frame of frames) {
      if (!this.alive) return;
      if (frame.kind === 'clear') {
        this.options.onClear();
        const duration = reduced ? 35 : 150;
        const wanted = new Set(
          frame.board
            .flat()
            .filter((c): c is Candy => c !== null)
            .map((c) => c.id),
        );
        for (const [id, sprite] of this.candies) {
          if (!wanted.has(id)) {
            const pos = this.cellAt(sprite.container.x, sprite.container.y);
            if (pos) this.burst(pos, PALETTE[sprite.candy.color]);
            this.tweens.add({
              targets: sprite.container,
              scale: 0.12,
              alpha: 0,
              angle: reduced ? 0 : 25,
              duration,
              ease: 'Back.easeIn',
            });
          }
        }
        if (frame.scoreDelta && !reduced) {
          const cells = frame.cells || [];
          const center = cells.length
            ? this.xy(cells[Math.floor(cells.length / 2)])
            : { x: SIZE / 2, y: SIZE / 2 };
          const text = this.add
            .text(
              center.x,
              center.y,
              `+${frame.scoreDelta}${frame.combo && frame.combo > 1 ? `  ×${frame.combo}` : ''}`,
              {
                fontFamily: 'Georgia, serif',
                fontSize: '34px',
                fontStyle: 'bold',
                color: '#fff2c7',
                stroke: '#6c3157',
                strokeThickness: 7,
              },
            )
            .setOrigin(0.5)
            .setDepth(22);
          this.tweens.add({
            targets: text,
            y: center.y - 64,
            alpha: 0,
            duration: 750,
            ease: 'Cubic.easeOut',
            onComplete: () => text.destroy(),
          });
        }
        await this.sleep(duration);
        if (!this.alive) return;
        this.syncBoard(frame.board, false, 0);
        this.drawFrost(frame.blockers);
      } else if (frame.kind === 'special') {
        for (const cell of frame.cells || []) this.burst(cell, 0xffe5a4, true);
        if (!reduced) {
          const glow = this.add.graphics().setDepth(19);
          (frame.cells || [])
            .slice(0, 40)
            .forEach((cell) => this.drawRing(glow, cell, 0xffefa6, 5));
          this.tweens.add({
            targets: glow,
            alpha: 0,
            duration: 260,
            onComplete: () => glow.destroy(),
          });
        }
        await this.sleep(reduced ? 20 : 120);
        if (!this.alive) return;
        this.syncBoard(frame.board, false, reduced ? 0 : 80);
        this.drawFrost(frame.blockers);
      } else {
        const duration = reduced
          ? 35
          : frame.kind === 'fall'
            ? 220
            : frame.kind === 'shuffle'
              ? 300
              : 155;
        this.syncBoard(frame.board, frame.kind === 'fall', duration);
        this.drawFrost(frame.blockers);
        await this.sleep(duration + 10);
      }
    }
    if (!this.alive) return;
    this.state = finalState;
    this.syncBoard(finalState.board, false, 0);
    this.drawFrost(finalState.blockers);
    this.resetHint();
    if (this.keyboardCell) this.setKeyboardCursor(this.keyboardCell);
  }
}
