import { describe, expect, it } from 'vitest';
import { execFile } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import levelData from '../../../shared/levels.json';
import winData from '../../../tests/fixtures/level_wins.json';
import {
  applyAction,
  createGame,
  findMatches,
  findValidMoves,
  getStars,
  validateLevel,
  type Action,
  type ActionResult,
  type Board,
  type GameState,
  type Level,
} from './engine';

const levels = levelData as Level[];
const wins = winData as {
  levelId: number;
  seed: number;
  actions: Action[];
  score: number;
  movesLeft: number;
}[];
const endless = (changes: Partial<Level> = {}): Level => ({
  ...structuredClone(levels[0]),
  target: 1_000_000,
  starThresholds: [1_000_000, 1_000_001, 1_000_002],
  ...changes,
});
const firstSwap = (state: GameState, level: Level): ActionResult =>
  applyAction(state, { kind: 'swap', ...findValidMoves(state.board)[0] }, level);
const firstClear = (result: ActionResult) => result.frames.find((frame) => frame.kind === 'clear')!;
function pristine(state: GameState): void {
  expect(findMatches(state.board)).toEqual([]);
  expect(findValidMoves(state.board).length).toBeGreaterThan(0);
  expect(state.board.flat().every((c) => c !== null)).toBe(true);
  expect(new Set(state.board.flat().map((c) => c!.id)).size).toBe(state.board.flat().length);
  expect(state.blockers.flat().every((hp) => hp >= 0)).toBe(true);
}

describe('configured levels and generation', () => {
  it('validates every level and rejects malformed objectives', () => {
    expect(levels.map((level) => level.id)).toEqual(Array.from({ length: 20 }, (_, i) => i + 1));
    for (const level of levels) expect(validateLevel(level)).toEqual([]);
    expect(validateLevel({ ...levels[0], colors: 4 }).length).toBeGreaterThan(0);
    expect(
      validateLevel({
        ...levels[0],
        collections: [
          { color: 0, count: 3 },
          { color: 0, count: 3 },
        ],
      }).length,
    ).toBeGreaterThan(0);
    expect(() => createGame({ ...levels[0], moves: 0 }, 1)).toThrow();
  });
  it.each(levels)('level $id has stable, playable starts across twenty seeds', (level) => {
    for (const seed of [
      0,
      1,
      2,
      42,
      0xffffffff,
      ...Array.from({ length: 15 }, (_, i) => 101 + i),
    ]) {
      const state = createGame(level, seed);
      pristine(state);
      expect(state.movesLeft).toBe(level.moves);
      expect(state.score).toBe(0);
      expect(state.collected).toEqual([0, 0, 0, 0, 0, 0]);
      expect(state.board.flat().every((c) => c!.color >= 0 && c!.color < level.colors)).toBe(true);
    }
  });
  it('reproduces the same seed and diverges for another seed', () => {
    expect(createGame(levels[0], 42)).toEqual(createGame(levels[0], 42));
    expect(createGame(levels[0], 42).board).not.toEqual(createGame(levels[0], 43).board);
  });
});

describe('matches, moves, scoring and snapshots', () => {
  it('detects horizontal, vertical and crossing runs once per cell', () => {
    const grid = [
      [1, 0, 2],
      [0, 0, 0],
      [2, 0, 1],
    ];
    const board: Board = grid.map((row, r) =>
      row.map((color, c) => ({ id: r * 3 + c, color, special: 'none' })),
    );
    expect(findMatches(board)).toEqual([
      [0, 1],
      [1, 0],
      [1, 1],
      [1, 2],
      [2, 1],
    ]);
    board[1][1]!.special = 'color';
    expect(findMatches(board)).toEqual([]);
    board[1][1] = null;
    expect(findMatches(board)).toEqual([]);
  });
  it.each([
    { from: [-1, 0], to: [0, 0] },
    { from: [0, 0], to: [8, 0] },
    { from: [0, 0], to: [1, 1] },
    { from: [0, 0], to: [0, 2] },
    { from: [0, 0], to: [0, 0] },
    { from: [0, 0], to: [0, 1] },
  ])('rejects invalid swap $from to $to without mutation', (move) => {
    const state = createGame(levels[0], 1),
      before = structuredClone(state);
    const result = applyAction(state, { kind: 'swap', ...move } as Action, levels[0]);
    expect(result.accepted).toBe(false);
    expect(result.state).toBe(state);
    expect(result.frames).toEqual([]);
    expect(state).toEqual(before);
  });
  it('commits a real move and counts only cleared candies', () => {
    const state = createGame(levels[0], 1),
      before = structuredClone(state);
    const result = firstSwap(state, levels[0]);
    expect(result.accepted).toBe(true);
    expect(state).toEqual(before);
    expect(result.state.movesLeft).toBe(state.movesLeft - 1);
    expect(result.state.score).toBe(180);
    expect(result.state.collected.reduce((a, b) => a + b)).toBe(3);
    expect(result.frames.map((f) => f.kind)).toEqual(['swap', 'clear', 'fall']);
    pristine(result.state);
    const frames = structuredClone(result.frames);
    result.state.board[0][0]!.color = 999;
    expect(result.frames).toEqual(frames);
  });
  it('resolves gravity with stable survivor ids and real cascade multipliers', () => {
    const result = firstSwap(createGame(levels[0], 42), levels[0]);
    const clears = result.frames.filter((frame) => frame.kind === 'clear');
    expect(clears.map((f) => f.combo)).toEqual([1, 2]);
    expect(clears.map((f) => f.scoreDelta)).toEqual([180, 360]);
    expect(result.state.score).toBe(540);
    result.frames.forEach((frame, i) => {
      if (frame.kind !== 'clear') return;
      const fall = result.frames[i + 1];
      expect(fall.kind).toBe('fall');
      for (let c = 0; c < 8; c++) {
        const survivors = frame.board
          .map((row) => row[c])
          .filter((candy) => candy !== null)
          .map((candy) => candy.id);
        expect(fall.board.map((row) => row[c]!.id).slice(8 - survivors.length)).toEqual(survivors);
      }
    });
    pristine(result.state);
  });
});

describe('special candy creation and chain reactions', () => {
  it.each([
    { seed: 4, from: [3, 3], to: [4, 3], special: 'row' },
    { seed: 3, from: [2, 5], to: [2, 6], special: 'column' },
    { seed: 8, from: [4, 4], to: [4, 5], special: 'color' },
    { seed: 3, from: [1, 6], to: [2, 6], special: 'color' },
  ])('creates $special from a real four/five/cross match on seed $seed', (test) => {
    const state = createGame(levels[0], test.seed);
    const result = applyAction(
      state,
      { kind: 'swap', from: test.from, to: test.to } as Action,
      levels[0],
    );
    const clear = firstClear(result);
    expect(clear.board[test.to[0]][test.to[1]]!.special).toBe(test.special);
    expect(clear.cells).not.toContainEqual(test.to);
    pristine(result.state);
  });
  it('chains a hammered row into a column exactly once at their intersection', () => {
    const level = endless(),
      state = createGame(level, 1);
    state.board[3][3]!.special = 'row';
    state.board[3][6]!.special = 'column';
    const result = applyAction(state, { kind: 'hammer', at: [3, 3] }, level),
      clear = firstClear(result);
    expect(clear.cells).toHaveLength(15);
    for (let i = 0; i < 8; i++) {
      expect(clear.cells).toContainEqual([3, i]);
      expect(clear.cells).toContainEqual([i, 6]);
    }
    expect(result.frames.some((f) => f.kind === 'special')).toBe(true);
    expect(result.state.movesLeft).toBe(state.movesLeft);
    expect(result.state.powers.hammer).toBe(0);
    pristine(result.state);
  });
  it('combines two color bombs into a full board clear and only one frosting hit', () => {
    const level = endless({ blockers: [{ row: 0, col: 0, hp: 2 }] }),
      state = createGame(level, 1);
    state.board[0][0]!.special = 'color';
    state.board[0][1]!.special = 'color';
    const result = applyAction(state, { kind: 'swap', from: [0, 0], to: [0, 1] }, level);
    const clear = firstClear(result);
    expect(clear.cells).toHaveLength(64);
    expect(clear.board.flat().every((c) => c === null)).toBe(true);
    expect(clear.blockers[0][0]).toBe(1);
    pristine(result.state);
  });
  it.each(['none', 'row', 'column'] as const)(
    'combines a color bomb with %s using the partner color',
    (special) => {
      const level = endless(),
        state = createGame(level, 1);
      state.board[0][0]!.special = 'color';
      state.board[0][1]!.special = special;
      const target = state.board[0][1]!.color;
      const result = applyAction(state, { kind: 'swap', from: [0, 0], to: [0, 1] }, level),
        clear = firstClear(result);
      result.frames[0].board.forEach((row, r) =>
        row.forEach((candy, c) => {
          if (candy!.color === target) expect(clear.cells).toContainEqual([r, c]);
        }),
      );
      expect(clear.cells).toContainEqual([0, 1]);
      pristine(result.state);
    },
  );
});

describe('powers, frosting, terminal states and complete attempts', () => {
  it('requires every frosting layer in addition to score and collection targets', () => {
    const level = endless({
      blockers: [{ row: 0, col: 0, hp: 2 }],
      collections: [{ color: 0, count: 2 }],
    });
    const state = createGame(level, 1);
    state.score = level.target;
    state.collected[0] = 2;
    const result = applyAction(state, { kind: 'hammer', at: [0, 0] }, level);
    expect(result.state.blockers[0][0]).toBe(1);
    expect(result.state.status).toBe('playing');
    expect(applyAction(result.state, { kind: 'hammer', at: [0, 0] }, level).accepted).toBe(false);
  });
  it('wins on the last move before checking loss', () => {
    const level = { ...levels[0], moves: 1, target: 1, starThresholds: [1, 200, 500] } as Level;
    const result = firstSwap(createGame(level, 1), level);
    expect(result.state.movesLeft).toBe(0);
    expect(result.state.status).toBe('won');
    expect(getStars(result.state, level)).toBe(1);
    expect(applyAction(result.state, { kind: 'extra' }, level).accepted).toBe(false);
  });
  it('loses, blocks regular input, and allows exactly one free +5 revival', () => {
    const level = endless({ moves: 1 }),
      lost = firstSwap(createGame(level, 1), level).state;
    expect(lost.status).toBe('lost');
    expect(firstSwap(lost, level).accepted).toBe(false);
    const revived = applyAction(lost, { kind: 'extra' }, level);
    expect(revived.state.status).toBe('playing');
    expect(revived.state.movesLeft).toBe(5);
    expect(applyAction(revived.state, { kind: 'extra' }, level).accepted).toBe(false);
    expect(getStars(lost, level)).toBe(0);
  });
  it('requires collection goals even when the target score has already been reached', () => {
    const level: Level = {
      ...levels[0],
      moves: 1,
      target: 1,
      starThresholds: [1, 2, 3],
      collections: [{ color: 4, count: 100 }],
    };
    const result = firstSwap(createGame(level, 1), level);
    expect(result.state.score).toBeGreaterThanOrEqual(level.target);
    expect(result.state.status).toBe('lost');
  });
  it('shuffles once without consuming a move or changing candy inventory', () => {
    const state = createGame(levels[7], 42),
      result = applyAction(state, { kind: 'shuffle' }, levels[7]);
    const inventory = (s: GameState) =>
      s.board
        .flat()
        .map((c) => ({ ...c! }))
        .sort((a, b) => a.id - b.id);
    expect(inventory(result.state)).toEqual(inventory(state));
    expect(result.state.blockers).toEqual(state.blockers);
    expect(result.state.movesLeft).toBe(state.movesLeft);
    expect(result.state.score).toBe(0);
    expect(applyAction(result.state, { kind: 'shuffle' }, levels[7]).accepted).toBe(false);
    pristine(result.state);
  });
  it('repairs a dead board automatically without spending the shuffle power', () => {
    const level = endless(),
      state = createGame(level, 1);
    state.board.forEach((row, r) =>
      row.forEach((candy, c) => {
        candy!.color = (r * 2 + c) % 5;
      }),
    );
    expect(findMatches(state.board)).toEqual([]);
    expect(findValidMoves(state.board)).toEqual([]);
    const result = applyAction(state, { kind: 'extra' }, level);
    expect(result.frames.some((f) => f.kind === 'shuffle')).toBe(true);
    expect(result.state.powers.shuffle).toBe(1);
    pristine(result.state);
  });
  it.each(levels)('level $id reaches a pristine win/loss through actual legal actions', (level) => {
    let state = createGame(level, 700 + level.id);
    for (let i = 0; i < level.moves && state.status === 'playing'; i++) {
      const result = firstSwap(state, level);
      expect(result.accepted).toBe(true);
      state = result.state;
      pristine(state);
    }
    expect(['won', 'lost']).toContain(state.status);
    if (state.status === 'won') {
      expect(state.score).toBeGreaterThanOrEqual(level.target);
      for (const goal of level.collections)
        expect(state.collected[goal.color]).toBeGreaterThanOrEqual(goal.count);
      expect(state.blockers.flat().reduce((a, b) => a + b)).toBe(0);
    }
  });
  it.each(wins)('level $levelId has a reproducible real winning solution', (fixture) => {
    const level = levels[fixture.levelId - 1];
    let state = createGame(level, fixture.seed);
    for (const action of fixture.actions) {
      const result = applyAction(state, action, level);
      expect(result.accepted).toBe(true);
      state = result.state;
    }
    expect(state.status).toBe('won');
    expect(state.score).toBe(fixture.score);
    expect(state.movesLeft).toBe(fixture.movesLeft);
    for (const goal of level.collections)
      expect(state.collected[goal.color]).toBeGreaterThanOrEqual(goal.count);
    expect(state.blockers.flat().reduce((a, b) => a + b)).toBe(0);
    pristine(state);
  });
});

describe('server/frontend replay parity', () => {
  it('matches Python exactly, including every animation snapshot, powers and special combos', async () => {
    type Case = { level: Level; seed: number; actions: Action[]; state?: GameState };
    const cases: Case[] = levels.map((level) => ({
      level,
      seed: (level.id * 2654435761) >>> 0,
      actions: [],
    }));
    const traces: unknown[][] = [];
    for (const entry of cases) {
      let state = createGame(entry.level, entry.seed);
      const trace: unknown[] = [{ initial: state }];
      for (let i = 0; i < 11; i++) {
        if (state.status !== 'playing') break;
        const action: Action =
          i === 2
            ? { kind: 'hammer', at: [3, 3] }
            : i === 4
              ? { kind: 'shuffle' }
              : i === 7
                ? { kind: 'extra' }
                : {
                    kind: 'swap',
                    ...findValidMoves(state.board)[(i * 3) % findValidMoves(state.board).length],
                  };
        entry.actions.push(action);
        const result = applyAction(state, action, entry.level);
        trace.push(result);
        state = result.state;
      }
      traces.push(trace);
    }
    for (const specials of [
      ['color', 'color'],
      ['color', 'row'],
      ['row', 'column'],
    ] as const) {
      const level = endless(),
        state = createGame(level, 1);
      state.board[0][0]!.special = specials[0];
      state.board[0][1]!.special = specials[1];
      const action: Action = { kind: 'swap', from: [0, 0], to: [0, 1] };
      cases.push({ level, seed: 1, state, actions: [action] });
      traces.push([{ initial: state }, applyAction(state, action, level)]);
    }
    for (const win of wins) {
      const level = levels[win.levelId - 1];
      let state = createGame(level, win.seed);
      const trace: unknown[] = [{ initial: state }];
      for (const action of win.actions) {
        const result = applyAction(state, action, level);
        trace.push(result);
        state = result.state;
      }
      cases.push({ level, seed: win.seed, actions: win.actions });
      traces.push(trace);
    }
    const root = path.resolve(process.cwd(), '..');
    const localPython = path.join(
      root,
      '.venv',
      process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python',
    );
    const python = process.env.SWEET_PYTHON ?? (existsSync(localPython) ? localPython : 'python');
    const output = await new Promise<string>((resolve, reject) => {
      const child = execFile(
        python,
        [path.join(root, 'tests/backend/engine_bridge.py')],
        {
          encoding: 'utf8',
          maxBuffer: 64 * 1024 * 1024,
          timeout: 30_000,
        },
        (error, stdout) => (error ? reject(error) : resolve(stdout)),
      );
      child.stdin!.end(JSON.stringify({ cases }));
    });
    expect(JSON.parse(output)).toEqual(traces);
  }, 40_000);
});
