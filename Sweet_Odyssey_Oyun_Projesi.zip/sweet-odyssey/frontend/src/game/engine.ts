/** Deterministic, rendering-independent match-3 rules.
 * Keep this file in lockstep with backend/app/engine.py. Every random decision
 * goes through xorshift32; iteration order is row-major, then numeric cell key.
 */
export type Position = [number, number];
export type Special = 'none' | 'row' | 'column' | 'color';
export interface Candy {
  id: number;
  color: number;
  special: Special;
}
export type Board = (Candy | null)[][];
export interface Level {
  id: number;
  name: string;
  realm: string;
  description: string;
  rows: number;
  cols: number;
  colors: number;
  moves: number;
  target: number;
  collections: { color: number; count: number }[];
  blockers: { row: number; col: number; hp: number }[];
  starThresholds: [number, number, number];
  difficulty: string;
}
export interface GameState {
  levelId: number;
  board: Board;
  blockers: number[][];
  rng: number;
  nextId: number;
  score: number;
  movesLeft: number;
  collected: number[];
  turn: number;
  status: 'playing' | 'won' | 'lost';
  powers: { hammer: number; shuffle: number; extra: number };
}
export type Action =
  | { kind: 'swap'; from: Position; to: Position }
  | { kind: 'hammer'; at: Position }
  | { kind: 'shuffle' }
  | { kind: 'extra' };
export interface Frame {
  kind: 'swap' | 'clear' | 'fall' | 'shuffle' | 'special';
  board: Board;
  blockers: number[][];
  cells?: Position[];
  scoreDelta?: number;
  combo?: number;
  from?: Position;
  to?: Position;
}
export interface ActionResult {
  accepted: boolean;
  state: GameState;
  frames: Frame[];
  message?: string;
}
export interface Move {
  from: Position;
  to: Position;
}
interface MatchRun {
  cells: number[];
  direction: 'row' | 'column';
}

const ZERO_SEED = 0x6d2b79f5;
const MAX_CASCADES = 64;
const copyBoard = (board: Board): Board =>
  board.map((row) => row.map((c) => (c ? { ...c } : null)));
const copyGrid = (grid: number[][]): number[][] => grid.map((row) => [...row]);
const position = (key: number, cols: number): Position => [Math.floor(key / cols), key % cols];
const sorted = (values: Iterable<number>): number[] => [...values].sort((a, b) => a - b);

export function cloneState(state: GameState): GameState {
  return {
    ...state,
    board: copyBoard(state.board),
    blockers: copyGrid(state.blockers),
    collected: [...state.collected],
    powers: { ...state.powers },
  };
}

/** A validation error list, empty for a well formed configuration. */
export function validateLevel(level: Level): string[] {
  const errors: string[] = [];
  if (!level || typeof level !== 'object') return ['Bölüm tanımı nesne olmalı.'];
  const integer = (v: unknown, lo: number, hi: number): boolean =>
    Number.isInteger(v) && Number(v) >= lo && Number(v) <= hi;
  if (!integer(level.id, 1, 10000)) errors.push('Bölüm kimliği geçersiz.');
  for (const field of ['name', 'realm', 'description', 'difficulty'] as const) {
    if (typeof level[field] !== 'string' || !level[field].trim())
      errors.push(`${field} metni gerekli.`);
  }
  if (!integer(level.rows, 3, 12) || !integer(level.cols, 3, 12))
    errors.push('Tahta boyutu 3–12 arasında olmalı.');
  if (!integer(level.colors, 5, 6)) errors.push('Şeker rengi sayısı 5 veya 6 olmalı.');
  if (!integer(level.moves, 1, 100)) errors.push('Hamle sayısı 1–100 arasında olmalı.');
  if (!integer(level.target, 1, 1000000)) errors.push('Puan hedefi geçersiz.');
  if (
    !Array.isArray(level.starThresholds) ||
    level.starThresholds.length !== 3 ||
    !level.starThresholds.every((v) => integer(v, 1, 10000000)) ||
    !(
      level.starThresholds[0] < level.starThresholds[1] &&
      level.starThresholds[1] < level.starThresholds[2]
    ) ||
    level.starThresholds[0] > level.target
  )
    errors.push('Yıldız eşikleri artan üç pozitif sayı olmalı; ilki puan hedefini aşamaz.');
  const colors = new Set<number>();
  if (!Array.isArray(level.collections)) errors.push('Toplama hedefleri liste olmalı.');
  else
    for (const goal of level.collections) {
      if (
        !goal ||
        !integer(goal.color, 0, level.colors - 1) ||
        !integer(goal.count, 1, 10000) ||
        colors.has(goal.color)
      )
        errors.push('Toplama hedefi geçersiz veya yineleniyor.');
      if (goal) colors.add(goal.color);
    }
  const cells = new Set<string>();
  if (!Array.isArray(level.blockers)) errors.push('Krema hücreleri liste olmalı.');
  else
    for (const cell of level.blockers) {
      if (
        !cell ||
        !integer(cell.row, 0, level.rows - 1) ||
        !integer(cell.col, 0, level.cols - 1) ||
        !integer(cell.hp, 1, 3) ||
        cells.has(`${cell.row}:${cell.col}`)
      )
        errors.push('Krema hücresi geçersiz veya yineleniyor.');
      if (cell) cells.add(`${cell.row}:${cell.col}`);
    }
  return errors;
}

function randomInt(state: GameState, bound: number): number {
  let value = state.rng >>> 0;
  value ^= value << 13;
  value ^= value >>> 17;
  value ^= value << 5;
  state.rng = value >>> 0;
  return state.rng % bound;
}

function newCandy(state: GameState, color: number): Candy {
  return { id: state.nextId++, color, special: 'none' };
}

function matchColor(candy: Candy | null): number {
  return candy && candy.special !== 'color' ? candy.color : -1;
}

function matchRuns(board: Board): MatchRun[] {
  const rows = board.length,
    cols = board[0]?.length ?? 0,
    runs: MatchRun[] = [];
  for (let r = 0; r < rows; r++) {
    let c = 0;
    while (c < cols) {
      const start = c,
        color = matchColor(board[r][c]);
      c++;
      while (c < cols && color >= 0 && matchColor(board[r][c]) === color) c++;
      if (color >= 0 && c - start >= 3)
        runs.push({
          direction: 'row',
          cells: Array.from({ length: c - start }, (_, i) => r * cols + start + i),
        });
    }
  }
  for (let c = 0; c < cols; c++) {
    let r = 0;
    while (r < rows) {
      const start = r,
        color = matchColor(board[r][c]);
      r++;
      while (r < rows && color >= 0 && matchColor(board[r][c]) === color) r++;
      if (color >= 0 && r - start >= 3)
        runs.push({
          direction: 'column',
          cells: Array.from({ length: r - start }, (_, i) => (start + i) * cols + c),
        });
    }
  }
  return runs;
}

export function findMatches(board: Board): Position[] {
  const cols = board[0]?.length ?? 0;
  return sorted(new Set(matchRuns(board).flatMap((run) => run.cells))).map((key) =>
    position(key, cols),
  );
}

function lineAt(board: Board, at: Position): boolean {
  const [r, c] = at,
    color = matchColor(board[r][c]);
  if (color < 0) return false;
  const rows = board.length,
    cols = board[0].length;
  for (const [dr, dc] of [
    [1, 0],
    [0, 1],
  ]) {
    let count = 1;
    for (const sign of [-1, 1]) {
      let rr = r + dr * sign,
        cc = c + dc * sign;
      while (rr >= 0 && rr < rows && cc >= 0 && cc < cols && matchColor(board[rr][cc]) === color) {
        count++;
        rr += dr * sign;
        cc += dc * sign;
      }
    }
    if (count >= 3) return true;
  }
  return false;
}

function specialSwap(a: Candy, b: Candy): boolean {
  return (
    a.special === 'color' || b.special === 'color' || (a.special !== 'none' && b.special !== 'none')
  );
}

export function findValidMoves(board: Board): Move[] {
  const rows = board.length,
    cols = board[0]?.length ?? 0;
  const work = board.map((row) => [...row]),
    moves: Move[] = [];
  for (let r = 0; r < rows; r++)
    for (let c = 0; c < cols; c++) {
      for (const [dr, dc] of [
        [0, 1],
        [1, 0],
      ]) {
        const rr = r + dr,
          cc = c + dc;
        if (rr >= rows || cc >= cols) continue;
        const a = work[r][c],
          b = work[rr][cc];
        if (!a || !b) continue;
        work[r][c] = b;
        work[rr][cc] = a;
        const valid = specialSwap(a, b) || lineAt(work, [r, c]) || lineAt(work, [rr, cc]);
        work[r][c] = a;
        work[rr][cc] = b;
        if (valid) moves.push({ from: [r, c], to: [rr, cc] });
      }
    }
  return moves;
}

/** Fresh fill avoids triples as it is built. The final fallback has a known move. */
function freshBoard(state: GameState, level: Level, forceMove = false): void {
  state.board = Array.from({ length: level.rows }, () =>
    Array<Candy | null>(level.cols).fill(null),
  );
  const fixed = new Map([
    [0, 0],
    [1, 1],
    [2, 0],
    [level.cols + 1, 0],
  ]);
  for (let r = 0; r < level.rows; r++)
    for (let c = 0; c < level.cols; c++) {
      const allowed: number[] = [];
      for (let color = 0; color < level.colors; color++) {
        if (
          c >= 2 &&
          state.board[r][c - 1]?.color === color &&
          state.board[r][c - 2]?.color === color
        )
          continue;
        if (
          r >= 2 &&
          state.board[r - 1][c]?.color === color &&
          state.board[r - 2][c]?.color === color
        )
          continue;
        allowed.push(color);
      }
      const key = r * level.cols + c;
      const color =
        forceMove && fixed.has(key) ? fixed.get(key)! : allowed[randomInt(state, allowed.length)];
      state.board[r][c] = newCandy(state, color);
    }
}

function fillPlayable(state: GameState, level: Level): void {
  for (let attempt = 0; attempt < 100; attempt++) {
    freshBoard(state, level);
    if (findValidMoves(state.board).length > 0) return;
  }
  freshBoard(state, level, true);
}

export function createGame(level: Level, seed: number): GameState {
  const errors = validateLevel(level);
  if (errors.length) throw new Error(errors.join(' '));
  const state: GameState = {
    levelId: level.id,
    board: [],
    blockers: Array.from({ length: level.rows }, () => Array<number>(level.cols).fill(0)),
    rng: seed >>> 0 || ZERO_SEED,
    nextId: 1,
    score: 0,
    movesLeft: level.moves,
    collected: Array<number>(6).fill(0),
    turn: 0,
    status: 'playing',
    powers: { hammer: 1, shuffle: 1, extra: 1 },
  };
  for (const cell of level.blockers) state.blockers[cell.row][cell.col] = cell.hp;
  fillPlayable(state, level);
  return state;
}

function snapshot(state: GameState, kind: Frame['kind'], extra: Partial<Frame> = {}): Frame {
  return { kind, board: copyBoard(state.board), blockers: copyGrid(state.blockers), ...extra };
}

function shuffleBoard(state: GameState, level: Level, frames: Frame[]): void {
  const original = state.board.flat().filter((c): c is Candy => c !== null);
  for (let attempt = 0; attempt < 512; attempt++) {
    const pool = [...original];
    for (let i = pool.length - 1; i > 0; i--) {
      const j = randomInt(state, i + 1);
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }
    state.board = Array.from({ length: level.rows }, (_, r) =>
      pool.slice(r * level.cols, (r + 1) * level.cols),
    );
    if (!findMatches(state.board).length && findValidMoves(state.board).length) {
      frames.push(snapshot(state, 'shuffle'));
      return;
    }
  }
  // An impossible color distribution can have no legal permutation. Refill then
  // retain each special's effect; this bounded repair prevents a locked game.
  const specials = original.filter((c) => c.special !== 'none').map((c) => c.special);
  fillPlayable(state, level);
  specials.forEach((special, key) => {
    const [r, c] = position(key, level.cols);
    state.board[r][c]!.special = special;
  });
  frames.push(snapshot(state, 'shuffle'));
}

function creations(board: Board, runs: MatchRun[], preferred: number[]): Map<number, Special> {
  const cols = board[0].length,
    groups: { cells: Set<number>; runs: MatchRun[] }[] = [];
  for (const run of runs) {
    const intersecting = groups.filter((group) => run.cells.some((key) => group.cells.has(key)));
    const group = { cells: new Set(run.cells), runs: [run] };
    for (const old of intersecting) {
      old.cells.forEach((key) => group.cells.add(key));
      group.runs.push(...old.runs);
      groups.splice(groups.indexOf(old), 1);
    }
    groups.push(group);
  }
  groups.sort((a, b) => Math.min(...a.cells) - Math.min(...b.cells));
  const result = new Map<number, Special>();
  for (const group of groups) {
    const longest = [...group.runs].sort((a, b) => b.cells.length - a.cells.length)[0];
    const crossing = new Set(group.runs.map((run) => run.direction)).size > 1;
    if (longest.cells.length < 4 && !crossing) continue;
    const special: Special = longest.cells.length >= 5 || crossing ? 'color' : longest.direction;
    const candidates = sorted(group.cells).filter((key) => {
      const [r, c] = position(key, cols);
      return board[r][c]?.special === 'none';
    });
    if (!candidates.length) continue;
    const anchor =
      preferred.find((key) => candidates.includes(key)) ??
      candidates[Math.floor((candidates.length - 1) / 2)];
    result.set(anchor, special);
  }
  return result;
}

function mostCommonColor(board: Board): number {
  const counts = Array<number>(6).fill(0);
  for (const row of board) for (const candy of row) if (candy) counts[candy.color]++;
  let best = 0;
  for (let color = 1; color < counts.length; color++)
    if (counts[color] > counts[best]) best = color;
  return best;
}

function expandClear(
  state: GameState,
  initial: Set<number>,
  protectedCells: Set<number>,
  colorTargets: Map<number, number>,
): { clear: number[]; activated: number[] } {
  const rows = state.board.length,
    cols = state.board[0].length;
  const pending = new Set(initial),
    cleared = new Set<number>(),
    activated = new Set<number>();
  const add = (key: number): void => {
    if (!cleared.has(key) && !protectedCells.has(key)) pending.add(key);
  };
  while (pending.size) {
    const key = Math.min(...pending);
    pending.delete(key);
    if (cleared.has(key) || protectedCells.has(key)) continue;
    const [r, c] = position(key, cols),
      candy = state.board[r][c];
    if (!candy) continue;
    cleared.add(key);
    if (candy.special === 'none' || activated.has(key)) continue;
    activated.add(key);
    if (candy.special === 'row') for (let cc = 0; cc < cols; cc++) add(r * cols + cc);
    else if (candy.special === 'column') for (let rr = 0; rr < rows; rr++) add(rr * cols + c);
    else {
      const color = colorTargets.get(key) ?? mostCommonColor(state.board);
      for (let rr = 0; rr < rows; rr++)
        for (let cc = 0; cc < cols; cc++) {
          const target = state.board[rr][cc];
          if (target && (color === -1 || target.color === color)) add(rr * cols + cc);
        }
    }
  }
  return { clear: sorted(cleared), activated: sorted(activated) };
}

function gravity(state: GameState, level: Level): void {
  for (let c = 0; c < level.cols; c++) {
    let write = level.rows - 1;
    for (let r = level.rows - 1; r >= 0; r--) {
      const candy = state.board[r][c];
      if (candy) {
        state.board[write][c] = candy;
        write--;
      }
    }
    while (write >= 0) {
      state.board[write][c] = newCandy(state, randomInt(state, level.colors));
      write--;
    }
  }
}

function resolve(
  state: GameState,
  level: Level,
  frames: Frame[],
  forced: number[] = [],
  preferred: number[] = [],
  targets = new Map<number, number>(),
): void {
  for (let combo = 1; combo <= MAX_CASCADES; combo++) {
    const runs = matchRuns(state.board);
    if (!runs.length && !forced.length) return;
    const created = creations(state.board, runs, combo === 1 ? preferred : []);
    // Directly selected power/combo candies must activate, never become anchors.
    for (const key of forced) created.delete(key);
    const initial = new Set([...forced, ...runs.flatMap((run) => run.cells)]);
    const effect = expandClear(state, initial, new Set(created.keys()), targets);
    if (effect.activated.length)
      frames.push(
        snapshot(state, 'special', {
          cells: effect.clear.map((key) => position(key, level.cols)),
          combo,
        }),
      );
    for (const key of effect.clear) {
      const [r, c] = position(key, level.cols),
        candy = state.board[r][c]!;
      state.collected[candy.color]++;
      if (state.blockers[r][c] > 0) state.blockers[r][c]--;
      state.board[r][c] = null;
    }
    for (const [key, special] of created) {
      const [r, c] = position(key, level.cols);
      if (state.board[r][c]) state.board[r][c] = { ...state.board[r][c]!, special };
    }
    const size = effect.clear.length;
    const scoreDelta = (size * 60 + Math.max(0, size - 3) * 20) * Math.min(combo, 8);
    state.score += scoreDelta;
    frames.push(
      snapshot(state, 'clear', {
        cells: effect.clear.map((key) => position(key, level.cols)),
        scoreDelta,
        combo,
      }),
    );
    gravity(state, level);
    frames.push(snapshot(state, 'fall', { combo }));
    forced = [];
    targets = new Map();
  }
  if (findMatches(state.board).length) shuffleBoard(state, level, frames);
}

function evaluate(state: GameState, level: Level): void {
  const won =
    state.score >= level.target &&
    level.collections.every((goal) => state.collected[goal.color] >= goal.count) &&
    state.blockers.every((row) => row.every((hp) => hp === 0));
  state.status = won ? 'won' : state.movesLeft <= 0 ? 'lost' : 'playing';
}

export function getStars(state: GameState, level: Level): number {
  if (state.status !== 'won') return 0;
  return Math.max(1, level.starThresholds.filter((threshold) => state.score >= threshold).length);
}

function validPosition(at: unknown, state: GameState): at is Position {
  return (
    Array.isArray(at) &&
    at.length === 2 &&
    Number.isInteger(at[0]) &&
    Number.isInteger(at[1]) &&
    at[0] >= 0 &&
    at[0] < state.board.length &&
    at[1] >= 0 &&
    at[1] < state.board[0].length
  );
}

export function applyAction(original: GameState, action: Action, level: Level): ActionResult {
  const reject = (message: string): ActionResult => ({
    accepted: false,
    state: original,
    frames: [],
    message,
  });
  if (!action || typeof action !== 'object') return reject('Geçersiz işlem.');
  if (original.levelId !== level.id) return reject('Bölüm uyuşmuyor.');
  if (original.status === 'won') return reject('Bu bölüm tamamlandı.');
  if (original.status === 'lost' && action.kind !== 'extra') return reject('Hamlelerin bitti.');
  const state = cloneState(original),
    frames: Frame[] = [];
  if (action.kind === 'extra') {
    if (state.powers.extra <= 0) return reject('Ek hamle hakkını kullandın.');
    state.powers.extra--;
    state.movesLeft += 5;
  } else if (action.kind === 'shuffle') {
    if (state.powers.shuffle <= 0) return reject('Karıştırma hakkını kullandın.');
    state.powers.shuffle--;
    shuffleBoard(state, level, frames);
  } else if (action.kind === 'hammer') {
    if (state.powers.hammer <= 0) return reject('Çekiç hakkını kullandın.');
    if (!validPosition(action.at, state)) return reject('Geçersiz hücre.');
    const [r, c] = action.at;
    if (!state.board[r][c]) return reject('Bu hücre boş.');
    state.powers.hammer--;
    resolve(state, level, frames, [r * level.cols + c]);
  } else if (action.kind === 'swap') {
    if (!validPosition(action.from, state) || !validPosition(action.to, state))
      return reject('Geçersiz hücre.');
    const [r, c] = action.from,
      [rr, cc] = action.to;
    if (Math.abs(r - rr) + Math.abs(c - cc) !== 1)
      return reject('Yalnızca yan yana şekerler yer değiştirebilir.');
    const a = state.board[r][c],
      b = state.board[rr][cc];
    if (!a || !b) return reject('Bu hücre boş.');
    state.board[r][c] = b;
    state.board[rr][cc] = a;
    const comboSwap = specialSwap(a, b);
    if (!comboSwap && !lineAt(state.board, action.from) && !lineAt(state.board, action.to))
      return reject('En az üç aynı renk şeker eşleştir.');
    state.movesLeft--;
    frames.push(snapshot(state, 'swap', { from: [...action.from], to: [...action.to] }));
    const first = r * level.cols + c,
      second = rr * level.cols + cc;
    const forced: number[] = [],
      targets = new Map<number, number>();
    if (comboSwap) {
      forced.push(first, second);
      if (a.special === 'color' && b.special === 'color') {
        targets.set(first, -1);
        targets.set(second, -1);
      } else if (a.special === 'color' || b.special === 'color') {
        const bombKey = a.special === 'color' ? second : first;
        const partner = a.special === 'color' ? b : a;
        targets.set(bombKey, partner.color);
        for (let row = 0; row < level.rows; row++)
          for (let col = 0; col < level.cols; col++) {
            const candy = state.board[row][col];
            if (candy?.color !== partner.color) continue;
            forced.push(row * level.cols + col);
            if (
              partner.special !== 'none' &&
              partner.special !== 'color' &&
              candy.special !== 'color'
            )
              candy.special = partner.special;
          }
      }
    }
    resolve(state, level, frames, forced, [second, first], targets);
  } else return reject('Geçersiz işlem.');
  state.turn++;
  if (findMatches(state.board).length || !findValidMoves(state.board).length)
    shuffleBoard(state, level, frames);
  evaluate(state, level);
  return { accepted: true, state, frames };
}
