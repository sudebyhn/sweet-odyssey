import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  CloudUpload,
  CloudOff,
  Crown,
  Flag,
  Hammer,
  HelpCircle,
  Layers3,
  LoaderCircle,
  LockKeyhole,
  Map as MapIcon,
  Music2,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Settings2,
  Shuffle,
  Sparkles,
  Star,
  Target,
  Trophy,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import levelData from '../../shared/levels.json';
import {
  createGame,
  applyAction,
  getStars,
  type Action,
  type ActionResult,
  type GameState,
  type Level,
} from './game/engine';
import { api, type Player, type Progress } from './services/api';
import { CandyBoard, CANDY_NAMES } from './components/CandyBoard';
import { Modal } from './components/Modal';
import type { CandyScene } from './game/CandyScene';
import { soundscape } from './audio';

const LEVELS = levelData as Level[];
const INITIAL_PROGRESS: Progress = { unlockedLevel: 1, completed: {}, totalStars: 0 };
const KEYS = {
  profile: 'sweet-odyssey-profile-v1',
  local: 'sweet-odyssey-local-progress-v1',
  name: 'sweet-odyssey-local-name-v1',
  settings: 'sweet-odyssey-settings-v1',
  tutorial: 'sweet-odyssey-tutorial-v1',
  pending: 'sweet-odyssey-pending-v1',
};
const number = (value: number) => value.toLocaleString('tr-TR');
type Settings = { sound: boolean; music: boolean; reducedMotion: boolean };
type Session = {
  mode: 'loading' | 'remote' | 'local';
  token: string | null;
  player: Player;
  progress: Progress;
};
type Attempt = {
  key: number;
  runId: string | null;
  token: string | null;
  level: Level;
  state: GameState;
  actions: Action[];
  remote: boolean;
};
type Pending = { token: string; runId: string; actions: Action[] };
type SaveState = { kind: 'idle' | 'saving' | 'saved' | 'error'; message: string };

function read<T>(key: string, fallback: T): T {
  try {
    return JSON.parse(localStorage.getItem(key) || 'null') ?? fallback;
  } catch {
    return fallback;
  }
}
function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}
function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : 'Bağlantı kurulamadı. Lütfen tekrar dene.';
}
function canFallback(error: unknown) {
  const status = (error as { status?: number })?.status;
  return !status || status >= 500;
}
function frosting(state: GameState) {
  return state.blockers.flat().reduce((sum, layers) => sum + layers, 0);
}
function readName(): string {
  const value = read<unknown>(KEYS.name, 'Tatlı Gezgin');
  return typeof value === 'string' && value.trim().length >= 2
    ? value.trim().slice(0, 20)
    : 'Tatlı Gezgin';
}
function readProfile(): { token: string; player: Player } | null {
  const value = read<{ token?: unknown; player?: Partial<Player> } | null>(KEYS.profile, null);
  return value &&
    typeof value.token === 'string' &&
    typeof value.player?.id === 'string' &&
    typeof value.player?.nickname === 'string'
    ? { token: value.token, player: value.player as Player }
    : null;
}
function readPending(): Pending[] {
  const values = read<unknown>(KEYS.pending, []);
  return Array.isArray(values)
    ? values.filter(
        (item): item is Pending =>
          !!item &&
          typeof item.token === 'string' &&
          typeof item.runId === 'string' &&
          Array.isArray(item.actions),
      )
    : [];
}
function initialSettings(): Settings {
  return {
    sound: true,
    music: false,
    reducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    ...read<Partial<Settings>>(KEYS.settings, {}),
  };
}
function normalProgress(raw: Progress | null): Progress {
  if (!raw || !raw.completed || Array.isArray(raw.completed) || typeof raw.completed !== 'object')
    return { ...INITIAL_PROGRESS };
  const completed: Progress['completed'] = {};
  for (const [id, result] of Object.entries(raw.completed))
    if (
      result &&
      typeof result === 'object' &&
      Number(id) >= 1 &&
      Number(id) <= LEVELS.length &&
      Number.isFinite(result.score) &&
      Number.isFinite(result.stars)
    )
      completed[id] = {
        score: Math.max(0, result.score),
        stars: Math.max(0, Math.min(3, result.stars)),
      };
  return {
    unlockedLevel: Math.max(1, Math.min(LEVELS.length, Math.floor(raw.unlockedLevel || 1))),
    completed,
    totalStars: Object.values(completed).reduce((sum, item) => sum + item.stars, 0),
  };
}

declare global {
  interface Window {
    __SWEET_GAME__?: {
      readonly state: GameState | null;
      readonly level: Level | null;
      readonly busy: boolean;
      action: (action: Action) => Promise<ActionResult | null>;
    };
  }
}

function Stars({ count, className = '' }: { count: number; className?: string }) {
  return (
    <span className={`stars ${className}`} aria-label={`${count} yıldız`}>
      {[1, 2, 3].map((n) => (
        <Star
          key={n}
          className={n <= count ? 'star-earned' : 'star-empty'}
          fill={n <= count ? 'currentColor' : 'none'}
          strokeWidth={1.8}
        />
      ))}
    </span>
  );
}

function IconButton({
  label,
  children,
  onClick,
  testId,
  disabled,
}: {
  label: string;
  children: ReactNode;
  onClick: () => void;
  testId?: string;
  disabled?: boolean;
}) {
  return (
    <button
      className="icon-button"
      aria-label={label}
      title={label}
      onClick={onClick}
      data-testid={testId}
      disabled={disabled}
    >
      {children}
    </button>
  );
}

export default function App() {
  const [screen, setScreen] = useState<'welcome' | 'map' | 'game'>('welcome');
  const [settings, setSettings] = useState<Settings>(initialSettings);
  const [session, setSession] = useState<Session>({
    mode: 'loading',
    token: null,
    player: { id: '', nickname: readName() },
    progress: { ...INITIAL_PROGRESS },
  });
  const sessionRef = useRef(session);
  sessionRef.current = session;
  const [selectedLevel, setSelectedLevel] = useState<Level | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [tutorialOpen, setTutorialOpen] = useState(false);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [paused, setPaused] = useState(false);
  const [starting, setStarting] = useState(false);
  const [attempt, setAttempt] = useState<Attempt | null>(null);
  const attemptRef = useRef(attempt);
  attemptRef.current = attempt;
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const sceneRef = useRef<CandyScene | null>(null);
  const [sceneReady, setSceneReady] = useState(false);
  const [hammerMode, setHammerMode] = useState(false);
  const [save, setSave] = useState<SaveState>({ kind: 'idle', message: '' });
  const [pending, setPending] = useState<Pending[]>(readPending);
  const pendingRef = useRef(pending);
  pendingRef.current = pending;
  const savesInFlight = useRef(new Map<string, Promise<boolean>>());
  const [retryingPending, setRetryingPending] = useState(false);
  const [toast, setToast] = useState('');
  const [nicknameDraft, setNicknameDraft] = useState('');
  const [nameSaving, setNameSaving] = useState(false);
  const [nameError, setNameError] = useState('');
  const nextKey = useRef(0);
  const blockedRef = useRef(false);
  blockedRef.current = paused || settingsOpen || tutorialOpen || starting;
  const actionRef = useRef<(action: Action) => Promise<ActionResult | null>>(async () => null);

  const notify = useCallback((message: string) => {
    setToast(message);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(''), 5600);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    write(KEYS.settings, settings);
    soundscape.setSettings(settings.sound, settings.music);
    document.documentElement.classList.toggle('reduce-motion', settings.reducedMotion);
  }, [settings]);
  useEffect(() => {
    const unlock = () => soundscape.unlock();
    document.addEventListener('pointerdown', unlock, { passive: true });
    document.addEventListener('keydown', unlock);
    return () => {
      document.removeEventListener('pointerdown', unlock);
      document.removeEventListener('keydown', unlock);
    };
  }, []);

  useEffect(() => {
    let active = true;
    async function connect() {
      const stored = readProfile();
      try {
        let profile: { token: string; player: Player; progress: Progress };
        if (stored?.token) {
          try {
            profile = { ...stored, progress: await api.progress(stored.token) };
          } catch (error) {
            if ((error as { status?: number }).status === 401)
              profile = await api.createPlayer(readName());
            else throw error;
          }
        } else profile = await api.createPlayer(readName());
        if (!active) return;
        write(KEYS.profile, { token: profile.token, player: profile.player });
        setSession({
          mode: 'remote',
          token: profile.token,
          player: profile.player,
          progress: normalProgress(profile.progress),
        });
      } catch (error) {
        if (!active) return;
        if (!canFallback(error)) notify(errorMessage(error));
        setSession({
          mode: 'local',
          token: null,
          player: { id: 'local', nickname: readName() },
          progress: normalProgress(read(KEYS.local, null)),
        });
      }
    }
    void connect();
    return () => {
      active = false;
    };
  }, [notify]);

  useEffect(() => {
    if (!(import.meta.env.DEV || import.meta.env.VITE_TEST_MODE === '1')) return;
    window.__SWEET_GAME__ = {
      get state() {
        return attemptRef.current?.state || null;
      },
      get level() {
        return attemptRef.current?.level || null;
      },
      get busy() {
        return busyRef.current || blockedRef.current || !sceneRef.current;
      },
      action: (action: Action) => actionRef.current(action),
    };
    return () => {
      delete window.__SWEET_GAME__;
    };
  }, []);

  useEffect(() => {
    if (screen !== 'map') return;
    const timer = setTimeout(
      () =>
        document
          .querySelector(`[data-testid="level-${sessionRef.current.progress.unlockedLevel}"]`)
          ?.scrollIntoView({ block: 'center', behavior: 'instant' }),
      80,
    );
    return () => clearTimeout(timer);
  }, [screen]);

  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (
        event.key === 'Escape' &&
        screen === 'game' &&
        !settingsOpen &&
        !tutorialOpen &&
        !busyRef.current &&
        attemptRef.current?.state.status === 'playing'
      )
        setPaused((value) => !value);
    };
    document.addEventListener('keydown', key);
    return () => document.removeEventListener('keydown', key);
  }, [screen, settingsOpen, tutorialOpen]);

  function updatePending(items: Pending[]) {
    pendingRef.current = items;
    setPending(items);
    write(KEYS.pending, items);
  }

  function updateRemoteProgress(progress: Progress, token: string) {
    if (sessionRef.current.token !== token) return;
    setSession((previous) => {
      const next = normalProgress(progress);
      // Network responses can arrive out of order; previously confirmed wins stay confirmed.
      for (const [id, result] of Object.entries(previous.progress.completed)) {
        const incoming = next.completed[id];
        next.completed[id] = {
          score: Math.max(result.score, incoming?.score || 0),
          stars: Math.max(result.stars, incoming?.stars || 0),
        };
      }
      next.unlockedLevel = Math.max(previous.progress.unlockedLevel, next.unlockedLevel);
      next.totalStars = Object.values(next.completed).reduce(
        (sum, result) => sum + result.stars,
        0,
      );
      return { ...previous, progress: next };
    });
  }

  async function submitPending(item: Pending, visible = true): Promise<boolean> {
    const existing = savesInFlight.current.get(item.runId);
    if (existing) return existing;
    const isCurrent = () => attemptRef.current?.runId === item.runId;
    if (visible && isCurrent()) setSave({ kind: 'saving', message: 'Tatlı başarın kaydediliyor…' });
    const operation = (async () => {
      try {
        const result = await api.finishRun(item.token, item.runId, item.actions);
        updateRemoteProgress(result.progress, item.token);
        updatePending(pendingRef.current.filter((p) => p.runId !== item.runId));
        if (isCurrent())
          setSave({
            kind: 'saved',
            message: result.status === 'won' ? 'İlerlemen kaydedildi.' : 'Denemen kaydedildi.',
          });
        return true;
      } catch (error) {
        if (isCurrent())
          setSave({
            kind: 'error',
            message: 'Sonucun henüz kaydedilemedi. Bağlantını kontrol edip tekrar dene.',
          });
        else if (visible) notify(`Sonucun kaydedilemedi: ${errorMessage(error)}`);
        return false;
      } finally {
        savesInFlight.current.delete(item.runId);
      }
    })();
    savesInFlight.current.set(item.runId, operation);
    return operation;
  }

  async function saveAttempt(current: Attempt, visible = true) {
    if (current.state.status === 'playing') return true;
    if (current.remote && current.token && current.runId) {
      const item: Pending = {
        token: current.token,
        runId: current.runId,
        actions: current.actions,
      };
      if (!pendingRef.current.some((p) => p.runId === item.runId))
        updatePending([...pendingRef.current, item]);
      return submitPending(item, visible);
    }
    if (current.state.status === 'won') {
      const stars = getStars(current.state, current.level);
      const progress = normalProgress(sessionRef.current.progress);
      const previous = progress.completed[String(current.level.id)];
      progress.completed[String(current.level.id)] = {
        score: Math.max(previous?.score || 0, current.state.score),
        stars: Math.max(previous?.stars || 0, stars),
      };
      progress.unlockedLevel = Math.max(
        progress.unlockedLevel,
        Math.min(LEVELS.length, current.level.id + 1),
      );
      progress.totalStars = Object.values(progress.completed).reduce(
        (sum, item) => sum + item.stars,
        0,
      );
      const stored = write(KEYS.local, progress);
      sessionRef.current = { ...sessionRef.current, progress };
      setSession(sessionRef.current);
      setSave(
        stored
          ? { kind: 'saved', message: 'İlerlemen bu tarayıcıya kaydedildi.' }
          : {
              kind: 'error',
              message: 'Tarayıcı depolaması kullanılamıyor. Bu pencere açıkken devam edebilirsin.',
            },
      );
      return stored;
    }
    return true;
  }

  async function retryPending() {
    if (retryingPending) return;
    setRetryingPending(true);
    let failures = 0;
    for (const item of pendingRef.current.filter((p) => p.token === sessionRef.current.token))
      if (!(await submitPending(item, false))) failures++;
    setRetryingPending(false);
    notify(
      failures
        ? 'Bazı sonuçlar hâlâ kaydedilemiyor. Daha sonra yeniden deneyebilirsin.'
        : 'Bekleyen sonuçların kaydedildi. Yolculuğa devam!',
    );
  }

  async function startLevel(level: Level) {
    if (starting || level.id > sessionRef.current.progress.unlockedLevel) return;
    setStarting(true);
    soundscape.play('tap');
    let remote = sessionRef.current.mode === 'remote';
    let token = sessionRef.current.token;
    let runId: string | null = null;
    let seed = crypto.getRandomValues(new Uint32Array(1))[0] || 1;
    let actualLevel = level;
    try {
      if (remote && token) {
        try {
          const run = await api.startRun(token, level.id);
          seed = run.seed;
          runId = run.id;
          actualLevel = run.level;
        } catch (error) {
          if (!canFallback(error)) throw error;
          remote = false;
          token = null;
          const current = sessionRef.current;
          const localSession: Session = {
            ...current,
            mode: 'local',
            token: null,
            progress: normalProgress(current.progress),
          };
          sessionRef.current = localSession;
          setSession(localSession);
          write(KEYS.local, localSession.progress);
          notify('Bağlantı yok. Bu oyunun ilerlemesi bu tarayıcıya kaydedilecek.');
        }
      }
      const gameState = createGame(actualLevel, seed);
      const next: Attempt = {
        key: ++nextKey.current,
        runId,
        token,
        level: actualLevel,
        state: gameState,
        actions: [],
        remote,
      };
      attemptRef.current = next;
      setAttempt(next);
      setSave({ kind: 'idle', message: '' });
      setSceneReady(false);
      setSelectedLevel(null);
      setPaused(false);
      setHammerMode(false);
      setScreen('game');
      window.scrollTo({ top: 0, behavior: 'instant' });
      if (!read(KEYS.tutorial, false)) {
        setTutorialStep(0);
        setTutorialOpen(true);
      }
    } catch (error) {
      notify(errorMessage(error));
    } finally {
      setStarting(false);
    }
  }

  async function performAction(action: Action): Promise<ActionResult | null> {
    const current = attemptRef.current;
    if (!current || busyRef.current || blockedRef.current || !sceneRef.current) return null;
    if (
      current.state.status !== 'playing' &&
      !(current.state.status === 'lost' && action.kind === 'extra')
    )
      return null;
    busyRef.current = true;
    setBusy(true);
    try {
      const result = applyAction(current.state, action, current.level);
      if (!result.accepted) {
        if (action.kind === 'swap') await sceneRef.current.invalidSwap(action.from, action.to);
        if (action.kind !== 'swap') notify(result.message || 'Bu gücü şu anda kullanamazsın.');
        return result;
      }
      setHammerMode(false);
      soundscape.play(action.kind === 'swap' ? 'swap' : 'power');
      await sceneRef.current.playFrames(result.frames, result.state);
      if (attemptRef.current?.key !== current.key) return result;
      const next: Attempt = {
        ...current,
        state: result.state,
        actions: [...current.actions, action],
      };
      attemptRef.current = next;
      setAttempt(next);
      if (result.state.status === 'won') {
        soundscape.play('win');
        void saveAttempt(next);
      } else if (result.state.status === 'lost') soundscape.play('lose');
      else if (action.kind === 'extra') setSave({ kind: 'idle', message: '' });
      return result;
    } catch (error) {
      notify(`Hamle tamamlanamadı. ${errorMessage(error)}`);
      return null;
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }
  actionRef.current = performAction;

  function leaveGame(destination: 'map' | 'welcome') {
    if (busyRef.current) return;
    const current = attemptRef.current;
    if (current?.state.status === 'lost') void saveAttempt(current, false);
    setPaused(false);
    setHammerMode(false);
    setScreen(destination);
    setAttempt(null);
    attemptRef.current = null;
  }

  function retryLevel() {
    const current = attemptRef.current;
    if (!current || starting) return;
    if (current.state.status === 'lost') void saveAttempt(current, false);
    void startLevel(current.level);
  }

  function openSettings() {
    setNicknameDraft(session.player.nickname);
    setNameError('');
    setSettingsOpen(true);
    soundscape.play('tap');
  }
  function openTutorial() {
    setTutorialStep(0);
    setTutorialOpen(true);
  }
  function closeTutorial() {
    write(KEYS.tutorial, true);
    setTutorialOpen(false);
    soundscape.play('tap');
  }
  async function saveNickname() {
    const nickname = nicknameDraft.trim();
    if (nickname.length < 2 || nickname.length > 20) {
      setNameError('Gezgin adın 2–20 karakter arasında olsun.');
      return;
    }
    setNameSaving(true);
    setNameError('');
    try {
      const player =
        session.mode === 'remote' && session.token
          ? await api.rename(session.token, nickname)
          : { ...session.player, nickname };
      setSession((previous) => ({ ...previous, player }));
      if (session.token) write(KEYS.profile, { token: session.token, player });
      write(KEYS.name, nickname);
      notify('Gezgin adın güncellendi.');
    } catch (error) {
      setNameError(errorMessage(error));
    } finally {
      setNameSaving(false);
    }
  }

  const finished = attempt && attempt.state.status !== 'playing';
  const pendingForPlayer = pending.filter((item) => item.token === session.token);
  const completedCount = Object.keys(session.progress.completed).length;

  return (
    <div className={`app screen-${screen}`}>
      <div className="ambient-grain" aria-hidden="true" />
      <header className={`topbar ${screen === 'game' ? 'topbar-game' : ''}`}>
        <button
          className="brand"
          disabled={screen === 'game' && busy}
          onClick={() =>
            screen === 'game'
              ? setPaused(true)
              : (setScreen('welcome'), window.scrollTo({ top: 0 }))
          }
          aria-label="Sweet Odyssey ana ekranı"
        >
          <img src="/assets/logo-mark.svg" alt="" />
          <span>
            SWEET <em>ODYSSEY</em>
          </span>
        </button>
        <div className="topbar-right">
          {screen !== 'welcome' && (
            <div className="star-wallet" title="Topladığın toplam yıldız">
              <Star size={17} fill="currentColor" />
              <b>{session.progress.totalStars}</b>
              <span> / 60</span>
            </div>
          )}
          <span
            className={`connection-status ${session.mode}`}
            title={
              session.mode === 'local'
                ? 'Yerel mod: ilerleme yalnızca bu tarayıcıda saklanır.'
                : 'Bölüm sonuçları oyun sunucusunda doğrulanarak kaydedilir.'
            }
          >
            {session.mode === 'loading' ? (
              <LoaderCircle size={13} className="spin" />
            ) : session.mode === 'remote' ? (
              <CloudUpload size={14} />
            ) : (
              <CloudOff size={14} />
            )}
            <span>
              {session.mode === 'loading'
                ? 'Hazırlanıyor'
                : session.mode === 'remote'
                  ? 'Kayıt açık'
                  : 'Yerel kayıt'}
            </span>
          </span>
          <IconButton
            label={settings.sound ? 'Ses efektlerini kapat' : 'Ses efektlerini aç'}
            onClick={() => setSettings((s) => ({ ...s, sound: !s.sound }))}
          >
            {settings.sound ? <Volume2 size={19} /> : <VolumeX size={19} />}
          </IconButton>
          <IconButton label="Ayarlar" onClick={openSettings}>
            <Settings2 size={19} />
          </IconButton>
        </div>
      </header>

      <AnimatePresence mode="wait">
        {screen === 'welcome' && (
          <motion.main
            key="welcome"
            className="welcome"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: settings.reducedMotion ? 0 : 0.3 }}
          >
            <img
              className="welcome-world"
              src="/assets/world.svg"
              alt="Şeker ağaçları, yumuşak bulutlar ve büyülü bir şatoyla çevrili tatlı bir ada"
            />
            <div className="welcome-shade" />
            <div className="hero-content">
              <div className="eyebrow hero-eyebrow">
                <span /> BİR TUTAM SİHİR, BOLCA EĞLENCE
              </div>
              <h1>
                <span>SWEET</span>
                <em>ODYSSEY</em>
                <Sparkles className="hero-sparkle" />
              </h1>
              <p className="hero-subtitle">
                Tatlı bir maceraya
                <br />
                hazır mısın?
              </p>
              <p className="hero-description">
                Renkleri eşleştir, küçük mucizeler yarat.
                <br />
                Şeker diyarında her hamle yeni bir keşif.
              </p>
              <div className="hero-actions">
                <button
                  className="primary-button hero-play"
                  data-testid={completedCount ? 'continue-button' : 'play-button'}
                  disabled={session.mode === 'loading'}
                  onClick={() => {
                    soundscape.play('tap');
                    setScreen('map');
                  }}
                >
                  {session.mode === 'loading' ? (
                    <LoaderCircle className="spin" size={21} />
                  ) : (
                    <Play size={22} fill="currentColor" />
                  )}{' '}
                  {completedCount ? 'DEVAM ET' : 'OYNA'} <ArrowRight size={22} />
                </button>
                <button className="text-button tutorial-link" onClick={openTutorial}>
                  <HelpCircle size={17} /> Nasıl oynanır?
                </button>
              </div>
              <div className="hero-facts">
                <span>
                  <MapIcon size={16} />
                  20 bölüm
                </span>
                <i />
                <span>
                  <Sparkles size={16} />3 tatlı güç
                </span>
                <i />
                <span>
                  <Star size={16} />
                  Senin maceran
                </span>
              </div>
            </div>
            <div className="floating-candy candy-float-one" aria-hidden="true">
              <img src="/assets/candy-0.svg" alt="" />
            </div>
            <div className="floating-candy candy-float-two" aria-hidden="true">
              <img src="/assets/candy-3.svg" alt="" />
            </div>
            <div className="island-caption">
              <span className="tiny-spark">✦</span>
              <div>
                Şeker Kıyısı<small>Yolculuğun burada başlıyor</small>
              </div>
              <span className="caption-line" />
            </div>
            <footer className="welcome-footer">
              <span>KENDİ HIZINDA OYNA. KEYFİNİ ÇIKAR.</span>
              <span>
                Bir eşleşmeyle başlar <span className="footer-star">✧</span>
              </span>
            </footer>
          </motion.main>
        )}

        {screen === 'map' && (
          <motion.main
            key="map"
            className="map-page"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <div className="map-intro">
              <div>
                <span className="eyebrow">
                  MERHABA, {session.player.nickname.toLocaleUpperCase('tr-TR')}
                </span>
                <h1>
                  Senin tatlı <em>yolculuğun.</em>
                </h1>
                <p>
                  {completedCount === 20
                    ? 'Tüm adaları keşfettin. Daha fazla yıldız için yeniden oyna!'
                    : 'Her bölüm, keşfedilecek yeni bir lezzet.'}
                </p>
              </div>
              <div className="map-completion">
                <Flag size={19} />
                <b>
                  {completedCount}
                  <small> / 20</small>
                </b>
                <span>bölüm tamamlandı</span>
              </div>
            </div>
            {pendingForPlayer.length > 0 && (
              <div className="pending-banner">
                <CloudOff size={18} />
                <span>{pendingForPlayer.length} bölüm sonucu kaydedilmeyi bekliyor.</span>
                <button onClick={() => void retryPending()} disabled={retryingPending}>
                  {retryingPending ? 'Kaydediliyor…' : 'Tekrar dene'} <RotateCcw size={14} />
                </button>
              </div>
            )}
            <JourneyMap
              progress={session.progress}
              reduced={settings.reducedMotion}
              onLevel={(level) => {
                soundscape.play('tap');
                setSelectedLevel(level);
              }}
            />
            <button
              className="map-jump"
              onClick={() =>
                document
                  .querySelector(`[data-testid="level-${session.progress.unlockedLevel}"]`)
                  ?.scrollIntoView({
                    block: 'center',
                    behavior: settings.reducedMotion ? 'instant' : 'smooth',
                  })
              }
            >
              <Flag size={15} />
              Bölümüme git <ArrowDown size={14} />
            </button>
          </motion.main>
        )}

        {screen === 'game' && attempt && (
          <motion.main
            key="game"
            className="game-page"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <div className="game-heading">
              <button
                className="back-link"
                data-testid="map-button"
                onClick={() => setPaused(true)}
                disabled={busy}
              >
                <ArrowLeft size={17} />
                <span>Yolculuğum</span>
              </button>
              <div>
                <span className="eyebrow">
                  {attempt.level.realm} <i>·</i> BÖLÜM {String(attempt.level.id).padStart(2, '0')}
                </span>
                <h1>{attempt.level.name}</h1>
              </div>
              <IconButton
                label="Oyunu duraklat"
                testId="pause-button"
                onClick={() => setPaused(true)}
                disabled={busy}
              >
                <Pause size={19} fill="currentColor" />
              </IconButton>
            </div>
            <div className="game-layout">
              <aside className="objectives-panel">
                <div className="panel-kicker">
                  <Target size={16} /> TATLI HEDEFLERİN
                </div>
                <h2>
                  Biraz eşleştir,
                  <br />
                  <em>çokça mutlu ol.</em>
                </h2>
                <ObjectiveList level={attempt.level} state={attempt.state} />
                <p className="goal-note">Hamlelerin bitmeden bütün hedefleri tamamla.</p>
                <div className="level-flower" aria-hidden="true">
                  <img src="/assets/candy-5.svg" alt="" />
                  <span>
                    Her hamle
                    <br />
                    bir fırsat.
                  </span>
                </div>
              </aside>
              <div className="board-column">
                <div className="game-hud">
                  <div
                    className={`moves-counter ${attempt.state.movesLeft <= 5 ? 'moves-low' : ''}`}
                  >
                    <span data-testid="moves">{attempt.state.movesLeft}</span>
                    <small>HAMLE</small>
                  </div>
                  <div className="score-area">
                    <div className="score-title">
                      <span>PUANIN</span>
                      <strong data-testid="score">{number(attempt.state.score)}</strong>
                    </div>
                    <div className="score-track">
                      <div
                        className="score-fill"
                        style={{
                          width: `${Math.min(100, (attempt.state.score / attempt.level.starThresholds[2]) * 100)}%`,
                        }}
                      />
                      {attempt.level.starThresholds.map((threshold, i) => (
                        <Star
                          key={threshold}
                          size={18}
                          className={attempt.state.score >= threshold ? 'earned' : ''}
                          fill="currentColor"
                          style={{
                            left: `${(threshold / attempt.level.starThresholds[2]) * 100}%`,
                          }}
                          aria-label={`${i + 1} yıldız: ${number(threshold)} puan`}
                        />
                      ))}
                    </div>
                    <div className="score-goal">
                      <span>Hedef: {number(attempt.level.target)}</span>
                      {attempt.state.score >= attempt.level.target && <Check size={14} />}
                    </div>
                  </div>
                </div>
                <CandyBoard
                  attemptKey={attempt.key}
                  state={attempt.state}
                  locked={
                    busy ||
                    paused ||
                    tutorialOpen ||
                    settingsOpen ||
                    attempt.state.status !== 'playing'
                  }
                  hammer={hammerMode}
                  reduced={settings.reducedMotion}
                  onAction={(action) => void performAction(action)}
                  onScene={(scene) => {
                    sceneRef.current = scene;
                    setSceneReady(Boolean(scene));
                  }}
                  onClear={() => soundscape.play('clear')}
                />
                <p
                  className={`board-instruction ${hammerMode ? 'instruction-active' : ''}`}
                  aria-live="polite"
                >
                  {!sceneReady ? (
                    <>
                      <LoaderCircle size={14} className="spin" /> Şekerler yerlerini alıyor…
                    </>
                  ) : hammerMode ? (
                    <>
                      <Hammer size={15} /> Kırmak istediğin şekere dokun. Vazgeçmek için çekice
                      tekrar bas.
                    </>
                  ) : busy ? (
                    <>
                      <Sparkles size={14} /> Tatlı bir zincirleme…
                    </>
                  ) : (
                    <>
                      <span className="instruction-dot" /> İki komşu şekeri seç veya birini kaydır.
                    </>
                  )}
                </p>
              </div>
              <aside className="powers-panel">
                <div className="panel-kicker">
                  <Sparkles size={16} /> BİR TUTAM SİHİR
                </div>
                <h2>Tatlı güçler</h2>
                <p>
                  Her denemede birer kez.
                  <br />
                  Tam zamanında kullan.
                </p>
                <div className="power-list">
                  <PowerButton
                    name="Şeker çekici"
                    description="Bir şekeri kır"
                    icon={<Hammer />}
                    count={attempt.state.powers.hammer}
                    active={hammerMode}
                    disabled={busy || attempt.state.status !== 'playing'}
                    onClick={() => {
                      soundscape.play('tap');
                      setHammerMode(!hammerMode);
                      sceneRef.current?.clearSelection();
                    }}
                  />
                  <PowerButton
                    name="Karıştır"
                    description="Yeni olasılıklar yarat"
                    icon={<Shuffle />}
                    count={attempt.state.powers.shuffle}
                    disabled={busy || attempt.state.status !== 'playing'}
                    onClick={() => void performAction({ kind: 'shuffle' })}
                  />
                  <PowerButton
                    name="+5 hamle"
                    description="Biraz daha şans"
                    icon={<Plus />}
                    count={attempt.state.powers.extra}
                    disabled={busy || attempt.state.status === 'won'}
                    onClick={() => void performAction({ kind: 'extra' })}
                  />
                </div>
                <button className="howto-inline" onClick={openTutorial}>
                  <HelpCircle size={16} /> Küçük bir hatırlatma
                </button>
                <div className="power-decoration" aria-hidden="true">
                  <img src="/assets/candy-3.svg" alt="" />
                  <Sparkles />
                </div>
              </aside>
            </div>
            <span data-testid="game-status" className="sr-only" aria-live="polite">
              {attempt.state.status}
            </span>
          </motion.main>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedLevel && (
          <Modal
            title={`Bölüm ${selectedLevel.id}: ${selectedLevel.name}`}
            onClose={starting ? undefined : () => setSelectedLevel(null)}
            reduced={settings.reducedMotion}
            className="level-modal"
          >
            <div className="modal-ornament">
              <img src={`/assets/candy-${(selectedLevel.id - 1) % 6}.svg`} alt="" />
              <span>✦</span>
              <span>✧</span>
            </div>
            <span className="eyebrow">
              {selectedLevel.realm} · BÖLÜM {selectedLevel.id}
            </span>
            <h2 className="modal-title">{selectedLevel.name}</h2>
            <p className="modal-description">{selectedLevel.description}</p>
            <Stars
              count={session.progress.completed[String(selectedLevel.id)]?.stars || 0}
              className="level-stars"
            />
            <div className="level-brief">
              <span>
                <RotateCcw size={17} />
                <b>{selectedLevel.moves}</b> hamle
              </span>
              <span>
                <Target size={17} />
                <b>{number(selectedLevel.target)}</b> puan
              </span>
            </div>
            {(selectedLevel.collections.length > 0 || selectedLevel.blockers.length > 0) && (
              <div className="level-collection-goals">
                {selectedLevel.collections.map((goal) => (
                  <span key={goal.color}>
                    <img src={`/assets/candy-${goal.color}.svg`} alt={CANDY_NAMES[goal.color]} />
                    {goal.count} adet
                  </span>
                ))}
                {selectedLevel.blockers.length > 0 && (
                  <span>
                    <Layers3 size={23} />
                    {selectedLevel.blockers.reduce((sum, item) => sum + item.hp, 0)} krema katmanı
                  </span>
                )}
              </div>
            )}
            {session.progress.completed[String(selectedLevel.id)] && (
              <p className="personal-best">
                <Trophy size={14} /> En iyi puanın:{' '}
                {number(session.progress.completed[String(selectedLevel.id)].score)}
              </p>
            )}
            <button
              className="primary-button wide"
              data-testid="start-level"
              onClick={() => void startLevel(selectedLevel)}
              disabled={starting}
            >
              {starting ? (
                <LoaderCircle className="spin" size={20} />
              ) : (
                <Play size={19} fill="currentColor" />
              )}
              {starting ? 'HAZIRLANIYOR…' : 'BAŞLAYALIM'}
              <ArrowRight size={20} />
            </button>
            <small className="level-difficulty">
              {selectedLevel.difficulty} · Bütün hedefleri tamamla
            </small>
          </Modal>
        )}

        {settingsOpen && (
          <Modal
            title="Ayarlar"
            onClose={() => setSettingsOpen(false)}
            reduced={settings.reducedMotion}
            className="settings-modal"
          >
            <span className="eyebrow">TAM SENİN SEVDİĞİN GİBİ</span>
            <h2 className="modal-title">Küçük ayarlar.</h2>
            <p className="modal-description">Macera senin, ritmi de öyle.</p>
            <div className="setting-rows">
              <SettingToggle
                icon={<Volume2 />}
                title="Ses efektleri"
                description="Her eşleşmeye tatlı bir ses"
                checked={settings.sound}
                onChange={() => setSettings((s) => ({ ...s, sound: !s.sound }))}
              />
              <SettingToggle
                icon={<Music2 />}
                title="Müzik"
                description="Yolculuğuna eşlik eden yumuşak notalar"
                checked={settings.music}
                onChange={() => setSettings((s) => ({ ...s, music: !s.music }))}
              />
              <SettingToggle
                icon={<Sparkles />}
                title="Hareketleri azalt"
                description="Daha sakin geçişler ve daha az efekt"
                checked={settings.reducedMotion}
                onChange={() => setSettings((s) => ({ ...s, reducedMotion: !s.reducedMotion }))}
              />
            </div>
            <div className="nickname-form">
              <label htmlFor="nickname">GEZGİN ADIN</label>
              <div>
                <input
                  id="nickname"
                  value={nicknameDraft}
                  maxLength={20}
                  onChange={(e) => setNicknameDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') void saveNickname();
                  }}
                  autoComplete="nickname"
                />
                <button
                  onClick={() => void saveNickname()}
                  disabled={nameSaving || nicknameDraft.trim() === session.player.nickname}
                >
                  {nameSaving ? <LoaderCircle size={18} className="spin" /> : <Check size={18} />}
                  <span>Kaydet</span>
                </button>
              </div>
              {nameError && (
                <p className="inline-error" role="alert">
                  {nameError}
                </p>
              )}
            </div>
            <div className="settings-storage">
              {session.mode === 'remote' ? <CloudUpload size={18} /> : <CloudOff size={18} />}
              <p>
                {session.mode === 'remote'
                  ? 'Bu tarayıcıdaki gezgin profilinle ilerlemen otomatik kaydedilir.'
                  : 'Yerel moddasın. İlerlemen yalnızca bu tarayıcıda saklanır.'}
                <small>
                  Tarayıcı verilerini silmek bu gezgin profiline erişimini kaldırabilir.
                </small>
              </p>
            </div>
          </Modal>
        )}

        {tutorialOpen && (
          <Modal
            title="Nasıl oynanır?"
            onClose={closeTutorial}
            reduced={settings.reducedMotion}
            className="tutorial-modal"
          >
            <span className="eyebrow">KÜÇÜK BİR TATLI REHBER</span>
            <div className="tutorial-art" aria-hidden="true">
              {tutorialStep === 0 ? (
                <>
                  <img src="/assets/candy-0.svg" alt="" />
                  <img src="/assets/candy-0.svg" alt="" />
                  <img src="/assets/candy-0.svg" alt="" />
                  <Sparkles />
                </>
              ) : tutorialStep === 1 ? (
                <>
                  <img src="/assets/candy-3.svg" alt="" />
                  <span className="tutorial-stripe">≡</span>
                  <ArrowRight />
                  <span className="tutorial-bomb">✦</span>
                </>
              ) : (
                <>
                  <span className="tutorial-frost">
                    <img src="/assets/candy-1.svg" alt="" />
                  </span>
                  <Hammer />
                  <span className="tutorial-plus">+5</span>
                </>
              )}
            </div>
            <h2 className="modal-title">
              {
                ['Üçü bir arada.', 'Biraz daha büyük düşün.', 'Hedefe giden tatlı yol.'][
                  tutorialStep
                ]
              }
            </h2>
            <p className="tutorial-copy">
              {
                [
                  <>
                    Yan yana veya alt alta <b>en az 3 aynı şekeri</b> bir araya getir. Bir şekeri
                    komşusuna kaydırabilir ya da ikisine sırayla tıklayabilirsin. Eşleşmeyen
                    değişimler hamle harcamaz.
                  </>,
                  <>
                    <b>4 şeker</b> çizgili bir şeker, <b>5 veya daha fazlası</b> renk bombası
                    oluşturur. Çizgili şekeri eşleştirerek bir satır veya sütunu temizle; renk
                    bombasını bir şekerle değiştirerek o rengi topla.
                  </>,
                  <>
                    Hamlelerin bitmeden <b>puan, toplama ve krema hedeflerinin hepsini</b> tamamla.
                    Krema kaplı hücredeki şekeri patlatmak bir katmanı temizler; şekerler krema
                    içinden geçebilir. Çekiç, karıştırma ve +5 hamle her denemede bir kez senin.
                  </>,
                ][tutorialStep]
              }
            </p>
            <div className="tutorial-dots">
              {[0, 1, 2].map((step) => (
                <button
                  key={step}
                  className={tutorialStep === step ? 'active' : ''}
                  aria-label={`${step + 1}. bilgi`}
                  onClick={() => setTutorialStep(step)}
                />
              ))}
            </div>
            <button
              className="primary-button wide"
              data-testid="tutorial-next"
              onClick={() => (tutorialStep < 2 ? setTutorialStep((s) => s + 1) : closeTutorial())}
            >
              {tutorialStep < 2 ? 'DEVAM' : 'HAZIRIM'}
              <ArrowRight size={19} />
            </button>
            <p className="keyboard-tip">Klavyeyle: ok tuşları ve Enter. Duraklatmak için Esc.</p>
          </Modal>
        )}

        {paused && attempt && (
          <Modal
            title="Oyun duraklatıldı"
            onClose={() => setPaused(false)}
            reduced={settings.reducedMotion}
            className="pause-modal"
          >
            <div className="pause-illustration">
              <img src="/assets/candy-3.svg" alt="" />
              <span>z</span>
              <span>z</span>
            </div>
            <span className="eyebrow">ŞEKERLER BEKLEYEBİLİR</span>
            <h2 className="modal-title">Bir nefes al.</h2>
            <p className="modal-description">Maceran tam burada seni bekliyor.</p>
            <div className="pause-stats">
              <span>{attempt.level.name}</span>
              <b>{attempt.state.movesLeft} hamle kaldı</b>
            </div>
            <button
              className="primary-button wide"
              onClick={() => {
                setPaused(false);
                soundscape.play('tap');
              }}
            >
              <Play size={18} fill="currentColor" />
              DEVAM ET
            </button>
            <div className="pause-secondary">
              <button className="secondary-button" onClick={retryLevel} disabled={starting}>
                <RotateCcw size={16} /> Yeniden başla
              </button>
              <button className="secondary-button" onClick={() => leaveGame('map')}>
                <MapIcon size={16} /> Haritaya dön
              </button>
            </div>
            <small className="pause-note">Haritaya dönersen bu deneme sona erer.</small>
          </Modal>
        )}

        {finished && !paused && !tutorialOpen && !settingsOpen && attempt && (
          <Modal
            title={attempt.state.status === 'won' ? 'Bölüm tamamlandı' : 'Hamlelerin bitti'}
            reduced={settings.reducedMotion}
            className={`result-modal ${attempt.state.status}`}
            testId="result-dialog"
          >
            {attempt.state.status === 'won' && !settings.reducedMotion && (
              <div className="confetti" aria-hidden="true">
                {Array.from({ length: 25 }, (_, i) => (
                  <i
                    key={i}
                    style={
                      {
                        '--i': i,
                        '--confetti-color': ['#ea8fba', '#d7e9a4', '#ffcb7e', '#b0a8ec'][i % 4],
                      } as CSSProperties
                    }
                  />
                ))}
              </div>
            )}
            <span className="eyebrow">
              BÖLÜM {attempt.level.id} · {attempt.level.name}
            </span>
            <h2 className="modal-title">
              {attempt.state.status === 'won' ? 'Tatlı bir zafer!' : 'Bir hamle daha?'}
            </h2>
            <p className="modal-description">
              {attempt.state.status === 'won'
                ? attempt.level.id === 20
                  ? 'Son adayı da keşfettin. Bu şeker tacı senin!'
                  : 'Bir adım daha, bir dünya daha tatlı.'
                : 'Hamlelerin bitti, ama macera bitmedi.'}
            </p>
            {attempt.state.status === 'won' ? (
              <Stars count={getStars(attempt.state, attempt.level)} className="result-stars" />
            ) : (
              <div className="result-candy">
                <img src="/assets/candy-0.svg" alt="" />
                <span>…</span>
              </div>
            )}
            <div className="result-score">
              <span>TOPLADIĞIN PUAN</span>
              <strong>{number(attempt.state.score)}</strong>
            </div>
            {attempt.state.status === 'lost' && (
              <div className="unfinished-goals">
                <ObjectiveList level={attempt.level} state={attempt.state} compact />
              </div>
            )}
            {attempt.state.status === 'won' && (
              <div className={`save-feedback ${save.kind}`} role="status">
                {save.kind === 'saving' ? (
                  <LoaderCircle className="spin" size={16} />
                ) : save.kind === 'saved' ? (
                  <CheckCircle2 size={16} />
                ) : save.kind === 'error' ? (
                  <CloudOff size={16} />
                ) : null}
                <span>{save.message}</span>
                {save.kind === 'error' && (
                  <button onClick={() => void saveAttempt(attempt)}>Tekrar dene</button>
                )}
              </div>
            )}
            {attempt.state.status === 'won' ? (
              <>
                <button
                  className="primary-button wide"
                  data-testid="next-level"
                  disabled={starting || (attempt.remote && save.kind !== 'saved')}
                  onClick={() =>
                    attempt.level.id < LEVELS.length
                      ? void startLevel(LEVELS[attempt.level.id])
                      : leaveGame('map')
                  }
                >
                  {starting ? (
                    <LoaderCircle className="spin" size={19} />
                  ) : attempt.level.id === 20 ? (
                    <Crown size={21} />
                  ) : (
                    <ArrowRight size={20} />
                  )}
                  {attempt.level.id === 20 ? 'YOLCULUĞUMU GÖR' : 'SIRADAKİ BÖLÜM'}
                </button>
                <div className="result-secondary">
                  <button
                    className="text-button"
                    data-testid="retry-level"
                    onClick={retryLevel}
                    disabled={starting}
                  >
                    <RotateCcw size={15} /> Yeniden oyna
                  </button>
                  <button className="text-button" onClick={() => leaveGame('map')}>
                    <MapIcon size={15} /> Haritaya dön
                  </button>
                </div>
              </>
            ) : (
              <>
                {attempt.state.powers.extra > 0 && (
                  <button
                    className="primary-button wide"
                    data-testid="extra-moves"
                    disabled={busy}
                    onClick={() => void performAction({ kind: 'extra' })}
                  >
                    <Plus size={21} />5 HAMLEYLE DEVAM ET<span className="button-note">1 HAK</span>
                  </button>
                )}
                <button
                  className={
                    attempt.state.powers.extra > 0
                      ? 'secondary-button wide retry-after-extra'
                      : 'primary-button wide'
                  }
                  data-testid="retry-level"
                  onClick={retryLevel}
                  disabled={starting}
                >
                  {starting ? <LoaderCircle size={18} className="spin" /> : <RotateCcw size={18} />}
                  YENİDEN DENE
                </button>
                <button className="text-button loss-map" onClick={() => leaveGame('map')}>
                  <MapIcon size={16} /> Haritaya dön
                </button>
              </>
            )}
          </Modal>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {toast && (
          <motion.div
            className="toast"
            role="status"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
          >
            <Sparkles size={17} />
            <span>{toast}</span>
            <button onClick={() => setToast('')} aria-label="Bildirimi kapat">
              <X size={16} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SettingToggle({
  icon,
  title,
  description,
  checked,
  onChange,
}: {
  icon: ReactNode;
  title: string;
  description: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <button className="setting-toggle" role="switch" aria-checked={checked} onClick={onChange}>
      <span className="setting-icon">{icon}</span>
      <span className="setting-copy">
        <b>{title}</b>
        <small>{description}</small>
      </span>
      <span className={`toggle-track ${checked ? 'on' : ''}`}>
        <i />
      </span>
    </button>
  );
}

function PowerButton({
  name,
  description,
  icon,
  count,
  active = false,
  disabled,
  onClick,
}: {
  name: string;
  description: string;
  icon: ReactNode;
  count: number;
  active?: boolean;
  disabled: boolean;
  onClick: () => void;
}) {
  return (
    <button
      className={`power-button ${active ? 'active' : ''} ${count === 0 ? 'used' : ''}`}
      onClick={onClick}
      disabled={disabled || count === 0}
      aria-pressed={active}
      title={`${name}: ${description}. ${count ? 'Bu denemede bir kullanım.' : 'Bu denemede kullanıldı.'}`}
    >
      <span className="power-icon">
        {icon}
        <b>{count > 0 ? '1' : <Check size={11} />}</b>
      </span>
      <span className="power-copy">
        <strong>{name}</strong>
        <small>{count === 0 ? 'Kullanıldı' : description}</small>
      </span>
      {active && <span className="power-active-dot" />}
    </button>
  );
}

function ObjectiveList({
  level,
  state,
  compact = false,
}: {
  level: Level;
  state: GameState;
  compact?: boolean;
}) {
  const frostLeft = frosting(state);
  const frostTotal = level.blockers.reduce((sum, blocker) => sum + blocker.hp, 0);
  return (
    <div className={`objectives ${compact ? 'compact' : ''}`}>
      <div className={`objective objective-score ${state.score >= level.target ? 'done' : ''}`}>
        <span className="objective-symbol">
          <Star size={24} fill="currentColor" />
        </span>
        <span>
          <b>
            {number(Math.min(state.score, level.target))} <small>/ {number(level.target)}</small>
          </b>
          <em>puan topla</em>
        </span>
        {state.score >= level.target && <CheckCircle2 size={18} />}
      </div>
      {level.collections.map((goal) => {
        const collected = state.collected[goal.color] || 0;
        return (
          <div key={goal.color} className={`objective ${collected >= goal.count ? 'done' : ''}`}>
            <img src={`/assets/candy-${goal.color}.svg`} alt={CANDY_NAMES[goal.color]} />
            <span>
              <b>
                {Math.min(collected, goal.count)} <small>/ {goal.count}</small>
              </b>
              <em>{CANDY_NAMES[goal.color]}</em>
            </span>
            {collected >= goal.count && <CheckCircle2 size={18} />}
          </div>
        );
      })}
      {frostTotal > 0 && (
        <div className={`objective ${frostLeft === 0 ? 'done' : ''}`}>
          <span className="objective-symbol frosting-symbol">
            <Layers3 size={25} />
          </span>
          <span>
            <b>
              {frostTotal - frostLeft} <small>/ {frostTotal}</small>
            </b>
            <em>krema katmanı temizle</em>
          </span>
          {frostLeft === 0 && <CheckCircle2 size={18} />}
        </div>
      )}
    </div>
  );
}

function JourneyMap({
  progress,
  reduced,
  onLevel,
}: {
  progress: Progress;
  reduced: boolean;
  onLevel: (level: Level) => void;
}) {
  const xPattern = [48, 30, 27, 47, 68, 70, 50, 29, 29, 49, 70, 69, 48, 27, 30, 50, 71, 66, 44, 49];
  const height = 2560;
  const points = LEVELS.map((level, i) => ({
    x: xPattern[i] * 8,
    y: height - 150 - i * 118,
    level,
  }));
  const path = points
    .map((point, i) =>
      i === 0
        ? `M ${point.x} ${point.y}`
        : `C ${points[i - 1].x} ${points[i - 1].y - 64}, ${point.x} ${point.y + 64}, ${point.x} ${point.y}`,
    )
    .join(' ');
  const realmNames = ['Şeker Kıyısı', 'Lokum Korusu', 'Karamel Zirveleri', 'Yıldız Şatosu'];
  return (
    <div className="journey-world" style={{ height }}>
      <div className="map-sky-glow" />
      {realmNames.map((realm, i) => (
        <div
          key={realm}
          className={`realm-land realm-land-${i}`}
          style={{ top: height - 710 - i * 590 }}
          aria-hidden="true"
        >
          <img src="/assets/island.svg" alt="" />
          <span>
            {String(i + 1).padStart(2, '0')}
            <em>{realm}</em>
          </span>
        </div>
      ))}
      <svg
        className="journey-path"
        viewBox={`0 0 800 ${height}`}
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path d={path} fill="none" stroke="#190f27" strokeWidth="35" opacity=".38" />
        <path d={path} fill="none" stroke="#956d73" strokeWidth="22" strokeLinecap="round" />
        <path d={path} fill="none" stroke="#edbfa0" strokeWidth="15" strokeLinecap="round" />
        <path
          d={path}
          fill="none"
          stroke="#fff3d7"
          strokeWidth="2"
          strokeDasharray="3 10"
          opacity=".65"
        />
      </svg>
      <div className="map-finale" style={{ top: 18 }}>
        <Crown size={29} />
        <span>ODYSSEIA TACI</span>
        <small>Her güzel maceranın bir tacı var.</small>
      </div>
      {points.map(({ x, y, level }) => {
        const locked = level.id > progress.unlockedLevel;
        const completed = progress.completed[String(level.id)];
        const current = !completed && level.id === progress.unlockedLevel;
        return (
          <div
            key={level.id}
            className={`map-stop ${locked ? 'locked' : completed ? 'completed' : 'current'}`}
            style={{ left: `${x / 8}%`, top: y }}
          >
            {current && (
              <span className="you-are-here">
                SIRADA SEN VARSIN <span />
              </span>
            )}
            <button
              className="level-node"
              data-testid={`level-${level.id}`}
              aria-label={`Bölüm ${level.id}: ${level.name}. ${locked ? 'Kilitli' : completed ? `${completed.stars} yıldızla tamamlandı. Yeniden oyna` : 'Oynamaya hazır'}`}
              aria-disabled={locked}
              onClick={() => {
                if (!locked) onLevel(level);
              }}
              tabIndex={locked ? -1 : 0}
            >
              {locked ? (
                <LockKeyhole size={21} />
              ) : level.id === 20 ? (
                <Crown size={25} />
              ) : (
                <span>{level.id}</span>
              )}
              {current && !reduced && <span className="node-pulse" />}
            </button>
            {completed ? (
              <Stars count={completed.stars} className="map-node-stars" />
            ) : locked ? (
              <span className="locked-number">{level.id}</span>
            ) : (
              <span className="current-node-caption">BAŞLAYALIM</span>
            )}
            <span className={`node-name ${x < 380 ? 'name-right' : 'name-left'}`}>
              <small>BÖLÜM {level.id}</small>
              {level.name}
            </span>
          </div>
        );
      })}
      <div className="map-start-caption">
        <span>✦</span> Her macera küçük bir adımla başlar.
      </div>
      {[0, 1, 2, 3, 4, 5].map((color, i) => (
        <img
          key={color}
          className={`map-loose-candy map-loose-${i}`}
          src={`/assets/candy-${color}.svg`}
          alt=""
          aria-hidden="true"
          style={{ top: 320 + i * 365, left: `${i % 2 ? 83 : 2}%` }}
        />
      ))}
    </div>
  );
}
