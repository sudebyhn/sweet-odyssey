import { describe, expect, it } from 'vitest';
import { ApiError, parseProgress } from './api';

describe('progress API boundary', () => {
  it('accepts a validated saved result and does not reuse the mutable response', () => {
    const input = {
      unlockedLevel: 2,
      completed: { '1': { score: 1640, stars: 1 } },
      totalStars: 1,
    };
    const result = parseProgress(input);
    input.completed['1'].score = -3;
    expect(result.completed['1'].score).toBe(1640);
  });
  it.each([
    null,
    { unlockedLevel: 0, completed: {}, totalStars: 0 },
    { unlockedLevel: '2', completed: {}, totalStars: 0 },
    { unlockedLevel: 2, completed: { '1': { score: -40, stars: 1 } }, totalStars: 1 },
    { unlockedLevel: 2, completed: { '1': { score: 1200, stars: 4 } }, totalStars: 4 },
    { unlockedLevel: 2, completed: { bogus: { score: 1200, stars: 1 } }, totalStars: 1 },
  ])('rejects malformed progress %j', (value) => {
    expect(() => parseProgress(value)).toThrow(ApiError);
  });
});
