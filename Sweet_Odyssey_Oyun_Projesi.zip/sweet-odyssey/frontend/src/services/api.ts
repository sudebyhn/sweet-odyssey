import type { Action, Level } from '../game/engine';

export interface Player {
  id: string;
  nickname: string;
}
export interface Progress {
  unlockedLevel: number;
  completed: Record<string, { score: number; stars: number }>;
  totalStars: number;
}
export interface Run {
  id: string;
  seed: number;
  level: Level;
}
export interface FinishResult {
  score: number;
  stars: number;
  status: 'won' | 'lost';
  progress: Progress;
}

export class ApiError extends Error {
  constructor(
    message: string,
    public readonly status = 0,
    public readonly code = 'NETWORK',
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

const base = (import.meta.env.VITE_API_BASE_URL || '/api').replace(/\/$/, '');
const invalid = (): never => {
  throw new ApiError('Kayıt servisinden geçersiz yanıt geldi.', 502, 'INVALID_RESPONSE');
};
const record = (value: unknown): Record<string, unknown> => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return invalid();
  return value as Record<string, unknown>;
};
const string = (value: unknown): string => (typeof value === 'string' ? value : invalid());
const integer = (value: unknown, min = 0, max = Number.MAX_SAFE_INTEGER): number =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= min && value <= max
    ? value
    : invalid();

function parsePlayer(value: unknown): Player {
  const p = record(value);
  return { id: string(p.id), nickname: string(p.nickname) };
}

export function parseProgress(value: unknown): Progress {
  const p = record(value);
  const completed: Progress['completed'] = {};
  for (const [key, value] of Object.entries(record(p.completed))) {
    if (!/^[1-9]\d*$/.test(key)) invalid();
    const result = record(value);
    completed[key] = { score: integer(result.score), stars: integer(result.stars, 0, 3) };
  }
  return {
    unlockedLevel: integer(p.unlockedLevel, 1),
    completed,
    totalStars: integer(p.totalStars),
  };
}

function parseLevel(value: unknown): Level {
  const l = record(value);
  for (const key of ['name', 'realm', 'description', 'difficulty']) string(l[key]);
  integer(l.id, 1, 10000);
  integer(l.rows, 3, 16);
  integer(l.cols, 3, 16);
  integer(l.colors, 3, 6);
  integer(l.moves, 1, 1000);
  integer(l.target, 1);
  if (
    !Array.isArray(l.collections) ||
    !Array.isArray(l.blockers) ||
    !Array.isArray(l.starThresholds)
  )
    invalid();
  for (const goal of l.collections as unknown[]) {
    const g = record(goal);
    integer(g.color, 0, Number(l.colors) - 1);
    integer(g.count, 1);
  }
  for (const blocker of l.blockers as unknown[]) {
    const b = record(blocker);
    integer(b.row, 0, Number(l.rows) - 1);
    integer(b.col, 0, Number(l.cols) - 1);
    integer(b.hp, 1, 10);
  }
  const thresholds = l.starThresholds as unknown[];
  if (thresholds.length !== 3) invalid();
  thresholds.forEach((v) => integer(v, 1));
  return l as unknown as Level;
}

async function request(
  path: string,
  method = 'GET',
  token?: string,
  body?: unknown,
): Promise<unknown> {
  const controller = new AbortController();
  const timer = window.setTimeout(
    () => controller.abort(),
    path.endsWith('/finish') ? 30000 : 9000,
  );
  try {
    const response = await fetch(`${base}${path}`, {
      method,
      headers: {
        Accept: 'application/json',
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
      signal: controller.signal,
      cache: 'no-store',
    });
    let payload: unknown;
    try {
      payload = await response.json();
    } catch {
      throw new ApiError(
        'Kayıt servisi beklenen biçimde yanıt vermedi.',
        response.status || 502,
        'INVALID_RESPONSE',
      );
    }
    if (!response.ok) {
      const error = record(payload);
      const message =
        typeof error.detail === 'string'
          ? error.detail
          : response.status === 401
            ? 'Oyuncu kaydına erişilemiyor. Başlangıç ekranından yeniden bağlanın.'
            : response.status === 403
              ? 'Bu bölüm henüz açılmadı.'
              : response.status === 422
                ? 'Gönderilen oyun kaydı doğrulanamadı.'
                : 'Kayıt servisine şu anda ulaşılamıyor. Tekrar deneyebilirsiniz.';
      throw new ApiError(message, response.status, 'HTTP');
    }
    return payload;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (controller.signal.aborted)
      throw new ApiError('Kayıt servisi zamanında yanıt vermedi.', 0, 'TIMEOUT');
    throw new ApiError(
      'Kayıt servisine bağlanılamadı. Oyunun Python penceresinin açık olduğundan emin olun.',
    );
  } finally {
    window.clearTimeout(timer);
  }
}

export const api = {
  async createPlayer(
    nickname = 'Gezgin',
  ): Promise<{ token: string; player: Player; progress: Progress }> {
    const p = record(await request('/players', 'POST', undefined, { nickname }));
    return {
      token: string(p.token),
      player: parsePlayer(p.player),
      progress: parseProgress(p.progress),
    };
  },
  async levels(): Promise<Level[]> {
    const result = await request('/levels');
    if (!Array.isArray(result)) return invalid();
    return result.map(parseLevel);
  },
  async progress(token: string): Promise<Progress> {
    return parseProgress(await request('/progress', 'GET', token));
  },
  async rename(token: string, nickname: string): Promise<Player> {
    return parsePlayer(await request('/players/me', 'PATCH', token, { nickname }));
  },
  async stats(token: string): Promise<Record<string, unknown>> {
    return record(await request('/stats', 'GET', token));
  },
  async startRun(token: string, levelId: number): Promise<Run> {
    const r = record(await request('/runs', 'POST', token, { level_id: levelId }));
    return { id: string(r.id), seed: integer(r.seed, 1, 0xffffffff), level: parseLevel(r.level) };
  },
  async finishRun(token: string, id: string, actions: Action[]): Promise<FinishResult> {
    const r = record(
      await request(`/runs/${encodeURIComponent(id)}/finish`, 'POST', token, { actions }),
    );
    if (r.status !== 'won' && r.status !== 'lost') invalid();
    return {
      score: integer(r.score),
      stars: integer(r.stars, 0, 3),
      status: r.status as 'won' | 'lost',
      progress: parseProgress(r.progress),
    };
  },
};
