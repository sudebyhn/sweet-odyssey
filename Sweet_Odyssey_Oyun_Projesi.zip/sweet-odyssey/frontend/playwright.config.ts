import { defineConfig, devices } from '@playwright/test';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdirSync } from 'node:fs';

const frontend = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(frontend, '..');
const python =
  process.env.SWEET_TEST_PYTHON ||
  path.join(root, '.venv', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
const database = path.join(root, 'data', `e2e-${Date.now()}.db`).replace(/\\/g, '/');
mkdirSync(path.dirname(database), { recursive: true });
const baseURL = 'http://127.0.0.1:8173';

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: false,
  workers: 1,
  timeout: 90000,
  expect: { timeout: 10000 },
  retries: 0,
  reporter: [['list'], ['json', { outputFile: '../test-results/e2e-results.json' }]],
  outputDir: '../test-results/e2e',
  use: {
    baseURL,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    reducedMotion: 'reduce',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'], viewport: { width: 1440, height: 1000 } },
    },
  ],
  webServer: {
    command: `"${python}" -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8173 --no-access-log`,
    cwd: root,
    env: { ...process.env, DATABASE_URL: `sqlite:///${database}`, CORS_ORIGINS: '' },
    url: `${baseURL}/api/health`,
    reuseExistingServer: false,
    timeout: 30000,
  },
});
