import { test, expect, type Page, type APIRequestContext } from '@playwright/test';
import {
  applyAction,
  createGame,
  findMatches,
  findValidMoves,
  type Action,
  type GameState,
  type Level,
  type Position,
} from '../../src/game/engine';

const PROFILE = 'sweet-odyssey-profile-v1';
const SETTINGS = 'sweet-odyssey-settings-v1';
const TUTORIAL = 'sweet-odyssey-tutorial-v1';

async function setup(page: Page, tutorial = true) {
  await page.addInitScript(
    ({ settings, tutorialKey, done }) => {
      if (!localStorage.getItem(settings))
        localStorage.setItem(
          settings,
          JSON.stringify({ sound: false, music: false, reducedMotion: true }),
        );
      if (done) localStorage.setItem(tutorialKey, 'true');
    },
    { settings: SETTINGS, tutorialKey: TUTORIAL, done: tutorial },
  );
}

async function stable(page: Page): Promise<GameState> {
  await expect
    .poll(() => page.evaluate(() => !!window.__SWEET_GAME__?.state && !window.__SWEET_GAME__?.busy))
    .toBe(true);
  return page.evaluate(() => structuredClone(window.__SWEET_GAME__!.state!));
}

async function start(page: Page, id = 1) {
  await page.goto('/');
  await page.locator('[data-testid="play-button"], [data-testid="continue-button"]').click();
  await page.getByTestId(`level-${id}`).click();
  await page.getByTestId('start-level').click();
  await expect(page.getByTestId('game-board').locator('canvas')).toBeVisible();
}

async function act(page: Page, action: Action) {
  await stable(page);
  const result = await page.evaluate((action) => window.__SWEET_GAME__!.action(action), action);
  expect(result?.accepted).toBe(true);
  return stable(page);
}

function choose(state: GameState, level: Level, policy: 'win' | 'lose' = 'win'): Action {
  const ranked = findValidMoves(state.board).map((move) => {
    const action: Action = { kind: 'swap', ...move };
    const next = applyAction(state, action, level).state;
    const frosting = next.blockers.flat().reduce((a, b) => a + b, 0);
    const collected = level.collections.reduce(
      (sum, goal) => sum + Math.min(next.collected[goal.color], goal.count),
      0,
    );
    const value =
      policy === 'win'
        ? (next.status === 'won' ? 1e9 : 0) - frosting * 2000 + collected * 200 + next.score
        : (next.status === 'won' ? -1e9 : 0) + frosting * 1e6 - next.score;
    return { action, value };
  });
  ranked.sort((a, b) => b.value - a.value);
  if (!ranked.length) throw new Error('No legal move on a stable board');
  return ranked[0].action;
}

async function finishByPlaying(page: Page, policy: 'win' | 'lose' = 'win') {
  let state = await stable(page);
  const level = await page.evaluate(() => structuredClone(window.__SWEET_GAME__!.level!));
  for (let turn = 0; turn < 70 && state.status === 'playing'; turn++)
    state = await act(page, choose(state, level, policy));
  return state;
}

async function clickCell(page: Page, position: Position) {
  const box = await page.getByTestId('game-board').locator('canvas').boundingBox();
  expect(box).not.toBeNull();
  const x = box!.x + (box!.width * (13 + (position[1] + 0.5) * (614 / 8))) / 640;
  const y = box!.y + (box!.height * (13 + (position[0] + 0.5) * (614 / 8))) / 640;
  await page.mouse.click(x, y);
}

// Preparatory progression is earned by real engine actions and independently
// verified by the API. This helper never writes unlocked values or fake scores.
async function earnLevels(request: APIRequestContext, through: number) {
  const created = await request.post('/api/players', { data: { nickname: 'Tarayıcı Testi' } });
  expect(created.ok()).toBe(true);
  const profile = await created.json();
  const headers = { Authorization: `Bearer ${profile.token}` };
  for (let id = 1; id <= through; id++) {
    let won = false;
    for (let retry = 0; retry < 8 && !won; retry++) {
      const response = await request.post('/api/runs', { headers, data: { level_id: id } });
      expect(response.ok()).toBe(true);
      const run = await response.json();
      const level: Level = run.level;
      let state = createGame(level, run.seed);
      const actions: Action[] = [];
      for (let step = 0; step < 70; step++) {
        let action: Action;
        if (state.status === 'won') break;
        if (state.status === 'lost') {
          if (!state.powers.extra) break;
          action = { kind: 'extra' };
        } else action = choose(state, level);
        const result = applyAction(state, action, level);
        if (!result.accepted) throw new Error('Illegal preparatory action');
        state = result.state;
        actions.push(action);
      }
      const saved = await request.post(`/api/runs/${run.id}/finish`, {
        headers,
        data: { actions },
      });
      expect(saved.ok()).toBe(true);
      expect((await saved.json()).status).toBe(state.status);
      won = state.status === 'won';
    }
    expect(won, `Earned canonical level ${id} within eight legal attempts`).toBe(true);
  }
  return profile;
}

test('welcome, tutorial, pointer swap, invalid swap, pause, powers, victory and persisted unlock', async ({
  page,
}) => {
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await setup(page, false);
  await page.goto('/');
  await expect(page.getByRole('heading', { name: /SWEET/ })).toBeVisible();
  await page.getByTestId('play-button').click();
  await expect(page.getByTestId('level-2')).toHaveAttribute('aria-disabled', 'true');
  await expect
    .poll(() =>
      page.locator('.topbar').evaluate((el) => Math.round(el.getBoundingClientRect().top)),
    )
    .toBe(0);
  await page.getByTestId('level-1').click();
  await page.getByTestId('start-level').click();
  for (let i = 0; i < 3; i++) await page.getByTestId('tutorial-next').click();
  await expect.poll(() => page.evaluate(() => document.body.style.overflow)).not.toBe('hidden');
  let state = await stable(page);
  expect(state.movesLeft).toBe(22);
  const move = findValidMoves(state.board)[0];
  await clickCell(page, move.from);
  await clickCell(page, move.to);
  await expect.poll(async () => (await stable(page)).movesLeft).toBe(21);
  state = await stable(page);
  expect(state.score).toBeGreaterThan(0);

  // A diagonal action is rejected by the actual UI action path and leaves state intact.
  const before = structuredClone(state);
  const rejected = await page.evaluate(() =>
    window.__SWEET_GAME__!.action({ kind: 'swap', from: [0, 0], to: [1, 1] }),
  );
  expect(rejected?.accepted).toBe(false);
  expect(await stable(page)).toEqual(before);
  await page.getByTestId('pause-button').click();
  await expect(page.getByRole('dialog', { name: 'Oyun duraklatıldı' })).toBeVisible();
  const blocked = await page.evaluate(() => window.__SWEET_GAME__!.action({ kind: 'extra' }));
  expect(blocked).toBeNull();
  expect(await page.evaluate(() => window.__SWEET_GAME__!.state!.movesLeft)).toBe(21);
  await page.getByRole('button', { name: 'DEVAM ET', exact: true }).click();
  state = await act(page, { kind: 'extra' });
  expect(state.movesLeft).toBe(26);
  expect(state.powers.extra).toBe(0);
  state = await act(page, { kind: 'shuffle' });
  expect(state.powers.shuffle).toBe(0);
  expect(findMatches(state.board)).toHaveLength(0);
  expect(findValidMoves(state.board).length).toBeGreaterThan(0);
  state = await finishByPlaying(page);
  expect(state.status).toBe('won');
  await expect(page.getByTestId('result-dialog')).toContainText('Tatlı bir zafer');
  await expect(page.getByTestId('next-level')).toBeEnabled();
  await page.getByTestId('next-level').click();
  state = await stable(page);
  expect(state.levelId).toBe(2);
  await page.reload();
  await page.getByTestId('continue-button').click();
  await expect(page.getByTestId('level-2')).toHaveAttribute('aria-disabled', 'false');
  await expect(page.getByTestId('level-1')).toHaveAttribute('aria-label', /yıldızla tamamlandı/);
  await expect.poll(() => page.evaluate(() => document.body.style.overflow)).not.toBe('hidden');
  await expect
    .poll(() =>
      page.locator('.topbar').evaluate((el) => Math.round(el.getBoundingClientRect().top)),
    )
    .toBe(0);
  expect(errors).toEqual([]);
});

test('settings and guest nickname persist after refresh', async ({ page }) => {
  await setup(page);
  await page.goto('/');
  await expect(page.getByTestId('play-button')).toBeEnabled();
  await page.getByRole('button', { name: 'Ayarlar', exact: true }).click();
  await page.getByRole('textbox', { name: 'GEZGİN ADIN' }).fill('Mavi Gezgin');
  await page.getByRole('button', { name: 'Kaydet', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Kaydet', exact: true })).toBeDisabled();
  const sound = page.getByRole('switch', { name: /Ses efektleri/ });
  await expect(sound).toHaveAttribute('aria-checked', 'false');
  await sound.click();
  await expect(sound).toHaveAttribute('aria-checked', 'true');
  await page.reload();
  await expect(page.getByTestId('play-button')).toBeEnabled();
  await page.getByRole('button', { name: 'Ayarlar', exact: true }).click();
  await expect(page.getByRole('textbox', { name: 'GEZGİN ADIN' })).toHaveValue('Mavi Gezgin');
  await expect(page.getByRole('switch', { name: /Ses efektleri/ })).toHaveAttribute(
    'aria-checked',
    'true',
  );
});

test('mobile board fits, pointer interaction works, hammer is single-use', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await setup(page);
  await start(page);
  let state = await stable(page);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  const box = await page.getByTestId('game-board').locator('canvas').boundingBox();
  expect(box!.width).toBeGreaterThan(290);
  expect(box!.x).toBeGreaterThanOrEqual(0);
  expect(box!.x + box!.width).toBeLessThanOrEqual(390);
  const pauseBox = await page.getByTestId('pause-button').boundingBox();
  expect(pauseBox!.width).toBeGreaterThanOrEqual(44);
  expect(pauseBox!.height).toBeGreaterThanOrEqual(44);
  await page.getByRole('button', { name: /Şeker çekici/ }).click();
  await clickCell(page, [0, 0]);
  await expect.poll(async () => (await stable(page)).powers.hammer).toBe(0);
  state = await stable(page);
  expect(state.movesLeft).toBe(22);
  expect(state.score).toBeGreaterThan(0);
  await expect(page.getByRole('button', { name: /Şeker çekici/ })).toBeDisabled();
  await page.screenshot({ path: '../test-results/mobile.png', fullPage: true });
});

test('failed save stays pending and retry unlocks only after server confirmation', async ({
  page,
}) => {
  await setup(page);
  await page.route('**/api/runs/*/finish', (route) =>
    route.fulfill({
      status: 503,
      contentType: 'application/json',
      body: '{"detail":"Test kesintisi"}',
    }),
  );
  await start(page);
  const state = await finishByPlaying(page);
  expect(state.status).toBe('won');
  await expect(page.getByTestId('result-dialog')).toContainText('henüz kaydedilemedi');
  await expect(page.getByTestId('next-level')).toBeDisabled();
  await page.unroute('**/api/runs/*/finish');
  await page.getByRole('button', { name: 'Tekrar dene', exact: true }).click();
  await expect(page.getByTestId('next-level')).toBeEnabled();
  await expect(page.getByTestId('result-dialog')).toContainText('İlerlemen kaydedildi');
});

test('offline local progress is labelled and survives refresh', async ({ page }) => {
  await setup(page);
  await page.route('**/api/**', (route) => route.abort('failed'));
  await start(page);
  await expect(page.locator('.connection-status')).toContainText('Yerel kayıt');
  expect((await finishByPlaying(page)).status).toBe('won');
  await expect(page.getByTestId('result-dialog')).toContainText('bu tarayıcıya kaydedildi');
  await page.reload();
  await page.getByTestId('continue-button').click();
  await expect(page.getByTestId('level-2')).toHaveAttribute('aria-disabled', 'false');
  await expect(page.locator('.connection-status')).toContainText('Yerel kayıt');
});

test('canonical frosting level reaches real loss, extra moves revive, retry resets state', async ({
  page,
  request,
}) => {
  const profile = await earnLevels(request, 3);
  await setup(page);
  await page.addInitScript(
    ({ key, profile }) =>
      localStorage.setItem(key, JSON.stringify({ token: profile.token, player: profile.player })),
    { key: PROFILE, profile },
  );
  await start(page, 4);
  let state = await finishByPlaying(page, 'lose');
  expect(state.status).toBe('lost');
  expect(state.movesLeft).toBe(0);
  expect(state.blockers.flat().some((hp) => hp > 0)).toBe(true);
  await expect(page.getByTestId('result-dialog')).toContainText('Hamlelerin bitti');
  await page.getByTestId('extra-moves').click();
  state = await stable(page);
  expect(state.status).toBe('playing');
  expect(state.movesLeft).toBe(5);
  state = await finishByPlaying(page, 'lose');
  expect(state.status).toBe('lost');
  await page.getByTestId('retry-level').click();
  state = await stable(page);
  expect(state.levelId).toBe(4);
  expect(state.movesLeft).toBe(26);
  expect(state.score).toBe(0);
  expect(state.powers).toEqual({ hammer: 1, shuffle: 1, extra: 1 });
  const progress = await request.get('/api/progress', {
    headers: { Authorization: `Bearer ${profile.token}` },
  });
  expect((await progress.json()).unlockedLevel).toBe(4);
});

test('real touch swipe resolves the adjacent move on a mobile context', async ({ browser }) => {
  const context = await browser.newContext({
    baseURL: 'http://127.0.0.1:8173',
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
    reducedMotion: 'reduce',
  });
  const page = await context.newPage();
  try {
    await setup(page);
    await start(page);
    const state = await stable(page);
    const move = findValidMoves(state.board)[0];
    const box = (await page.getByTestId('game-board').locator('canvas').boundingBox())!;
    const xy = (cell: Position) => ({
      x: box.x + (box.width * (13 + (cell[1] + 0.5) * (614 / 8))) / 640,
      y: box.y + (box.height * (13 + (cell[0] + 0.5) * (614 / 8))) / 640,
    });
    const from = xy(move.from),
      to = xy(move.to);
    const cdp = await context.newCDPSession(page);
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [from] });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [to] });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
    await expect.poll(async () => (await stable(page)).movesLeft).toBe(state.movesLeft - 1);
    expect((await stable(page)).score).toBeGreaterThan(0);
    await cdp.detach();
  } finally {
    await context.close();
  }
});
