"""Pure deterministic game rules, mirrored by frontend/src/game/engine.ts.

No database, network or rendering dependency belongs here. The server replays
actions using this engine instead of trusting client scores or claimed wins.
Random calls and all set iteration have explicit cross-language ordering.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

ZERO_SEED = 0x6D2B79F5
MAX_CASCADES = 64
MASK_32 = 0xFFFFFFFF


def clone_state(state: dict[str, Any]) -> dict[str, Any]:
    return deepcopy(state)


def validate_level(level: Any) -> list[str]:
    """Return all validation errors; a valid level returns an empty list."""
    if not isinstance(level, dict):
        return ["Bölüm tanımı nesne olmalı."]
    errors: list[str] = []

    def integer(value: Any, low: int, high: int) -> bool:
        return isinstance(value, int) and not isinstance(value, bool) and low <= value <= high

    if not integer(level.get("id"), 1, 10000):
        errors.append("Bölüm kimliği geçersiz.")
    for field in ("name", "realm", "description", "difficulty"):
        if not isinstance(level.get(field), str) or not level[field].strip():
            errors.append(f"{field} metni gerekli.")
    rows, cols, colors = level.get("rows"), level.get("cols"), level.get("colors")
    if not integer(rows, 3, 12) or not integer(cols, 3, 12):
        errors.append("Tahta boyutu 3–12 arasında olmalı.")
    if not integer(colors, 5, 6):
        errors.append("Şeker rengi sayısı 5 veya 6 olmalı.")
    if not integer(level.get("moves"), 1, 100):
        errors.append("Hamle sayısı 1–100 arasında olmalı.")
    if not integer(level.get("target"), 1, 1000000):
        errors.append("Puan hedefi geçersiz.")
    thresholds = level.get("starThresholds")
    if (
        not isinstance(thresholds, list)
        or len(thresholds) != 3
        or not all(integer(value, 1, 10000000) for value in thresholds)
        or not thresholds[0] < thresholds[1] < thresholds[2]
        or not integer(level.get("target"), 1, 1000000)
        or thresholds[0] > level["target"]
    ):
        errors.append("Yıldız eşikleri artan üç pozitif sayı olmalı; ilki puan hedefini aşamaz.")
    seen_colors: set[int] = set()
    if not isinstance(level.get("collections"), list):
        errors.append("Toplama hedefleri liste olmalı.")
    else:
        for goal in level["collections"]:
            if (
                not isinstance(goal, dict)
                or not integer(goal.get("color"), 0, colors - 1 if isinstance(colors, int) else -1)
                or not integer(goal.get("count"), 1, 10000)
                or goal["color"] in seen_colors
            ):
                errors.append("Toplama hedefi geçersiz veya yineleniyor.")
            if isinstance(goal, dict) and isinstance(goal.get("color"), int):
                seen_colors.add(goal["color"])
    seen_cells: set[tuple[int, int]] = set()
    if not isinstance(level.get("blockers"), list):
        errors.append("Krema hücreleri liste olmalı.")
    else:
        for cell in level["blockers"]:
            if (
                not isinstance(cell, dict)
                or not integer(cell.get("row"), 0, rows - 1 if isinstance(rows, int) else -1)
                or not integer(cell.get("col"), 0, cols - 1 if isinstance(cols, int) else -1)
                or not integer(cell.get("hp"), 1, 3)
                or (cell["row"], cell["col"]) in seen_cells
            ):
                errors.append("Krema hücresi geçersiz veya yineleniyor.")
            if isinstance(cell, dict) and isinstance(cell.get("row"), int) and isinstance(cell.get("col"), int):
                seen_cells.add((cell["row"], cell["col"]))
    return errors


def _random_int(state: dict[str, Any], bound: int) -> int:
    value = state["rng"] & MASK_32
    value ^= (value << 13) & MASK_32
    value ^= value >> 17
    value ^= (value << 5) & MASK_32
    state["rng"] = value & MASK_32
    return state["rng"] % bound


def _new_candy(state: dict[str, Any], color: int) -> dict[str, Any]:
    candy = {"id": state["nextId"], "color": color, "special": "none"}
    state["nextId"] += 1
    return candy


def _position(key: int, cols: int) -> list[int]:
    return [key // cols, key % cols]


def _match_color(candy: dict[str, Any] | None) -> int:
    return candy["color"] if candy and candy["special"] != "color" else -1


def _match_runs(board: list[list[Any]]) -> list[dict[str, Any]]:
    rows, cols = len(board), len(board[0]) if board else 0
    runs = []
    for r in range(rows):
        c = 0
        while c < cols:
            start, color = c, _match_color(board[r][c])
            c += 1
            while c < cols and color >= 0 and _match_color(board[r][c]) == color:
                c += 1
            if color >= 0 and c - start >= 3:
                runs.append({"direction": "row", "cells": [r * cols + cc for cc in range(start, c)]})
    for c in range(cols):
        r = 0
        while r < rows:
            start, color = r, _match_color(board[r][c])
            r += 1
            while r < rows and color >= 0 and _match_color(board[r][c]) == color:
                r += 1
            if color >= 0 and r - start >= 3:
                runs.append({"direction": "column", "cells": [rr * cols + c for rr in range(start, r)]})
    return runs


def find_matches(board: list[list[Any]]) -> list[list[int]]:
    cols = len(board[0]) if board else 0
    return [_position(key, cols) for key in sorted({key for run in _match_runs(board) for key in run["cells"]})]


def _line_at(board: list[list[Any]], at: list[int]) -> bool:
    r, c = at
    color = _match_color(board[r][c])
    if color < 0:
        return False
    rows, cols = len(board), len(board[0])
    for dr, dc in ((1, 0), (0, 1)):
        count = 1
        for sign in (-1, 1):
            rr, cc = r + dr * sign, c + dc * sign
            while 0 <= rr < rows and 0 <= cc < cols and _match_color(board[rr][cc]) == color:
                count += 1
                rr, cc = rr + dr * sign, cc + dc * sign
        if count >= 3:
            return True
    return False


def _special_swap(a: dict[str, Any], b: dict[str, Any]) -> bool:
    return a["special"] == "color" or b["special"] == "color" or (a["special"] != "none" and b["special"] != "none")


def find_valid_moves(board: list[list[Any]]) -> list[dict[str, list[int]]]:
    rows, cols = len(board), len(board[0]) if board else 0
    work = [row[:] for row in board]
    moves = []
    for r in range(rows):
        for c in range(cols):
            for dr, dc in ((0, 1), (1, 0)):
                rr, cc = r + dr, c + dc
                if rr >= rows or cc >= cols:
                    continue
                a, b = work[r][c], work[rr][cc]
                if not a or not b:
                    continue
                work[r][c], work[rr][cc] = b, a
                valid = _special_swap(a, b) or _line_at(work, [r, c]) or _line_at(work, [rr, cc])
                work[r][c], work[rr][cc] = a, b
                if valid:
                    moves.append({"from": [r, c], "to": [rr, cc]})
    return moves


def _fresh_board(state: dict[str, Any], level: dict[str, Any], force_move: bool = False) -> None:
    state["board"] = [[None] * level["cols"] for _ in range(level["rows"])]
    fixed = {0: 0, 1: 1, 2: 0, level["cols"] + 1: 0}
    for r in range(level["rows"]):
        for c in range(level["cols"]):
            allowed = []
            for color in range(level["colors"]):
                if c >= 2 and state["board"][r][c - 1]["color"] == color and state["board"][r][c - 2]["color"] == color:
                    continue
                if r >= 2 and state["board"][r - 1][c]["color"] == color and state["board"][r - 2][c]["color"] == color:
                    continue
                allowed.append(color)
            key = r * level["cols"] + c
            color = fixed[key] if force_move and key in fixed else allowed[_random_int(state, len(allowed))]
            state["board"][r][c] = _new_candy(state, color)


def _fill_playable(state: dict[str, Any], level: dict[str, Any]) -> None:
    for _ in range(100):
        _fresh_board(state, level)
        if find_valid_moves(state["board"]):
            return
    _fresh_board(state, level, True)


def create_game(level: dict[str, Any], seed: int) -> dict[str, Any]:
    errors = validate_level(level)
    if errors:
        raise ValueError(" ".join(errors))
    state = {
        "levelId": level["id"], "board": [],
        "blockers": [[0] * level["cols"] for _ in range(level["rows"])],
        "rng": (seed & MASK_32) or ZERO_SEED, "nextId": 1, "score": 0,
        "movesLeft": level["moves"], "collected": [0] * 6, "turn": 0,
        "status": "playing", "powers": {"hammer": 1, "shuffle": 1, "extra": 1},
    }
    for cell in level["blockers"]:
        state["blockers"][cell["row"]][cell["col"]] = cell["hp"]
    _fill_playable(state, level)
    return state


def _snapshot(state: dict[str, Any], kind: str, **extra: Any) -> dict[str, Any]:
    return {"kind": kind, "board": deepcopy(state["board"]), "blockers": deepcopy(state["blockers"]), **extra}


def _shuffle_board(state: dict[str, Any], level: dict[str, Any], frames: list[dict[str, Any]]) -> None:
    original = [candy for row in state["board"] for candy in row if candy is not None]
    for _ in range(512):
        pool = original[:]
        for i in range(len(pool) - 1, 0, -1):
            j = _random_int(state, i + 1)
            pool[i], pool[j] = pool[j], pool[i]
        state["board"] = [pool[r * level["cols"]:(r + 1) * level["cols"]] for r in range(level["rows"])]
        if not find_matches(state["board"]) and find_valid_moves(state["board"]):
            frames.append(_snapshot(state, "shuffle"))
            return
    # Some pathological distributions cannot be legally permuted. A bounded
    # refill preserves the special effects and prevents an unplayable state.
    specials = [candy["special"] for candy in original if candy["special"] != "none"]
    _fill_playable(state, level)
    for key, special in enumerate(specials):
        r, c = _position(key, level["cols"])
        state["board"][r][c]["special"] = special
    frames.append(_snapshot(state, "shuffle"))


def _creations(board: list[list[Any]], runs: list[dict[str, Any]], preferred: list[int]) -> dict[int, str]:
    cols = len(board[0])
    groups: list[dict[str, Any]] = []
    for run in runs:
        intersecting = [group for group in groups if any(key in group["cells"] for key in run["cells"])]
        group = {"cells": set(run["cells"]), "runs": [run]}
        for old in intersecting:
            group["cells"].update(old["cells"])
            group["runs"].extend(old["runs"])
            groups.remove(old)
        groups.append(group)
    groups.sort(key=lambda group: min(group["cells"]))
    result = {}
    for group in groups:
        longest = sorted(group["runs"], key=lambda run: -len(run["cells"]))[0]
        crossing = len({run["direction"] for run in group["runs"]}) > 1
        if len(longest["cells"]) < 4 and not crossing:
            continue
        special = "color" if len(longest["cells"]) >= 5 or crossing else longest["direction"]
        candidates = [key for key in sorted(group["cells"]) if board[key // cols][key % cols]["special"] == "none"]
        if not candidates:
            continue
        anchor = next((key for key in preferred if key in candidates), candidates[(len(candidates) - 1) // 2])
        result[anchor] = special
    return result


def _most_common_color(board: list[list[Any]]) -> int:
    counts = [0] * 6
    for row in board:
        for candy in row:
            if candy:
                counts[candy["color"]] += 1
    best = 0
    for color in range(1, 6):
        if counts[color] > counts[best]:
            best = color
    return best


def _expand_clear(state: dict[str, Any], initial: set[int], protected: set[int], targets: dict[int, int]) -> tuple[list[int], list[int]]:
    rows, cols = len(state["board"]), len(state["board"][0])
    pending, cleared, activated = set(initial), set(), set()

    def add(key: int) -> None:
        if key not in cleared and key not in protected:
            pending.add(key)

    while pending:
        key = min(pending)
        pending.remove(key)
        if key in cleared or key in protected:
            continue
        r, c = _position(key, cols)
        candy = state["board"][r][c]
        if not candy:
            continue
        cleared.add(key)
        if candy["special"] == "none" or key in activated:
            continue
        activated.add(key)
        if candy["special"] == "row":
            for cc in range(cols):
                add(r * cols + cc)
        elif candy["special"] == "column":
            for rr in range(rows):
                add(rr * cols + c)
        else:
            color = targets[key] if key in targets else _most_common_color(state["board"])
            for rr in range(rows):
                for cc in range(cols):
                    target = state["board"][rr][cc]
                    if target and (color == -1 or target["color"] == color):
                        add(rr * cols + cc)
    return sorted(cleared), sorted(activated)


def _gravity(state: dict[str, Any], level: dict[str, Any]) -> None:
    for c in range(level["cols"]):
        write = level["rows"] - 1
        for r in range(level["rows"] - 1, -1, -1):
            candy = state["board"][r][c]
            if candy:
                state["board"][write][c] = candy
                write -= 1
        while write >= 0:
            state["board"][write][c] = _new_candy(state, _random_int(state, level["colors"]))
            write -= 1


def _resolve(state: dict[str, Any], level: dict[str, Any], frames: list[dict[str, Any]], forced: list[int] | None = None,
             preferred: list[int] | None = None, targets: dict[int, int] | None = None) -> None:
    forced, preferred, targets = forced or [], preferred or [], targets or {}
    for combo in range(1, MAX_CASCADES + 1):
        runs = _match_runs(state["board"])
        if not runs and not forced:
            return
        created = _creations(state["board"], runs, preferred if combo == 1 else [])
        for key in forced:
            created.pop(key, None)
        initial = set(forced) | {key for run in runs for key in run["cells"]}
        cleared, activated = _expand_clear(state, initial, set(created), targets)
        if activated:
            frames.append(_snapshot(state, "special", cells=[_position(key, level["cols"]) for key in cleared], combo=combo))
        for key in cleared:
            r, c = _position(key, level["cols"])
            candy = state["board"][r][c]
            state["collected"][candy["color"]] += 1
            if state["blockers"][r][c] > 0:
                state["blockers"][r][c] -= 1
            state["board"][r][c] = None
        for key, special in created.items():
            r, c = _position(key, level["cols"])
            if state["board"][r][c]:
                state["board"][r][c] = {**state["board"][r][c], "special": special}
        size = len(cleared)
        score_delta = (size * 60 + max(0, size - 3) * 20) * min(combo, 8)
        state["score"] += score_delta
        frames.append(_snapshot(state, "clear", cells=[_position(key, level["cols"]) for key in cleared], scoreDelta=score_delta, combo=combo))
        _gravity(state, level)
        frames.append(_snapshot(state, "fall", combo=combo))
        forced, targets = [], {}
    if find_matches(state["board"]):
        _shuffle_board(state, level, frames)


def _evaluate(state: dict[str, Any], level: dict[str, Any]) -> None:
    won = (
        state["score"] >= level["target"]
        and all(state["collected"][goal["color"]] >= goal["count"] for goal in level["collections"])
        and all(hp == 0 for row in state["blockers"] for hp in row)
    )
    state["status"] = "won" if won else "lost" if state["movesLeft"] <= 0 else "playing"


def get_stars(state: dict[str, Any], level: dict[str, Any]) -> int:
    if state["status"] != "won":
        return 0
    return max(1, sum(state["score"] >= threshold for threshold in level["starThresholds"]))


def _valid_position(at: Any, state: dict[str, Any]) -> bool:
    return (
        isinstance(at, list) and len(at) == 2
        and all(isinstance(v, int) and not isinstance(v, bool) for v in at)
        and 0 <= at[0] < len(state["board"]) and 0 <= at[1] < len(state["board"][0])
    )


def apply_action(original: dict[str, Any], action: Any, level: dict[str, Any]) -> dict[str, Any]:
    def reject(message: str) -> dict[str, Any]:
        return {"accepted": False, "state": original, "frames": [], "message": message}

    if not isinstance(action, dict):
        return reject("Geçersiz işlem.")
    if original["levelId"] != level["id"]:
        return reject("Bölüm uyuşmuyor.")
    if original["status"] == "won":
        return reject("Bu bölüm tamamlandı.")
    kind = action.get("kind")
    if original["status"] == "lost" and kind != "extra":
        return reject("Hamlelerin bitti.")
    state, frames = clone_state(original), []
    if kind == "extra":
        if state["powers"]["extra"] <= 0:
            return reject("Ek hamle hakkını kullandın.")
        state["powers"]["extra"] -= 1
        state["movesLeft"] += 5
    elif kind == "shuffle":
        if state["powers"]["shuffle"] <= 0:
            return reject("Karıştırma hakkını kullandın.")
        state["powers"]["shuffle"] -= 1
        _shuffle_board(state, level, frames)
    elif kind == "hammer":
        if state["powers"]["hammer"] <= 0:
            return reject("Çekiç hakkını kullandın.")
        if not _valid_position(action.get("at"), state):
            return reject("Geçersiz hücre.")
        r, c = action["at"]
        if not state["board"][r][c]:
            return reject("Bu hücre boş.")
        state["powers"]["hammer"] -= 1
        _resolve(state, level, frames, [r * level["cols"] + c])
    elif kind == "swap":
        if not _valid_position(action.get("from"), state) or not _valid_position(action.get("to"), state):
            return reject("Geçersiz hücre.")
        r, c = action["from"]
        rr, cc = action["to"]
        if abs(r - rr) + abs(c - cc) != 1:
            return reject("Yalnızca yan yana şekerler yer değiştirebilir.")
        a, b = state["board"][r][c], state["board"][rr][cc]
        if not a or not b:
            return reject("Bu hücre boş.")
        state["board"][r][c], state["board"][rr][cc] = b, a
        combo_swap = _special_swap(a, b)
        if not combo_swap and not _line_at(state["board"], action["from"]) and not _line_at(state["board"], action["to"]):
            return reject("En az üç aynı renk şeker eşleştir.")
        state["movesLeft"] -= 1
        frames.append(_snapshot(state, "swap", **{"from": action["from"][:], "to": action["to"][:]}))
        first, second = r * level["cols"] + c, rr * level["cols"] + cc
        forced: list[int] = []
        targets: dict[int, int] = {}
        if combo_swap:
            forced.extend([first, second])
            if a["special"] == "color" and b["special"] == "color":
                targets[first], targets[second] = -1, -1
            elif a["special"] == "color" or b["special"] == "color":
                bomb_key = second if a["special"] == "color" else first
                partner = b if a["special"] == "color" else a
                targets[bomb_key] = partner["color"]
                for row in range(level["rows"]):
                    for col in range(level["cols"]):
                        candy = state["board"][row][col]
                        if not candy or candy["color"] != partner["color"]:
                            continue
                        forced.append(row * level["cols"] + col)
                        if partner["special"] not in ("none", "color") and candy["special"] != "color":
                            candy["special"] = partner["special"]
        _resolve(state, level, frames, forced, [second, first], targets)
    else:
        return reject("Geçersiz işlem.")
    state["turn"] += 1
    if find_matches(state["board"]) or not find_valid_moves(state["board"]):
        _shuffle_board(state, level, frames)
    _evaluate(state, level)
    return {"accepted": True, "state": state, "frames": frames}
