"""Sweet Odyssey API. Every saved result is independently replayed by Python."""
from __future__ import annotations

import hashlib
import json
import secrets
from contextlib import asynccontextmanager
from copy import deepcopy
from pathlib import Path
from typing import Any
from uuid import uuid4

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from .config import PROJECT_ROOT, get_database_url, get_cors_origins
from .database import Base, LevelProgress, Player, Run, make_engine, make_session_factory, utc_now
from .engine import apply_action, create_game, get_stars, validate_level
from .middleware import ApiBodyLimit
from .schemas import (
    CreatePlayer, FinishRun, RenamePlayer, StartRun,
    CreatePlayerOutput, FinishRunOutput, HealthOutput, LevelOutput,
    PlayerOutput, ProgressOutput, StartRunOutput, StatsOutput,
)

API_VERSION = "1.0.0"
ENGINE_VERSION = "1"
bearer = HTTPBearer(auto_error=False)


def load_levels(path: Path) -> list[dict[str, Any]]:
    levels = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(levels, list) or not levels:
        raise RuntimeError("Bölüm dosyası dolu bir liste olmalı.")
    for index, level in enumerate(levels, start=1):
        errors = validate_level(level)
        if errors or level.get("id") != index:
            raise RuntimeError(f"Bölüm {index} geçersiz: {errors or 'Bölüm numaraları sıralı olmalı.'}")
    return levels


def get_session(request: Request):
    with request.app.state.sessions() as session:
        yield session


def require_player(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
    session: Session = Depends(get_session),
) -> Player:
    if credentials is None or credentials.scheme.lower() != "bearer" or not 32 <= len(credentials.credentials) <= 128:
        raise HTTPException(401, "Oyuncu oturumu bulunamadı.", headers={"WWW-Authenticate": "Bearer"})
    digest = hashlib.sha256(credentials.credentials.encode("utf-8")).hexdigest()
    player = session.scalar(select(Player).where(Player.token_hash == digest))
    if player is None:
        raise HTTPException(401, "Oyuncu oturumu geçersiz. Yeni bir macera başlatabilirsin.", headers={"WWW-Authenticate": "Bearer"})
    return player


def progress_for(session: Session, player: Player) -> dict[str, Any]:
    rows = session.scalars(select(LevelProgress).where(LevelProgress.player_id == player.id).order_by(LevelProgress.level_id)).all()
    completed = {str(row.level_id): {"score": row.score, "stars": row.stars} for row in rows}
    return {"unlockedLevel": player.unlocked_level, "completed": completed, "totalStars": sum(row.stars for row in rows)}


def public_player(player: Player) -> dict[str, str]:
    return {"id": player.id, "nickname": player.nickname}


def run_response(session: Session, player: Player, run: Run) -> dict[str, Any]:
    return {"score": run.score, "stars": run.stars, "status": run.status, "progress": progress_for(session, player)}


def create_app(database_url: str | None = None, levels_path: Path | None = None, frontend_dir: Path | None = None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(application: FastAPI):
        engine = make_engine(database_url or get_database_url())
        application.state.engine = engine
        application.state.sessions = make_session_factory(engine)
        application.state.levels = load_levels(levels_path or PROJECT_ROOT / "shared" / "levels.json")
        Base.metadata.create_all(engine)
        try:
            yield
        finally:
            engine.dispose()

    application = FastAPI(
        title="Sweet Odyssey API",
        description="Misafir oyuncu profili, kalıcı ilerleme ve sunucuda doğrulanan oyun sonuçları.",
        version=API_VERSION,
        lifespan=lifespan,
    )
    application.add_middleware(ApiBodyLimit)
    origins = get_cors_origins()
    if origins:
        application.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False,
                                   allow_methods=["GET", "POST", "PATCH"], allow_headers=["Authorization", "Content-Type"])
    frontend = (frontend_dir or PROJECT_ROOT / "frontend" / "dist").resolve()

    @application.exception_handler(RequestValidationError)
    async def validation_error(_request: Request, exc: RequestValidationError):
        fields = [".".join(str(part) for part in error["loc"]) for error in exc.errors()]
        return JSONResponse(status_code=422, content={"detail": "Gönderilen bilgi geçersiz. Alanları kontrol et.", "fields": fields})

    @application.get("/api/health", response_model=HealthOutput, tags=["Sistem"])
    def health():
        return {"status": "ok", "app": "sweet-odyssey", "version": API_VERSION}

    @application.get("/api/levels", response_model=list[LevelOutput], tags=["Bölümler"])
    def get_levels(request: Request):
        return request.app.state.levels

    @application.post("/api/players", status_code=201, response_model=CreatePlayerOutput, tags=["Oyuncu"])
    def create_player(body: CreatePlayer, session: Session = Depends(get_session)):
        token = secrets.token_urlsafe(32)
        player = Player(id=str(uuid4()), token_hash=hashlib.sha256(token.encode("utf-8")).hexdigest(), nickname=body.nickname or "Gezgin", unlocked_level=1)
        session.add(player)
        session.commit()
        return {"token": token, "player": public_player(player), "progress": progress_for(session, player)}

    @application.patch("/api/players/me", response_model=PlayerOutput, tags=["Oyuncu"])
    def rename_player(body: RenamePlayer, player: Player = Depends(require_player), session: Session = Depends(get_session)):
        player.nickname = body.nickname
        session.commit()
        return public_player(player)

    @application.get("/api/progress", response_model=ProgressOutput, tags=["Oyuncu"])
    def progress(player: Player = Depends(require_player), session: Session = Depends(get_session)):
        return progress_for(session, player)

    @application.get("/api/stats", response_model=StatsOutput, tags=["Oyuncu"])
    def stats(player: Player = Depends(require_player), session: Session = Depends(get_session)):
        counts = dict(session.execute(select(Run.status, func.count()).where(Run.player_id == player.id).group_by(Run.status)).all())
        wins, losses = counts.get("won", 0), counts.get("lost", 0)
        saved = progress_for(session, player)
        best = session.scalar(select(func.max(Run.score)).where(Run.player_id == player.id)) or 0
        return {"finishedRuns": wins + losses, "wins": wins, "losses": losses, "startedRuns": sum(counts.values()), "bestScore": best,
                "winRate": round(wins / (wins + losses) * 100, 1) if wins + losses else 0,
                "completedLevels": len(saved["completed"]), "totalStars": saved["totalStars"], "unlockedLevel": saved["unlockedLevel"]}

    @application.post("/api/runs", status_code=201, response_model=StartRunOutput, tags=["Oyun"])
    def start_run(body: StartRun, request: Request, player: Player = Depends(require_player), session: Session = Depends(get_session)):
        levels = request.app.state.levels
        if body.level_id > len(levels):
            raise HTTPException(404, "Bu bölüm bulunamadı.")
        if body.level_id > player.unlocked_level:
            raise HTTPException(403, "Bu bölüm kilitli. Önce önceki bölümü tamamla.")
        level = deepcopy(levels[body.level_id - 1])
        seed = secrets.randbelow(0xFFFFFFFF) + 1
        run = Run(id=str(uuid4()), player_id=player.id, level_id=body.level_id, level_snapshot=level, seed=seed, engine_version=ENGINE_VERSION, status="started")
        session.add(run)
        session.commit()
        return {"id": run.id, "seed": seed, "level": level}

    @application.post("/api/runs/{run_id}/finish", response_model=FinishRunOutput, tags=["Oyun"])
    def finish_run(run_id: str, body: FinishRun, request: Request, player: Player = Depends(require_player), session: Session = Depends(get_session)):
        player_id = player.id
        actions = [action.model_dump(by_alias=True, mode="json") for action in body.actions]
        actions_hash = hashlib.sha256(json.dumps(actions, separators=(",", ":"), sort_keys=True).encode("utf-8")).hexdigest()
        # Auth performed a read transaction. Begin a fresh serialized write transaction:
        # SQLite uses BEGIN IMMEDIATE, PostgreSQL locks this player's row. This keeps
        # duplicate finishing and multiple simultaneous victories atomic across workers.
        session.rollback()
        if session.bind.dialect.name == "sqlite":
            session.execute(text("BEGIN IMMEDIATE"))
        player = session.scalar(select(Player).where(Player.id == player_id).with_for_update())
        run = session.scalar(select(Run).where(Run.id == run_id, Run.player_id == player_id).with_for_update())
        if run is None:
            raise HTTPException(404, "Bu oyun denemesi bulunamadı.")
        if run.status != "started":
            if run.actions_hash != actions_hash:
                raise HTTPException(409, "Bu oyun farklı bir hamle listesiyle zaten kaydedildi.")
            return run_response(session, player, run)
        if run.engine_version != ENGINE_VERSION:
            raise HTTPException(409, "Bu oyun eski bir sürümde başlatıldı. Bölümü yeniden başlat.")
        state = create_game(run.level_snapshot, run.seed)
        for index, action in enumerate(actions):
            result = apply_action(state, action, run.level_snapshot)
            if not result["accepted"]:
                raise HTTPException(422, f"{index + 1}. hamle oyun kurallarına uygun değil.")
            state = result["state"]
        if state["status"] not in ("won", "lost"):
            raise HTTPException(409, "Oyun henüz bitmedi. Sonuç kaydedilmedi.")
        run.status = state["status"]
        run.score = int(state["score"])
        run.stars = get_stars(state, run.level_snapshot)
        run.actions_hash = actions_hash
        run.actions = actions
        run.finished_at = utc_now()
        if run.status == "won":
            saved = session.get(LevelProgress, (player_id, run.level_id))
            if saved is None:
                saved = LevelProgress(player_id=player_id, level_id=run.level_id, score=run.score, stars=run.stars)
                session.add(saved)
            else:
                saved.score = max(saved.score, run.score)
                saved.stars = max(saved.stars, run.stars)
            player.unlocked_level = max(player.unlocked_level, min(run.level_id + 1, len(request.app.state.levels)))
        session.commit()
        return run_response(session, player, run)

    @application.api_route("/api/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"], include_in_schema=False)
    def missing_api(path: str):
        raise HTTPException(404, "API adresi bulunamadı.")

    @application.get("/{path:path}", include_in_schema=False)
    def frontend_file(path: str):
        candidate = (frontend / path).resolve()
        if not candidate.is_relative_to(frontend):
            raise HTTPException(404, "Dosya bulunamadı.")
        if candidate.is_file():
            cache = "no-cache" if candidate.name == "index.html" else "public, max-age=3600"
            return FileResponse(candidate, headers={"Cache-Control": cache, "X-Content-Type-Options": "nosniff"})
        if path.startswith("assets/") or Path(path).suffix:
            raise HTTPException(404, "Dosya bulunamadı.")
        index = frontend / "index.html"
        if index.is_file():
            return FileResponse(index, headers={"Cache-Control": "no-cache", "X-Content-Type-Options": "nosniff"})
        return JSONResponse(status_code=503, content={"detail": "Oyun arayüzü bulunamadı. ZIP dosyasının tamamını bir klasöre çıkar."})

    return application


app = create_app()
