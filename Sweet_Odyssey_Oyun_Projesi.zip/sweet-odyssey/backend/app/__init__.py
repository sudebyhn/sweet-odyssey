"""HTTP API, persistence and deterministic game verification."""
