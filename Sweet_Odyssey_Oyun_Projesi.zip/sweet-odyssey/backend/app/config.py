"""Small, explicit settings layer; no system-wide configuration is changed."""
from __future__ import annotations

import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def load_env_file(path: Path | None = None) -> None:
    """Read simple KEY=value .env entries without overriding the process env."""
    path = path or PROJECT_ROOT / ".env"
    if not path.is_file():
        return
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.removeprefix("export ").strip()
        value = value.strip()
        if not key or not key.replace("_", "a").isalnum():
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        os.environ.setdefault(key, value)


def get_database_url() -> str:
    load_env_file()
    explicit = os.environ.get("DATABASE_URL", "").strip()
    if explicit:
        # psycopg v3 is the only supported optional PostgreSQL driver.
        if explicit.startswith("postgres://"):
            return "postgresql+psycopg://" + explicit[len("postgres://"):]
        if explicit.startswith("postgresql://"):
            return "postgresql+psycopg://" + explicit[len("postgresql://"):]
        return explicit
    data_dir = Path(os.environ.get("SWEET_DATA_DIR", str(PROJECT_ROOT / "data"))).expanduser().resolve()
    data_dir.mkdir(parents=True, exist_ok=True)
    return "sqlite:///" + (data_dir / "sweet-odyssey.db").as_posix()


def get_cors_origins() -> list[str]:
    """Explicit development origins; empty means same-origin only."""
    from urllib.parse import urlsplit

    load_env_file()
    origins = []
    for raw in os.environ.get("CORS_ORIGINS", "").split(","):
        origin = raw.strip().rstrip("/")
        if not origin:
            continue
        parsed = urlsplit(origin)
        if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.path or parsed.query or parsed.fragment or parsed.username:
            raise RuntimeError("CORS_ORIGINS virgülle ayrılmış tam http(s) kaynak adresleri olmalı.")
        origins.append(origin)
    return origins
