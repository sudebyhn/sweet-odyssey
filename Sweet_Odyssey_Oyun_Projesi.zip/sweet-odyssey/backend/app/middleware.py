"""Bound request memory even if Content-Length is missing or misleading."""
from __future__ import annotations

from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Message, Receive, Scope, Send


class ApiBodyLimit:
    def __init__(self, app: ASGIApp, limit: int = 65536) -> None:
        self.app = app
        self.limit = limit

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or not scope.get("path", "").startswith("/api"):
            await self.app(scope, receive, send)
            return

        async def guarded_send(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers.extend([
                    (b"cache-control", b"no-store"),
                    (b"x-content-type-options", b"nosniff"),
                    (b"referrer-policy", b"no-referrer"),
                ])
                message["headers"] = headers
            await send(message)

        if scope.get("method") not in {"POST", "PUT", "PATCH"}:
            await self.app(scope, receive, guarded_send)
            return
        request_headers = dict(scope.get("headers", []))
        try:
            declared = int(request_headers.get(b"content-length", b"0"))
        except ValueError:
            declared = self.limit + 1
        if declared < 0 or declared > self.limit:
            await JSONResponse({"detail": "İstek en fazla 64 KB olabilir."}, status_code=413)(scope, receive, guarded_send)
            return
        body = bytearray()
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            body.extend(message.get("body", b""))
            if len(body) > self.limit:
                await JSONResponse({"detail": "İstek en fazla 64 KB olabilir."}, status_code=413)(scope, receive, guarded_send)
                return
            if not message.get("more_body", False):
                break
        consumed = False

        async def replay_body() -> Message:
            nonlocal consumed
            if consumed:
                return await receive()
            consumed = True
            return {"type": "http.request", "body": bytes(body), "more_body": False}

        await self.app(scope, replay_body, guarded_send)
