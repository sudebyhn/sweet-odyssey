from __future__ import annotations

import unicodedata
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StrictInt, field_validator


class InputModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


def clean_nickname(value: str) -> str:
    value = " ".join(unicodedata.normalize("NFC", value).split())
    if not 2 <= len(value) <= 24:
        raise ValueError("Oyuncu adı 2–24 karakter olmalı.")
    if any(unicodedata.category(character).startswith("C") for character in value):
        raise ValueError("Oyuncu adında görünmez kontrol karakterleri bulunamaz.")
    return value


class CreatePlayer(InputModel):
    nickname: str | None = None

    @field_validator("nickname")
    @classmethod
    def validate_nickname(cls, value: str | None) -> str | None:
        return clean_nickname(value) if value is not None else None


class RenamePlayer(InputModel):
    nickname: str

    @field_validator("nickname")
    @classmethod
    def validate_nickname(cls, value: str) -> str:
        return clean_nickname(value)


class StartRun(InputModel):
    level_id: Annotated[StrictInt, Field(ge=1, le=1000)]


Coordinate = Annotated[StrictInt, Field(ge=0, le=31)]
Position = Annotated[list[Coordinate], Field(min_length=2, max_length=2)]


class SwapAction(InputModel):
    kind: Literal["swap"]
    origin: Position = Field(alias="from")
    to: Position


class HammerAction(InputModel):
    kind: Literal["hammer"]
    at: Position


class ShuffleAction(InputModel):
    kind: Literal["shuffle"]


class ExtraAction(InputModel):
    kind: Literal["extra"]


Action = Annotated[SwapAction | HammerAction | ShuffleAction | ExtraAction, Field(discriminator="kind")]


class FinishRun(InputModel):
    actions: Annotated[list[Action], Field(max_length=128)]


# Explicit response models document the JSON contract consumed by the frontend.
class PlayerOutput(BaseModel):
    id: str
    nickname: str


class CompletionOutput(BaseModel):
    score: int
    stars: int


class ProgressOutput(BaseModel):
    unlockedLevel: int
    completed: dict[str, CompletionOutput]
    totalStars: int


class CreatePlayerOutput(BaseModel):
    token: str
    player: PlayerOutput
    progress: ProgressOutput


class CollectionGoal(BaseModel):
    color: int
    count: int


class FrostingCell(BaseModel):
    row: int
    col: int
    hp: int


class LevelOutput(BaseModel):
    id: int
    name: str
    realm: str
    description: str
    rows: int
    cols: int
    colors: int
    moves: int
    target: int
    collections: list[CollectionGoal]
    blockers: list[FrostingCell]
    starThresholds: tuple[int, int, int]
    difficulty: str


class StartRunOutput(BaseModel):
    id: str
    seed: int
    level: LevelOutput


class FinishRunOutput(BaseModel):
    score: int
    stars: int
    status: Literal["won", "lost"]
    progress: ProgressOutput


class StatsOutput(BaseModel):
    finishedRuns: int
    wins: int
    losses: int
    startedRuns: int
    bestScore: int
    winRate: float
    completedLevels: int
    totalStars: int
    unlockedLevel: int


class HealthOutput(BaseModel):
    status: Literal["ok"]
    app: str
    version: str
