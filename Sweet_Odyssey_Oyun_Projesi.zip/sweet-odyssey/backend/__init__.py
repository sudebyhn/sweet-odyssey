"""Sweet Odyssey server package."""
