"""API tests use real deterministic game actions, including a genuine replay."""
from __future__ import annotations

import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from backend.app.config import PROJECT_ROOT
from backend.app.database import Player, Run
from backend.app.engine import apply_action, create_game, find_valid_moves, get_stars
from backend.app.main import create_app


@pytest.fixture
def client(tmp_path):
    application = create_app(database_url="sqlite:///" + str(tmp_path / "game.db"))
    with TestClient(application) as connection:
        yield connection


def account(client, nickname="Tatlı Gezgin"):
    response = client.post("/api/players", json={"nickname": nickname})
    assert response.status_code == 201, response.text
    profile = response.json()
    return {"Authorization": "Bearer " + profile["token"]}, profile


def start(client, headers, level=1):
    response = client.post("/api/runs", headers=headers, json={"level_id": level})
    assert response.status_code == 201, response.text
    return response.json()


def play(run, greedy=True):
    level = run["level"]
    state = create_game(level, run["seed"])
    actions = []
    for _ in range(100):
        if state["status"] != "playing":
            break
        choices = find_valid_moves(state["board"])
        assert choices, "Engine must return a playable settled board."
        ranked = []
        for move in choices if greedy else choices[:1]:
            action = {"kind": "swap", **move}
            result = apply_action(state, action, level)
            assert result["accepted"]
            candidate = result["state"]
            collection = sum(min(candidate["collected"][goal["color"]], goal["count"]) for goal in level["collections"])
            frosting = sum(sum(row) for row in candidate["blockers"])
            ranked.append(((candidate["status"] == "won", collection * 80 - frosting * 150 + candidate["score"]), action, candidate))
        _, action, state = max(ranked, key=lambda item: item[0])
        actions.append(action)
    assert state["status"] in ("won", "lost")
    return actions, state


def tiny_client(tmp_path, target=30, moves=1):
    """A one-move level exercises API persistence using actual engine rules."""
    levels = json.loads((PROJECT_ROOT / "shared" / "levels.json").read_text(encoding="utf-8"))
    first = deepcopy(levels[0])
    first.update(target=target, moves=moves, collections=[], blockers=[], starThresholds=[target, target + 500, target + 1000])
    second = deepcopy(first)
    second["id"] = 2
    path = tmp_path / "levels.json"
    path.write_text(json.dumps([first, second]), encoding="utf-8")
    return TestClient(create_app(database_url="sqlite:///" + str(tmp_path / "tiny.db"), levels_path=path))


def test_health_levels_and_missing_api(client):
    assert client.get("/api/health").json()["app"] == "sweet-odyssey"
    levels = client.get("/api/levels").json()
    assert [level["id"] for level in levels] == list(range(1, 21))
    assert client.get("/api/missing").status_code == 404


def test_guest_token_authentication_and_private_storage(client):
    assert client.get("/api/progress").status_code == 401
    assert client.get("/api/stats", headers={"Authorization": "Bearer " + "x" * 43}).status_code == 401
    headers, profile = account(client)
    assert len(profile["token"]) >= 40
    assert profile["progress"] == {"unlockedLevel": 1, "completed": {}, "totalStars": 0}
    with client.app.state.sessions() as session:
        row = session.get(Player, profile["player"]["id"])
        assert row.token_hash == hashlib.sha256(profile["token"].encode()).hexdigest()
        assert row.token_hash != profile["token"]
    assert client.get("/api/progress", headers=headers).status_code == 200


def test_profile_validation_and_isolation(client):
    headers, _ = account(client)
    other, other_profile = account(client, "İkinci Gezgin")
    response = client.patch("/api/players/me", headers=headers, json={"nickname": "  Kerem   Taşkıran  "})
    assert response.json()["nickname"] == "Kerem Taşkıran"
    assert client.patch("/api/players/me", headers=headers, json={"nickname": "K"}).status_code == 422
    assert client.patch("/api/players/me", headers=headers, json={"nickname": "Test", "unlockedLevel": 20}).status_code == 422
    assert client.post("/api/players", json={"nickname": "Test\u200b"}).status_code == 422
    response = client.patch("/api/players/me", headers=other, json={"nickname": "İkinci Gezgin"})
    assert response.json()["id"] == other_profile["player"]["id"]


def test_locked_and_invalid_levels(client):
    headers, _ = account(client)
    assert client.post("/api/runs", headers=headers, json={"level_id": 2}).status_code == 403
    assert client.post("/api/runs", headers=headers, json={"level_id": 21}).status_code == 404
    for value in (0, True, 1.5, "1"):
        assert client.post("/api/runs", headers=headers, json={"level_id": value}).status_code == 422
    run = start(client, headers)
    assert 1 <= run["seed"] <= 0xFFFFFFFF


def test_nonterminal_invalid_and_forged_finishes(client):
    headers, _ = account(client)
    run = start(client, headers)
    endpoint = f'/api/runs/{run["id"]}/finish'
    assert client.post(endpoint, headers=headers, json={"actions": []}).status_code == 409
    assert client.post(endpoint, headers=headers, json={"actions": [], "score": 999999}).status_code == 422
    invalid = {"kind": "swap", "from": [0, 0], "to": [4, 4]}
    assert client.post(endpoint, headers=headers, json={"actions": [invalid]}).status_code == 422
    for bad in ({"kind": "hammer", "at": [False, 0]}, {"kind": "swap", "from": [0, 0], "to": [0, 1], "score": 9000}):
        assert client.post(endpoint, headers=headers, json={"actions": [bad]}).status_code == 422
    with client.app.state.sessions() as session:
        assert session.get(Run, run["id"]).status == "started"
    assert client.get("/api/progress", headers=headers).json()["unlockedLevel"] == 1


def test_run_ownership(client):
    first, _ = account(client)
    second, _ = account(client)
    run = start(client, first)
    assert client.post(f'/api/runs/{run["id"]}/finish', headers=second, json={"actions": []}).status_code == 404
    assert client.post("/api/runs/no-such-run/finish", headers=first, json={"actions": []}).status_code == 404


def test_real_canonical_level_replay_score_and_unlock(client):
    headers, _ = account(client)
    # Seed 42 is fixed in this test only through the cryptorandom source at run
    # creation. The HTTP request has no ability to choose or override it.
    from unittest.mock import patch
    with patch("backend.app.main.secrets.randbelow", return_value=41):
        run = start(client, headers)
    actions, state = play(run)
    assert state["status"] == "won", "Canonical opening level should be achievable."
    response = client.post(f'/api/runs/{run["id"]}/finish', headers=headers, json={"actions": actions})
    assert response.status_code == 200, response.text
    result = response.json()
    assert result["score"] == state["score"]
    assert result["stars"] == get_stars(state, run["level"])
    assert result["status"] == "won"
    assert result["progress"]["unlockedLevel"] == 2
    assert result["progress"]["completed"]["1"]["score"] == state["score"]
    assert start(client, headers, 2)["level"]["id"] == 2


def test_duplicate_finish_is_idempotent_and_changed_payload_is_rejected(tmp_path):
    with tiny_client(tmp_path) as client:
        headers, _ = account(client)
        run = start(client, headers)
        actions, state = play(run)
        assert state["status"] == "won"
        endpoint = f'/api/runs/{run["id"]}/finish'
        first = client.post(endpoint, headers=headers, json={"actions": actions})
        second = client.post(endpoint, headers=headers, json={"actions": actions})
        assert first.status_code == second.status_code == 200
        assert first.json() == second.json()
        assert client.post(endpoint, headers=headers, json={"actions": actions + [{"kind": "shuffle"}]}).status_code == 409
        stats = client.get("/api/stats", headers=headers).json()
        assert stats["finishedRuns"] == stats["wins"] == 1
        assert stats["losses"] == 0


def test_concurrent_duplicate_finishes_count_one_win(tmp_path):
    with tiny_client(tmp_path) as client:
        headers, _ = account(client)
        run = start(client, headers)
        actions, _ = play(run)
        endpoint = f'/api/runs/{run["id"]}/finish'
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(client.post, endpoint, headers=headers, json={"actions": actions}) for _ in range(2)]
            responses = [future.result() for future in futures]
        assert [response.status_code for response in responses] == [200, 200]
        assert client.get("/api/stats", headers=headers).json()["wins"] == 1


def test_lost_run_does_not_unlock_or_award_stars(tmp_path):
    with tiny_client(tmp_path, target=1000000) as client:
        headers, _ = account(client)
        run = start(client, headers)
        actions, state = play(run, greedy=False)
        assert state["status"] == "lost"
        response = client.post(f'/api/runs/{run["id"]}/finish', headers=headers, json={"actions": actions})
        assert response.status_code == 200, response.text
        assert response.json() == {"score": state["score"], "status": "lost", "stars": 0, "progress": {"unlockedLevel": 1, "completed": {}, "totalStars": 0}}
        assert client.get("/api/stats", headers=headers).json()["losses"] == 1


def test_started_run_keeps_its_level_snapshot(tmp_path):
    with tiny_client(tmp_path) as client:
        headers, _ = account(client)
        run = start(client, headers)
        actions, _ = play(run)
        client.app.state.levels[0]["target"] = 1000000
        response = client.post(f'/api/runs/{run["id"]}/finish', headers=headers, json={"actions": actions})
        assert response.status_code == 200
        assert response.json()["status"] == "won"


def test_progress_survives_server_restart(tmp_path):
    with tiny_client(tmp_path) as client:
        headers, _ = account(client)
        run = start(client, headers)
        actions, _ = play(run)
        saved = client.post(f'/api/runs/{run["id"]}/finish', headers=headers, json={"actions": actions}).json()["progress"]
    with tiny_client(tmp_path) as restarted:
        assert restarted.get("/api/progress", headers=headers).json() == saved
        assert restarted.get("/api/stats", headers=headers).json()["wins"] == 1


def test_limits_for_action_count_and_chunked_body(client):
    headers, _ = account(client)
    run = start(client, headers)
    endpoint = f'/api/runs/{run["id"]}/finish'
    assert client.post(endpoint, headers=headers, json={"actions": [{"kind": "shuffle"}] * 129}).status_code == 422
    assert client.post(endpoint, headers=headers, content=b" " * 70000).status_code == 413
    chunked = iter([b" " * 32768, b" " * 32768, b" " * 500])
    assert client.post(endpoint, headers=headers, content=chunked).status_code == 413


def test_static_files_and_spa_fallback(tmp_path):
    frontend = tmp_path / "dist"
    frontend.mkdir()
    (frontend / "index.html").write_text("<html><title>Sweet Odyssey</title></html>", encoding="utf-8")
    with TestClient(create_app(database_url="sqlite://", frontend_dir=frontend)) as client:
        assert "Sweet Odyssey" in client.get("/").text
        assert client.get("/harita").status_code == 200
        assert client.get("/assets/missing.js").status_code == 404
        assert client.get("/%2e%2e/requirements.txt").status_code == 404
        assert client.get("/").headers["cache-control"] == "no-cache"


def test_cors_allows_only_explicit_configured_origins(tmp_path, monkeypatch):
    monkeypatch.setenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
    with TestClient(create_app(database_url="sqlite://")) as client:
        allowed = client.options("/api/runs", headers={"Origin": "http://localhost:5173", "Access-Control-Request-Method": "POST", "Access-Control-Request-Headers": "authorization,content-type"})
        assert allowed.status_code == 200
        assert allowed.headers["access-control-allow-origin"] == "http://localhost:5173"
        assert "access-control-allow-credentials" not in allowed.headers
        denied = client.options("/api/runs", headers={"Origin": "http://unrelated.example", "Access-Control-Request-Method": "POST"})
        assert denied.status_code == 400
        assert "access-control-allow-origin" not in denied.headers


def test_cors_wildcard_is_not_accepted(monkeypatch):
    monkeypatch.setenv("CORS_ORIGINS", "*")
    with pytest.raises(RuntimeError, match="CORS_ORIGINS"):
        create_app(database_url="sqlite://")
