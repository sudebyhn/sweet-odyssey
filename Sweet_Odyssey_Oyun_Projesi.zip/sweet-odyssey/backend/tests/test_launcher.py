"""Launcher checks never install or modify global packages."""
import importlib.util
from pathlib import Path
import subprocess
import sys

import pytest

from backend.app.config import PROJECT_ROOT


def launcher_module():
    specification = importlib.util.spec_from_file_location("sweet_launcher", PROJECT_ROOT / "app.py")
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def test_launcher_help_does_not_start_game():
    result = subprocess.run([sys.executable, str(PROJECT_ROOT / "app.py"), "--help"], capture_output=True, text=True, timeout=10)
    assert result.returncode == 0
    assert "--no-browser" in result.stdout
    assert "--port" in result.stdout


def test_requested_port_is_respected_and_default_falls_back(monkeypatch):
    launcher = launcher_module()
    monkeypatch.setenv("SWEET_PORT", "8000")
    monkeypatch.setattr(launcher, "port_available", lambda port: port == 8001)
    assert launcher.choose_port(None) == 8001
    assert launcher.choose_port(8001) == 8001
    with pytest.raises(RuntimeError):
        launcher.choose_port(8000)
    with pytest.raises(RuntimeError):
        launcher.choose_port(1)
