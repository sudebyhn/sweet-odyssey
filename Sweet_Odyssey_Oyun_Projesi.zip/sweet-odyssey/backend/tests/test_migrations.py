from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import inspect

from backend.app.config import PROJECT_ROOT
from backend.app.database import Base, make_engine


def test_initial_migration_on_empty_sqlite_and_existing_local_schema(tmp_path, monkeypatch):
    config = Config(str(PROJECT_ROOT / "alembic.ini"))
    for index, initialize_local in enumerate((False, True)):
        url = "sqlite:///" + str(tmp_path / f"migration-{index}.db")
        monkeypatch.setenv("DATABASE_URL", url)
        engine = make_engine(url)
        if initialize_local:
            Base.metadata.create_all(engine)
        command.upgrade(config, "head")
        assert set(inspect(engine).get_table_names()) == {"players", "runs", "level_progress", "alembic_version"}
        command.upgrade(config, "head")
        with engine.connect() as connection:
            assert connection.exec_driver_sql("SELECT version_num FROM alembic_version").scalar() == "0001_initial"
        engine.dispose()
