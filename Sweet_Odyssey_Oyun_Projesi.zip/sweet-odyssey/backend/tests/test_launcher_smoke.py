"""Opt-in real bootstrap test (downloads pinned packages into a temporary venv).

SWEET_TEST_LAUNCHER=1 python -m pytest backend/tests/test_launcher_smoke.py -q
No global packages, real user profiles or source database are modified.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.request

import pytest

from backend.app.config import PROJECT_ROOT


@pytest.mark.skipif(os.environ.get("SWEET_TEST_LAUNCHER") != "1", reason="Opt-in: real package bootstrap and local HTTP server.")
def test_clean_first_run_then_warm_restart(tmp_path):
    shutil.copy2(PROJECT_ROOT / "app.py", tmp_path / "app.py")
    shutil.copytree(PROJECT_ROOT / "backend", tmp_path / "backend", ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache", "tests"))
    shutil.copytree(PROJECT_ROOT / "shared", tmp_path / "shared")
    dist = tmp_path / "frontend" / "dist"
    dist.mkdir(parents=True)
    (dist / "index.html").write_text("<!doctype html><title>Sweet Odyssey launcher check</title>", encoding="utf-8")
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    url = f"http://127.0.0.1:{port}"
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    env = os.environ.copy()
    env.pop("DATABASE_URL", None)
    env["SWEET_DATA_DIR"] = str(tmp_path / "data")
    token = None
    for iteration in (1, 2):
        log_path = tmp_path / f"launch-{iteration}.log"
        with log_path.open("w", encoding="utf-8") as log:
            process = subprocess.Popen([sys.executable, str(tmp_path / "app.py"), "--no-browser", "--port", str(port)], cwd=tmp_path, stdout=log, stderr=subprocess.STDOUT, env=env)
            ready = False
            try:
                deadline = time.monotonic() + 120
                while time.monotonic() < deadline and process.poll() is None:
                    try:
                        with opener.open(url + "/api/health", timeout=1) as response:
                            health = json.load(response)
                        if health.get("app") == "sweet-odyssey":
                            ready = True
                            break
                    except (OSError, ValueError):
                        pass
                    time.sleep(0.2)
                assert ready, log_path.read_text(encoding="utf-8")
                with opener.open(url + "/api/levels", timeout=2) as response:
                    assert len(json.load(response)) == 20
                venv_python = tmp_path / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
                assert venv_python.is_file()
                assert (tmp_path / ".venv" / ".sweet-requirements.sha256").is_file()
                assert (tmp_path / "data" / "sweet-odyssey.db").is_file()
                if iteration == 1:
                    request = urllib.request.Request(url + "/api/players", data=b'{}', headers={"Content-Type": "application/json"}, method="POST")
                    with opener.open(request, timeout=2) as response:
                        profile = json.load(response)
                    token = profile["token"]
                else:
                    request = urllib.request.Request(url + "/api/progress", headers={"Authorization": "Bearer " + token})
                    with opener.open(request, timeout=2) as response:
                        assert json.load(response) == profile["progress"]
            finally:
                if process.poll() is None:
                    if os.name == "nt":
                        # Stop only the temporary launcher and its own server child.
                        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
                    else:
                        process.send_signal(signal.SIGINT)
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
        logs = log_path.read_text(encoding="utf-8")
        if iteration == 1:
            assert "İlk açılış" in logs and "paketler kuruluyor" in logs.lower(), logs
        else:
            assert "İlk açılış" not in logs and "paketler kuruluyor" not in logs.lower(), logs
