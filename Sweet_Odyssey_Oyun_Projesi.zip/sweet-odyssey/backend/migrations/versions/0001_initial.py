"""Initial persistent players, verified runs and level progress.

Revision ID: 0001_initial
Revises: None
"""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # checkfirst supports a local database initialized by app.py before Alembic
    # was used. Future revisions should use explicit, incremental operations.
    bind = op.get_bind()
    metadata = sa.MetaData()
    sa.Table(
        "players", metadata,
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("token_hash", sa.String(64), nullable=False, unique=True, index=True),
        sa.Column("nickname", sa.String(24), nullable=False),
        sa.Column("unlocked_level", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("unlocked_level >= 1", name="ck_player_unlocked"),
    )
    sa.Table(
        "level_progress", metadata,
        sa.Column("player_id", sa.String(36), sa.ForeignKey("players.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("level_id", sa.Integer(), primary_key=True),
        sa.Column("score", sa.Integer(), nullable=False),
        sa.Column("stars", sa.Integer(), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("score >= 0", name="ck_progress_score"),
        sa.CheckConstraint("stars >= 1 AND stars <= 3", name="ck_progress_stars"),
    )
    sa.Table(
        "runs", metadata,
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("player_id", sa.String(36), sa.ForeignKey("players.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("level_id", sa.Integer(), nullable=False),
        sa.Column("level_snapshot", sa.JSON(), nullable=False),
        sa.Column("seed", sa.BigInteger(), nullable=False),
        sa.Column("engine_version", sa.String(16), nullable=False),
        sa.Column("status", sa.String(12), nullable=False),
        sa.Column("score", sa.Integer(), nullable=True),
        sa.Column("stars", sa.Integer(), nullable=True),
        sa.Column("actions_hash", sa.String(64), nullable=True),
        sa.Column("actions", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.CheckConstraint("status IN ('started', 'won', 'lost')", name="ck_run_status"),
        sa.CheckConstraint("seed > 0 AND seed <= 4294967295", name="ck_run_seed"),
    )
    metadata.create_all(bind=bind, checkfirst=True)


def downgrade():
    op.drop_table("runs")
    op.drop_table("level_progress")
    op.drop_table("players")
