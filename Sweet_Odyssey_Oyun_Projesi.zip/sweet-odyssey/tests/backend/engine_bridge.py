"""JSON stdin/stdout bridge for Vitest's exact Python/TypeScript parity check."""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from backend.app.engine import apply_action, create_game  # noqa: E402


def main():
    request = json.load(sys.stdin)
    output = []
    for case in request["cases"]:
        state = case.get("state") or create_game(case["level"], case["seed"])
        trace = [{"initial": state}]
        for action in case["actions"]:
            result = apply_action(state, action, case["level"])
            trace.append(result)
            state = result["state"]
        output.append(trace)
    json.dump(output, sys.stdout, ensure_ascii=False, separators=(",", ":"))


if __name__ == "__main__":
    main()
