"""Behavioral engine tests. Tests use actual legal moves, never force victories."""

import json
from copy import deepcopy
from pathlib import Path

import pytest

from backend.app.engine import (
    apply_action,
    create_game,
    find_matches,
    find_valid_moves,
    get_stars,
    validate_level,
)

LEVELS = json.loads((Path(__file__).resolve().parents[2] / "shared/levels.json").read_text())
WIN_FIXTURES = json.loads((Path(__file__).resolve().parents[1] / "fixtures/level_wins.json").read_text())


def level_with(**changes):
    return {**deepcopy(LEVELS[0]), **changes}


def endless_level(**changes):
    return level_with(target=1000000, starThresholds=[1000000, 1000001, 1000002], **changes)


def swap_first(state, level):
    return apply_action(state, {"kind": "swap", **find_valid_moves(state["board"])[0]}, level)


def first_clear(result):
    return next(frame for frame in result["frames"] if frame["kind"] == "clear")


def assert_pristine(state):
    assert not find_matches(state["board"])
    assert find_valid_moves(state["board"])
    candies = [c for row in state["board"] for c in row]
    assert all(c is not None for c in candies)
    assert len({c["id"] for c in candies}) == len(candies)
    assert all(hp >= 0 for row in state["blockers"] for hp in row)


def test_all_twenty_levels_have_valid_distinct_definitions():
    assert [level["id"] for level in LEVELS] == list(range(1, 21))
    assert all(not validate_level(level) for level in LEVELS)
    assert len({level["name"] for level in LEVELS}) == 20
    assert LEVELS[0]["blockers"] == []
    assert LEVELS[-1]["target"] > LEVELS[0]["target"]
    assert max(cell["hp"] for cell in LEVELS[-1]["blockers"]) == 2


@pytest.mark.parametrize("changes", [
    {"rows": 2}, {"colors": 4}, {"moves": 0}, {"target": -5},
    {"starThresholds": [5, 4, 3]}, {"name": ""},
    {"collections": [{"color": 0, "count": 1}, {"color": 0, "count": 2}]},
    {"blockers": [{"row": 8, "col": 0, "hp": 1}]},
    {"blockers": [{"row": 0, "col": 0, "hp": 1}, {"row": 0, "col": 0, "hp": 1}]},
])
def test_invalid_level_definitions_fail_early(changes):
    level = level_with(**changes)
    assert validate_level(level)
    with pytest.raises(ValueError):
        create_game(level, 42)


@pytest.mark.parametrize("level", LEVELS, ids=lambda level: f"level-{level['id']}")
def test_each_level_generates_pristine_boards_for_twenty_seeds(level):
    for seed in [0, 1, 2, 42, 0xFFFFFFFF, *range(101, 116)]:
        state = create_game(level, seed)
        assert_pristine(state)
        assert state["score"] == 0
        assert state["movesLeft"] == level["moves"]
        assert state["collected"] == [0] * 6
        assert all(0 <= c["color"] < level["colors"] for row in state["board"] for c in row)


def test_seeded_initialization_and_actions_are_repeatable():
    a, b = create_game(LEVELS[0], 123), create_game(LEVELS[0], 123)
    assert a == b
    assert a != create_game(LEVELS[0], 124)
    assert swap_first(a, LEVELS[0]) == swap_first(b, LEVELS[0])


def test_horizontal_vertical_cross_matches_are_deduplicated_and_bombs_are_not_colors():
    colors = [[1, 0, 2], [0, 0, 0], [2, 0, 1]]
    board = [[{"id": r * 3 + c, "color": color, "special": "none"} for c, color in enumerate(row)] for r, row in enumerate(colors)]
    assert find_matches(board) == [[0, 1], [1, 0], [1, 1], [1, 2], [2, 1]]
    board[1][1]["special"] = "color"
    assert find_matches(board) == []
    board[1][1] = None
    assert find_matches(board) == []


@pytest.mark.parametrize("action", [
    {"kind": "swap", "from": [-1, 0], "to": [0, 0]},
    {"kind": "swap", "from": [0, 0], "to": [8, 0]},
    {"kind": "swap", "from": [0, 0], "to": [1, 1]},
    {"kind": "swap", "from": [0, 0], "to": [0, 2]},
    {"kind": "swap", "from": [0, 0], "to": [0, 0]},
    {"kind": "swap", "from": [0, 0], "to": [0, 1]},
    {"kind": "swap", "from": [False, 0], "to": [0, 1]},
    {"kind": "swap", "from": [0, 0]}, {"kind": "unknown"}, None,
])
def test_invalid_swaps_do_not_change_any_state_or_rng(action):
    state = create_game(LEVELS[0], 1)
    before = deepcopy(state)
    result = apply_action(state, action, LEVELS[0])
    assert not result["accepted"]
    assert result["state"] is state
    assert result["frames"] == []
    assert state == before


def test_valid_move_consumes_one_move_scores_actual_candies_and_keeps_input_immutable():
    state = create_game(LEVELS[0], 1)
    before = deepcopy(state)
    result = swap_first(state, LEVELS[0])
    assert result["accepted"]
    assert state == before
    assert result["state"]["movesLeft"] == state["movesLeft"] - 1
    assert result["state"]["score"] == 180
    assert sum(result["state"]["collected"]) == 3
    assert [frame["kind"] for frame in result["frames"]] == ["swap", "clear", "fall"]
    assert_pristine(result["state"])
    snapshot = deepcopy(result["frames"])
    result["state"]["board"][0][0]["color"] = 999
    assert result["frames"] == snapshot


def test_gravity_preserves_survivor_order_and_spawns_unique_ids():
    state = create_game(LEVELS[0], 42)
    result = swap_first(state, LEVELS[0])
    for index, clear in enumerate(result["frames"]):
        if clear["kind"] != "clear":
            continue
        fall = result["frames"][index + 1]
        assert fall["kind"] == "fall"
        for c in range(8):
            survivors = [row[c]["id"] for row in clear["board"] if row[c]]
            falling = [row[c]["id"] for row in fall["board"]]
            assert falling[len(falling) - len(survivors):] == survivors
    assert_pristine(result["state"])


def test_cascade_multiplier_and_score_sum():
    state = create_game(LEVELS[0], 42)
    result = swap_first(state, LEVELS[0])
    clears = [frame for frame in result["frames"] if frame["kind"] == "clear"]
    assert [frame["combo"] for frame in clears] == [1, 2]
    assert [frame["scoreDelta"] for frame in clears] == [180, 360]
    assert result["state"]["score"] == 540
    assert sum(result["state"]["collected"]) == sum(len(frame["cells"]) for frame in clears)


@pytest.mark.parametrize("seed,move,special", [
    (4, {"from": [3, 3], "to": [4, 3]}, "row"),
    (3, {"from": [2, 5], "to": [2, 6]}, "column"),
    (8, {"from": [4, 4], "to": [4, 5]}, "color"),
    (3, {"from": [1, 6], "to": [2, 6]}, "color"),
])
def test_four_five_and_cross_matches_create_real_specials(seed, move, special):
    state = create_game(LEVELS[0], seed)
    result = apply_action(state, {"kind": "swap", **move}, LEVELS[0])
    clear = first_clear(result)
    r, c = move["to"]
    assert clear["board"][r][c]["special"] == special
    assert move["to"] not in clear["cells"]
    assert_pristine(result["state"])


def test_hammer_triggers_a_line_chain_once_per_cell():
    level = endless_level()
    state = create_game(level, 1)
    state["board"][3][3]["special"] = "row"
    state["board"][3][6]["special"] = "column"
    result = apply_action(state, {"kind": "hammer", "at": [3, 3]}, level)
    clear = first_clear(result)
    expected = {(3, c) for c in range(8)} | {(r, 6) for r in range(8)}
    assert {tuple(cell) for cell in clear["cells"]} == expected
    assert len(clear["cells"]) == 15
    assert result["state"]["movesLeft"] == state["movesLeft"]
    assert result["state"]["powers"]["hammer"] == 0
    assert any(frame["kind"] == "special" for frame in result["frames"])
    assert not apply_action(result["state"], {"kind": "hammer", "at": [0, 0]}, level)["accepted"]


def test_double_bomb_clears_every_cell_and_single_layer_exactly_once():
    level = endless_level(blockers=[{"row": 0, "col": 0, "hp": 2}])
    state = create_game(level, 1)
    state["board"][0][0]["special"] = "color"
    state["board"][0][1]["special"] = "color"
    result = apply_action(state, {"kind": "swap", "from": [0, 0], "to": [0, 1]}, level)
    clear = first_clear(result)
    assert len(clear["cells"]) == 64
    assert clear["blockers"][0][0] == 1
    assert all(c is None for row in clear["board"] for c in row)
    assert_pristine(result["state"])


@pytest.mark.parametrize("partner_special", ["none", "row", "column"])
def test_color_bomb_uses_partner_color_and_stripe_combinations(partner_special):
    level = endless_level()
    state = create_game(level, 1)
    state["board"][0][0]["special"] = "color"
    state["board"][0][1]["special"] = partner_special
    target_color = state["board"][0][1]["color"]
    result = apply_action(state, {"kind": "swap", "from": [0, 0], "to": [0, 1]}, level)
    swapped, clear = result["frames"][0]["board"], first_clear(result)
    required = {(r, c) for r, row in enumerate(swapped) for c, candy in enumerate(row) if candy["color"] == target_color}
    assert required <= {tuple(cell) for cell in clear["cells"]}
    assert [0, 1] in clear["cells"]
    assert_pristine(result["state"])


def test_frosting_requires_hits_in_that_fixed_cell_and_all_objectives_are_required():
    level = endless_level(blockers=[{"row": 0, "col": 0, "hp": 2}], collections=[{"color": 0, "count": 2}])
    state = create_game(level, 1)
    state["score"] = level["target"]
    state["collected"][0] = 2
    result = apply_action(state, {"kind": "hammer", "at": [0, 0]}, level)
    assert first_clear(result)["blockers"][0][0] == 1
    assert result["state"]["status"] == "playing"
    assert result["state"]["blockers"][0][0] == 1


def test_last_move_victory_has_priority_over_loss_and_stars_use_verified_score():
    level = level_with(moves=1, target=1, starThresholds=[1, 200, 500])
    state = create_game(level, 1)
    result = swap_first(state, level)
    assert result["state"]["movesLeft"] == 0
    assert result["state"]["status"] == "won"
    assert get_stars(result["state"], level) == 1
    assert not apply_action(result["state"], {"kind": "extra"}, level)["accepted"]


def test_loss_extra_moves_revive_once_and_normal_actions_are_blocked_when_lost():
    level = endless_level(moves=1)
    lost = swap_first(create_game(level, 1), level)["state"]
    assert lost["status"] == "lost" and get_stars(lost, level) == 0
    assert not swap_first(lost, level)["accepted"]
    revived = apply_action(lost, {"kind": "extra"}, level)
    assert revived["accepted"] and revived["state"]["status"] == "playing"
    assert revived["state"]["movesLeft"] == 5
    assert not apply_action(revived["state"], {"kind": "extra"}, level)["accepted"]


def test_reaching_score_without_collection_goal_does_not_win():
    level = level_with(moves=1, target=1, starThresholds=[1, 2, 3], collections=[{"color": 4, "count": 100}])
    result = swap_first(create_game(level, 1), level)
    assert result["state"]["score"] >= level["target"]
    assert result["state"]["status"] == "lost"


def test_manual_shuffle_preserves_inventory_blockers_score_and_moves():
    level = LEVELS[7]
    state = create_game(level, 42)
    before_inventory = sorted((c["id"], c["color"], c["special"]) for row in state["board"] for c in row)
    result = apply_action(state, {"kind": "shuffle"}, level)
    assert result["accepted"]
    assert result["state"]["score"] == 0
    assert result["state"]["movesLeft"] == level["moves"]
    assert result["state"]["blockers"] == state["blockers"]
    assert before_inventory == sorted((c["id"], c["color"], c["special"]) for row in result["state"]["board"] for c in row)
    assert_pristine(result["state"])
    assert not apply_action(result["state"], {"kind": "shuffle"}, level)["accepted"]


def test_automatic_shuffle_repairs_a_dead_board_without_spending_shuffle_power():
    level = endless_level()
    state = create_game(level, 1)
    for r in range(8):
        for c in range(8):
            state["board"][r][c]["color"] = (r * 2 + c) % 5
    assert find_matches(state["board"]) == []
    assert find_valid_moves(state["board"]) == []
    result = apply_action(state, {"kind": "extra"}, level)
    assert any(frame["kind"] == "shuffle" for frame in result["frames"])
    assert result["state"]["powers"]["shuffle"] == 1
    assert_pristine(result["state"])


@pytest.mark.parametrize("level", LEVELS, ids=lambda level: f"level-{level['id']}")
def test_full_real_playthrough_always_reaches_a_clean_terminal_result(level):
    state = create_game(level, 700 + level["id"])
    for _ in range(level["moves"]):
        if state["status"] != "playing":
            break
        result = swap_first(state, level)
        assert result["accepted"]
        state = result["state"]
        assert_pristine(state)
    assert state["status"] in ("won", "lost")
    if state["status"] == "won":
        assert state["score"] >= level["target"]
        assert all(state["collected"][goal["color"]] >= goal["count"] for goal in level["collections"])
        assert sum(map(sum, state["blockers"])) == 0


@pytest.mark.parametrize("fixture", WIN_FIXTURES, ids=lambda fixture: f"level-{fixture['levelId']}-actual-win")
def test_each_of_twenty_levels_has_a_reproducible_legal_winning_solution(fixture):
    level = LEVELS[fixture["levelId"] - 1]
    state = create_game(level, fixture["seed"])
    for action in fixture["actions"]:
        result = apply_action(state, action, level)
        assert result["accepted"], result.get("message")
        state = result["state"]
    assert state["status"] == "won"
    assert state["score"] == fixture["score"]
    assert state["movesLeft"] == fixture["movesLeft"]
    assert state["score"] >= level["target"]
    assert all(state["collected"][goal["color"]] >= goal["count"] for goal in level["collections"])
    assert sum(map(sum, state["blockers"])) == 0
    assert_pristine(state)

