"""Reproducible design check: search legal moves and save real winning traces.

This deliberately uses the seeded simulator to score candidate moves. It is a
development solver, not a player hint system, game cheat or claim of win rates.
Run from the project root: python tests/backend/generate_win_fixtures.py
The ordinary test suite replays the saved actions and verifies the wins.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from backend.app.engine import apply_action, create_game, find_valid_moves  # noqa: E402


def utility(before, after, level):
    if after["status"] == "won":
        return 1_000_000 + after["movesLeft"]
    score_gain = min(level["target"], after["score"]) - min(level["target"], before["score"])
    collection_gain = sum(
        min(goal["count"], after["collected"][goal["color"]]) - min(goal["count"], before["collected"][goal["color"]])
        for goal in level["collections"]
    )
    frosting_gain = sum(map(sum, before["blockers"])) - sum(map(sum, after["blockers"]))

    def specials(state):
        return sum(7 if candy["special"] == "color" else 3 if candy["special"] != "none" else 0
                   for row in state["board"] for candy in row)

    return score_gain / 180 + collection_gain * 2 + frosting_gain * 12 + specials(after) - specials(before)


def solve(level, seed):
    state = create_game(level, seed)
    actions = []
    for _ in range(120):
        if state["status"] == "won":
            return {"levelId": level["id"], "seed": seed, "actions": actions, "score": state["score"], "movesLeft": state["movesLeft"]}
        if state["status"] == "lost":
            if state["powers"]["extra"]:
                action = {"kind": "extra"}
                state = apply_action(state, action, level)["state"]
                actions.append(action)
                continue
            return None
        candidates = []
        for move in find_valid_moves(state["board"]):
            action = {"kind": "swap", **move}
            result = apply_action(state, action, level)
            candidates.append((utility(state, result["state"], level), action, result["state"]))
        best = max(candidates, key=lambda item: item[0])
        remaining_frosting = sum(map(sum, state["blockers"]))
        if state["powers"]["hammer"] and (state["movesLeft"] <= 2 or remaining_frosting <= 2):
            for r in range(level["rows"]):
                for c in range(level["cols"]):
                    action = {"kind": "hammer", "at": [r, c]}
                    result = apply_action(state, action, level)
                    candidate = (utility(state, result["state"], level) - 0.1, action, result["state"])
                    if candidate[0] > best[0]:
                        best = candidate
        if best[0] < 2 and state["powers"]["shuffle"]:
            action = {"kind": "shuffle"}
            state = apply_action(state, action, level)["state"]
            actions.append(action)
            continue
        _, action, state = best
        actions.append(action)
    return None


def main():
    levels = json.loads((ROOT / "shared/levels.json").read_text())
    fixtures = []
    for level in levels:
        for offset in range(20):
            fixture = solve(level, 31415 + level["id"] + offset * 1000)
            if fixture:
                fixtures.append(fixture)
                print(f"Level {level['id']:2}: won, seed={fixture['seed']}, score={fixture['score']}, movesLeft={fixture['movesLeft']}, actions={len(fixture['actions'])}", flush=True)
                break
        else:
            raise RuntimeError(f"No win found for level {level['id']}; review its design.")
    destination = ROOT / "tests/fixtures/level_wins.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(fixtures, ensure_ascii=False, indent=2) + "\n")
    print(f"Saved {len(fixtures)} verified win fixtures to {destination.relative_to(ROOT)}", flush=True)


if __name__ == "__main__":
    main()
