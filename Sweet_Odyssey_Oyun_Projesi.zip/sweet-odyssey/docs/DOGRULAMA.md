# Sweet Odyssey — Doğrulama raporu

Tarih: **19 Ekim 2026**. Bu rapor çalıştırılan kontrolleri ve sınırlarını kaydeder; planlanan testleri geçmiş gibi göstermez.

## Çalıştırılan kontroller

| Kontrol | Sonuç |
| --- | --- |
| Python: oyun motoru + API + veritabanı + başlatıcı + geçişler | **119 geçti**; varsayılan olarak 1 isteğe bağlı kurulum testi atlandı |
| İsteğe bağlı gerçek ilk kurulum / ikinci başlatma | **Ayrıca çalıştırıldı ve geçti** |
| Vitest: oyun motoru, diller arası eşitlik ve istemci sınır doğrulaması | **94 geçti** |
| Playwright: gerçek Chromium uçtan uca akışları | **7 geçti** |
| TypeScript strict tür kontrolü | **Geçti** |
| ESLint | **Geçti** |
| Vite ön yüz derlemesi | **Geçti** |
| Python paket tutarlılığı (`pip check`) | **Geçti** |

Python paketinin 119 testi, 100 motor testi ve 19 backend/başlatıcı/geçiş testinden oluşur. Vitest paketinde 87 motor testi ve 7 istemci sınır testi vardır. Python testinde Starlette'in `httpx` test adaptörüne ilişkin bir kullanımdan kaldırma uyarısı çıktı; test başarısızlığı oluşmadı. Normal oyun çalışma yolunda bu test adaptörü kullanılmaz.

### Ortam

- Linux, Python **3.12.14**, Node.js **24.19.0**.
- Chromium **141.0.7390.37**, Playwright **1.56.1**.
- SQLite veritabanı; test başına veya test oturumu başına ayrı kayıt alanı.
- Masaüstü: **1440 × 1000**; mobil: **390 × 844**.
- Mobil testte gerçek `touchStart → touchMove → touchEnd` olaylarıyla kaydırma uygulandı.

## Motor kapsamı

Başlangıç tahtalarının eşleşmesiz olması ve en az bir geçerli hamle içermesi 20 bölümde, bölüm başına 20 farklı tohumla kontrol edildi. Her bölümde gerçek hamlelerle biten denemeler çalıştırıldı.

Kontroller; yatay/dikey eşleşmeler, geçersiz/çapraz takaslar, veri durumunun değişmezliği, yerçekimi, yeni şeker üretimi, zincirleme patlamalar, tam puan hesabı, renk toplama, krema, özel şeker oluşturma/tetikleme, özel şeker kombinasyonları, karıştırma, güçlerin birer kullanım sınırı ve son hamlede kazanma önceliğini kapsar.

Python ile TypeScript karşılaştırması yalnızca son puanı karşılaştırmaz. **Her son durum ve her animasyon karesi** karşılaştırılır. 20 karışık hamle izi, üç özel şeker kombinasyonu ve 20 bölümün tam kazanma izleri aynı sonucu verdi.

### Her bölüm için gerçek kazanma örneği

Aşağıdaki örneklerde oyun kuralları değiştirilmedi. Geliştirme çözücüsü geçerli hamleleri ve izin verilen güçleri değerlendirerek kazanan yollar buldu. `tests/fixtures/level_wins.json` dosyasında tohumlar ve bütün eylemler bulunur; her iki motor da bunları tekrar oynayarak doğrular.

**Bu tablo, belirtilen başlangıçlarda kazanmaya ulaşılabildiğini gösterir. İnsan oyuncuların genel kazanma oranını veya tüm rastgele başlangıçların zorluğunu ölçmez.** Eylem sayısı güç kullanımını da içerir; bir güç her zaman bir normal hamle tüketmez.

| Bölüm | Ad | Tohum | Eylem sayısı | Son puan | Yıldız |
| --- | --- | --- | --- | --- | --- |
| 1 | İlk Lokma | 31416 | 1 | 4320 | 3 |
| 2 | Ahududu Dalgası | 31417 | 2 | 12040 | 3 |
| 3 | Altın Kumlar | 31418 | 3 | 12460 | 3 |
| 4 | Krema İskelesi | 31419 | 1 | 9540 | 3 |
| 5 | Turkuaz Feneri | 31420 | 4 | 8100 | 3 |
| 6 | Lavanta Geçidi | 31421 | 7 | 10300 | 3 |
| 7 | İkiz Meyveler | 31422 | 18 | 13100 | 3 |
| 8 | Kat Kat Lokum | 31423 | 6 | 7160 | 2 |
| 9 | Antep Köprüsü | 31424 | 10 | 17840 | 3 |
| 10 | Korunun Kalbi | 31425 | 16 | 13980 | 3 |
| 11 | Mercan Kapısı | 31426 | 12 | 27780 | 3 |
| 12 | Mor Bulutlar | 31427 | 15 | 18040 | 3 |
| 13 | Karamel Merdiveni | 31428 | 15 | 19960 | 3 |
| 14 | Kristal Pusula | 31429 | 12 | 15440 | 3 |
| 15 | Zirve Pikniği | 31430 | 10 | 18800 | 3 |
| 16 | Gece Bahçesi | 31431 | 17 | 21420 | 3 |
| 17 | Yıldızlı Avlu | 31432 | 12 | 22120 | 3 |
| 18 | Gökkuşağı Salonu | 31433 | 8 | 23880 | 3 |
| 19 | Tatlı Takımyıldız | 31434 | 23 | 33880 | 3 |
| 20 | Odysseia Tacı | 31435 | 11 | 29360 | 3 |

## Gerçek tarayıcı senaryoları

1. **Karşılama → harita → öğretici → gerçek pointer takası → geçersiz takas → duraklat → güç kullan → kazan → sonraki bölüm → yenileme.** Kazanımın kaydedildiği ve bölüm kilidinin korunduğu doğrulandı. Öğretici sonrası sayfanın kaydırma kilidinin kalktığı ve harita üst çubuğunun görünür kaldığı da kontrol edildi.
2. **Ayarlar ve oyuncu adı.** Ad ve ses tercihi değiştirildi; sayfa yenilendikten sonra aynı değerler görüldü.
3. **Mobil tahta ve çekiç.** Yatay taşma olmadığı, tahtanın ekrana sığdığı, duraklatma hedefinin en az 44 px olduğu ve çekicin bir kullanım sonrası devre dışı kaldığı doğrulandı.
4. **Kayıt kesintisi.** Sonuç kaydı için kontrollü 503 hatası üretildi. Arayüz kaydı tamamlandı diye göstermedi; sonraki bölüm onay gelene kadar kapalı kaldı. Tekrar denemede gerçek API kaydı ve kilit açılması başarılı oldu.
5. **Yerel mod.** API bağlantısı kontrollü kesildi. Yerel kayıt etiketi görüldü; gerçek oynanışla kazanılan bölümün tarayıcı kaydı yenileme sonrasında korundu.
6. **Gerçek kaybetme ve yeniden deneme.** Önce ilk üç bölüm geçerli motor hamleleriyle kazanılıp sunucuda doğrulandı. Asıl dördüncü bölümde krema hedefi tamamlanmadan hamleler bitti. +5 hamleyle aynı deneme sürdürüldü, tekrar kaybedildi ve yeniden denemede başlangıç puanı/hamleleri/güçleri doğru sıfırlandı. Kaybetme yeni bölüm açmadı.
7. **Mobil dokunarak kaydırma.** Dokunma destekli mobil tarayıcı bağlamında komşu iki şeker kaydırıldı. Hamle bir azaldı ve gerçek eşleşme puanı oluştu.

Bu testler test derlemesindeki gözlem arayüzünü kullanır. Oyun durumuna keyfî puan, kazanma veya kilit açma atayan bir yöntem yoktur. Dağıtıma normal üretim derlemesi eklendi; test denetim kancasının bu derlemede bulunmadığı hem dosyalarda hem çalışan tarayıcıda kontrol edildi. Bu normal derlemede ayrıca gerçek pointer takası yapıldı; hamle 22’den 21’e indi ve eşleşme puanı oluştu.

## API ve kayıt kapsamı

Gerçek ilk bölümden oluşturulan hamle listesi sunucuda tekrar oynandı. Sahte puan alanları, bitmemiş veya geçersiz hamleli sonuçlar, başka oyuncunun denemesine erişim ve kilitli bölüm isteği reddedildi. Aynı sonucu tekrar gönderme, eşzamanlı aynı sonuç gönderimleri, kaybetmede ilerlemenin korunması, uygulama yeniden açıldığında kayıtların kalması ve bölüm tanımının deneme başlangıcındaki görüntüsünün kullanılması doğrulandı. İstek boyutu ve CORS kapsamı da test edildi.

Alembic geçişi hem boş SQLite veritabanında hem uygulamanın otomatik oluşturduğu ilk SQLite şeması üzerinde çalıştırıldı.

## Kolay başlatma

Temiz bir geçici klasörde `app.py` çalıştırılarak gerçekten yeni `.venv` oluşturuldu ve sabitlenmiş Python paketleri indirildi. HTTP sağlık kontrolü, 20 bölümün sunulması, SQLite oluşturma ve oyuncu kaydı doğrulandı. Ardından aynı bağlantı noktasında ikinci kez çalıştırıldı: paket kurulumu tekrarlanmadı, aynı oyuncu kaydına erişildi.

Bu ilk-kurulum testi standart Pytest komutunda özellikle atlanır çünkü ağdan paket indirir. Bu teslim sırasında ayrıca etkinleştirilerek çalıştırıldı. `backend/tests/test_launcher_smoke.py` dosyası yeniden çalıştırma komutunu içerir.

Derlenmiş gerçek oyun ayrıca kökteki `app.py --no-browser --port 8000` başlatıcısından açılarak görsel olarak incelendi. İncelenen başlangıç yerleşiminde masaüstü tahta 540 × 540 px, mobil tahta 342 × 342 px idi. İki görünümde de yatay taşma veya JavaScript sayfa hatası görülmedi.

## Doğrulama sınırları

- **Windows üzerinde yerel çalıştırma yapılmadı.** Windows `.bat` başlatıcısı sağlandı, Python 3.11+ ve Windows AMD64 paket belirteçleri kontrol edildi; canlı ilk-kurulum testi Linux'ta yapıldı.
- **Canlı PostgreSQL sunucusu çalıştırılmadı.** Bağlantı, sürücü, Docker Compose ve Alembic yolu hazırdır; veritabanı davranışı bu ortamda SQLite ile doğrulandı.
- Gerçek iOS/Safari veya fiziksel Android cihazında test yapılmadı. Mobil doğrulama Chromium ve dokunma emülasyonuyla yapıldı.
- Tarayıcı testleri ses ayarlarının davranışını doğrular; farklı hoparlörlerde ses kalitesi dinleme testi yapılmadı.
- Yük / ölçek testi, rekabetçi anti-bot sistemi, hesap kurtarma ve cihazlar arası senkronizasyon bu yerel sürümün kapsamı dışındadır.
- GitHub Actions dosyası hazırlandı; bir uzak GitHub iş akışı çalıştırılmadı. Çevrimiçi yayın yapılmadı.
