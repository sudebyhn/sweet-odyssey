"""Generate Sweet Odyssey's original, self-contained SVG art. Python stdlib only."""
from pathlib import Path
import random

DEST = Path(__file__).resolve().parents[1] / "frontend" / "public" / "assets"
DEST.mkdir(parents=True, exist_ok=True)

palettes = [
    ("#ffbbcf", "#fa608e", "#a7275d", "#591939"),
    ("#a7fff0", "#4ccec9", "#147d91", "#184953"),
    ("#fff6b9", "#ffc558", "#d87831", "#723c26"),
    ("#e8c8ff", "#ad81e5", "#6643a7", "#382256"),
    ("#ffd5a6", "#fa896c", "#c1465d", "#662b43"),
    ("#e5ffc7", "#99d786", "#429d80", "#245b51"),
]
shapes = [
    'M60 103C46 94 16 71 16 43C16 20 43 13 60 33C77 13 104 20 104 43C104 71 74 94 60 103Z',
    'M48 17Q60 9 72 17L101 46Q110 59 101 72L73 102Q60 111 47 102L19 72Q10 59 19 46Z',
    'M60 12C77 28 97 48 99 68C102 91 84 105 61 105C38 105 19 92 21 70C23 48 43 29 60 12Z',
    'M20 43C21 23 39 14 60 14C82 14 100 23 101 44L102 74C100 94 82 105 60 105C37 105 18 93 18 74Z',
    'M37 17H83Q102 17 102 38V82Q102 103 82 103H38Q17 103 17 82V38Q17 17 37 17Z',
    'M60 12C69 12 70 33 79 36C87 39 105 33 108 42C111 51 92 60 92 69C92 78 103 92 95 99C87 105 72 91 62 93C53 95 42 110 34 104C26 98 31 80 27 73C23 66 7 61 10 51C13 41 32 45 38 38C45 30 49 12 60 12Z',
]
details = [
    '<path d="M28 45C28 29 42 28 51 36" fill="none" stroke="#fff9ef" stroke-width="7" stroke-linecap="round" opacity=".62"/><path d="M86 65Q77 81 66 87" fill="none" stroke="#ffb5d0" stroke-width="3" stroke-linecap="round" opacity=".65"/>',
    '<path d="M59 23L29 55L59 98L89 59Z" fill="#e9fff7" opacity=".14"/><path d="M29 55H89M59 23V98" stroke="#d4fff3" stroke-width="2" opacity=".28"/><path d="M32 45L49 27" stroke="#fff" stroke-width="6" stroke-linecap="round" opacity=".6"/>',
    '<path d="M48 35Q30 57 33 71" fill="none" stroke="#ffffef" stroke-width="7" stroke-linecap="round" opacity=".65"/><path d="M78 71Q78 88 61 93" fill="none" stroke="#ffe2a0" stroke-width="3" stroke-linecap="round" opacity=".6"/>',
    '<path d="M19 65Q58 78 101 65" fill="none" stroke="#f4dcff" stroke-width="8" opacity=".65"/><path d="M20 73Q60 86 101 73" fill="none" stroke="#512d7c" stroke-width="4" opacity=".38"/><ellipse cx="45" cy="31" rx="18" ry="7" fill="#fff" opacity=".5" transform="rotate(-18 45 31)"/>',
    '<path d="M33 42Q33 29 47 29H67" fill="none" stroke="#fff5dc" stroke-width="7" stroke-linecap="round" opacity=".62"/><path d="M50 59Q60 43 74 58Q84 75 63 81Q49 86 40 76" fill="none" stroke="#ffcbaa" stroke-width="5" stroke-linecap="round" opacity=".6"/>',
    '<path d="M57 27Q52 47 34 51" fill="none" stroke="#fffde8" stroke-width="6" stroke-linecap="round" opacity=".65"/><path d="M73 79L83 88" fill="none" stroke="#d5ffd6" stroke-width="4" stroke-linecap="round" opacity=".7"/>',
]
for i, (p, shape, detail) in enumerate(zip(palettes, shapes, details)):
    light, main, dark, outline = p
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120">
<defs><linearGradient id="c" x1=".25" y1="0" x2=".65" y2="1" gradientUnits="objectBoundingBox"><stop stop-color="{light}"/><stop offset=".38" stop-color="{main}"/><stop offset="1" stop-color="{dark}"/></linearGradient><linearGradient id="shine" x2="0" y2="1"><stop stop-color="#fff" stop-opacity=".4"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient><clipPath id="shape"><path d="{shape}"/></clipPath></defs>
<ellipse cx="60" cy="108" rx="36" ry="6" fill="#130b28" opacity=".28"/><path d="{shape}" transform="translate(0 3)" fill="{outline}" opacity=".8"/>
<path d="{shape}" fill="url(#c)" stroke="{outline}" stroke-width="2" stroke-linejoin="round"/>
<g clip-path="url(#shape)"><ellipse cx="48" cy="22" rx="53" ry="32" fill="url(#shine)"/><path d="M9 90Q60 119 112 82" stroke="{light}" stroke-width="3" fill="none" opacity=".24"/>{detail}</g></svg>'''
    (DEST / f"candy-{i}.svg").write_text(svg, encoding="utf-8")

(DEST / "logo-mark.svg").write_text('''<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><defs><linearGradient id="g" x2=".5" y2="1"><stop stop-color="#fff1b0"/><stop offset="1" stop-color="#db9758"/></linearGradient></defs><rect width="96" height="96" rx="26" fill="#342342"/><path d="M48 10Q51 39 80 48Q51 54 48 85Q42 55 14 48Q42 39 48 10Z" fill="url(#g)"/><path d="M48 29L58 48L48 67L38 48Z" fill="#fff6d9"/><circle cx="76" cy="20" r="3" fill="#f294b4"/></svg>''', encoding="utf-8")

defs = '''<defs>
<linearGradient id="sky" x2=".7" y2="1"><stop stop-color="#21192f"/><stop offset=".55" stop-color="#382343"/><stop offset="1" stop-color="#583454"/></linearGradient>
<radialGradient id="glow"><stop stop-color="#e88997" stop-opacity=".34"/><stop offset="1" stop-color="#e88997" stop-opacity="0"/></radialGradient>
<linearGradient id="sun" x2=".4" y2="1"><stop stop-color="#fbd6ac"/><stop offset="1" stop-color="#e39fa5"/></linearGradient>
<linearGradient id="land" x2=".2" y2="1"><stop stop-color="#aa6f8f"/><stop offset="1" stop-color="#543952"/></linearGradient>
<linearGradient id="grass" x2=".6" y2="1"><stop stop-color="#adc7af"/><stop offset="1" stop-color="#669d92"/></linearGradient>
<linearGradient id="rock" x2=".8" y2="1"><stop stop-color="#916883"/><stop offset="1" stop-color="#3f2e50"/></linearGradient>
<linearGradient id="pink" x2=".4" y2="1"><stop stop-color="#ffd0cd"/><stop offset=".5" stop-color="#e990a8"/><stop offset="1" stop-color="#a15583"/></linearGradient>
<linearGradient id="mint" x2=".4" y2="1"><stop stop-color="#d6f2d1"/><stop offset="1" stop-color="#78aeb0"/></linearGradient>
<linearGradient id="water" x2="1" y2="1"><stop stop-color="#b8c5bc"/><stop offset=".45" stop-color="#7d969f"/><stop offset="1" stop-color="#46536d" stop-opacity="0"/></linearGradient>
<linearGradient id="gold" x2=".5" y2="1"><stop stop-color="#ffe9b8"/><stop offset="1" stop-color="#d7a279"/></linearGradient>
<filter id="soft"><feGaussianBlur stdDeviation="12"/></filter>
</defs>'''
island = '''<g>
<ellipse cx="0" cy="131" rx="192" ry="26" fill="#160e2b" opacity=".3" filter="url(#soft)"/>
<path d="M-204 10L-160 76L-116 83L-84 114L-31 134L18 119L60 141L119 97L162 80L209 13Z" fill="url(#rock)"/>
<path d="M-159 25L-116 83L-84 114L-75 39M-14 45L18 119L60 141L79 43M138 27L119 97L162 80L175 25" fill="#3d3050" opacity=".36"/>
<ellipse rx="211" ry="59" fill="url(#land)"/>
<ellipse cy="-9" rx="202" ry="52" fill="url(#grass)"/>
<path d="M-190 -10Q-91 33 8 13Q114 -15 200 -8" fill="none" stroke="#cfe1bc" stroke-width="3" opacity=".6"/>
<path d="M-86 -52C-129 -25 -54 -16 -3 -12C62 -6 59 16 51 34C41 70 17 114 19 164C22 229 -33 286 -23 325" fill="none" stroke="url(#water)" stroke-width="33"/>
<path d="M-86 -52C-129 -25 -54 -16 -3 -12C62 -6 59 16 51 34" fill="none" stroke="#e6dfc0" stroke-width="20"/>
<path d="M-86 -52C-129 -25 -54 -16 -3 -12C62 -6 59 16 51 34" fill="none" stroke="#ccac94" stroke-width="2" stroke-dasharray="2 10"/>
<g transform="translate(97 -55)"><path d="M-8 17L-5 -155H7L9 17" fill="#dfc9b7"/><path d="M-4 17L2 -155" stroke="#fff0cf" stroke-width="3"/>
<circle cy="-157" r="57" fill="#563958" opacity=".3"/><circle cy="-162" r="57" fill="url(#pink)"/><circle cy="-162" r="45" fill="none" stroke="#ffe0cc" stroke-width="7" opacity=".8"/>
<path d="M0 -162C28 -195 45 -155 24 -140C-7 -117 -40 -159 -17 -183C1 -202 27 -184 13 -167C2 -154 -14 -163 -3 -174" fill="none" stroke="#ffdfcc" stroke-width="9" stroke-linecap="round"/>
<path d="M-36 -190Q-28 -203 -11 -209" fill="none" stroke="#fff5de" stroke-width="5" stroke-linecap="round" opacity=".7"/></g>
<g transform="translate(-124 -53)"><path d="M0 20V-75" stroke="#7d5067" stroke-width="10" stroke-linecap="round"/><path d="M-34 -67Q-43 -96 -13 -110Q-3 -141 22 -112Q51 -118 48 -91Q70 -68 41 -52Q39 -26 11 -39Q-13 -27 -24 -48Q-53 -43 -34 -67" fill="url(#mint)"/><path d="M0 -71Q12 -98 26 -102" fill="none" stroke="#eef4da" stroke-width="3" opacity=".65"/></g>
<g transform="translate(149 -2)"><path d="M-23 -2L-17 -44L0 -71L15 -39L25 3Z" fill="url(#pink)"/><path d="M0 -71L-3 3L15 -39Z" fill="#ffe1d0" opacity=".32"/><path d="M15 -2L22 -35L34 -50L46 -17L47 4Z" fill="url(#gold)"/></g>
<g transform="translate(-158 -7)"><ellipse cy="-14" rx="24" ry="19" fill="url(#pink)"/><ellipse cx="22" cy="-4" rx="20" ry="14" fill="url(#pink)"/><path d="M-17 -20L-9 -25M12 -8L17 -12" stroke="#ffe8cf" stroke-width="3" stroke-linecap="round"/></g>
<g fill="#f7e9bc"><ellipse cx="-29" cy="-35" rx="6" ry="3"/><ellipse cx="-53" cy="12" rx="6" ry="3"/><ellipse cx="116" cy="21" rx="5" ry="3"/></g>
</g>'''
(DEST / "island.svg").write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="560" height="520" viewBox="-250 -290 500 610">{defs}{island}</svg>', encoding="utf-8")
rng = random.Random(89)
stars = ''.join(f'<circle cx="{rng.randint(50,1390)}" cy="{rng.randint(45,690)}" r="{rng.choice([1,1,1.5,2])}" fill="#ffe5b6" opacity="{rng.uniform(.12,.55):.2f}"/>' for _ in range(76))
world = f'''<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="1000" viewBox="0 0 1440 1000">{defs}
<rect width="1440" height="1000" fill="url(#sky)"/>
<ellipse cx="1035" cy="455" rx="590" ry="485" fill="url(#glow)"/>{stars}
<circle cx="1040" cy="342" r="186" fill="url(#sun)" opacity=".13"/><circle cx="1040" cy="342" r="148" fill="url(#sun)" opacity=".25"/>
<path d="M759 250Q963 63 1252 244M802 615Q1125 658 1312 389" stroke="#c992ae" stroke-width="1" fill="none" opacity=".2"/>
<g fill="#ae849c" opacity=".1"><path d="M970 563L1070 242L1170 563Z"/><path d="M1132 614L1252 348L1379 614Z"/><path d="M701 691L806 455L927 691Z"/></g>
<g fill="#b695aa" opacity=".09"><ellipse cx="876" cy="396" rx="100" ry="15"/><ellipse cx="917" cy="383" rx="52" ry="26"/><ellipse cx="1280" cy="189" rx="139" ry="14"/><ellipse cx="1240" cy="174" rx="61" ry="29"/></g>
<path d="M0 819Q108 681 273 815Q481 865 606 774Q778 662 947 766Q1174 682 1440 750V1000H0Z" fill="#523750" opacity=".44"/>
<path d="M0 877Q218 787 430 911Q669 817 843 919Q1102 791 1440 867V1000H0Z" fill="#2c2239" opacity=".62"/>
<g transform="translate(1030 592) scale(1.22)">{island}</g>
<g transform="translate(697 786) scale(.47)" opacity=".75">{island}</g>
<g transform="translate(1331 762) scale(.4)" opacity=".62">{island}</g>
<g transform="translate(263 955) scale(.55)" opacity=".28">{island}</g>
<g fill="#fae4b7"><path d="M835 236L838 249L851 252L838 255L835 268L832 255L819 252L832 249Z" opacity=".7"/><path d="M1253 405L1256 415L1267 418L1256 421L1253 432L1250 421L1239 418L1250 415Z" opacity=".48"/></g>
<path d="M0 988Q417 954 722 993Q1014 1052 1440 983V1000H0Z" fill="#21192f"/>
</svg>'''
(DEST / "world.svg").write_text(world, encoding="utf-8")
print(f"Generated {len(list(DEST.glob('*.svg')))} original SVG assets in {DEST}")
