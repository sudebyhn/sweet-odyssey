"""Reproducibly package source + prebuilt game, excluding secrets and player data."""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {".venv", "node_modules", ".git", "__pycache__", ".pytest_cache", ".ruff_cache", "test-results", "playwright-report", "qa", ".cache"}
SKIP_NAMES = {".env", ".DS_Store", "CONTRACT.md"}


def included(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    return (
        path.is_file()
        and not set(relative.parts).intersection(SKIP_DIRS)
        and path.name not in SKIP_NAMES
        and path.suffix not in {".db", ".sqlite", ".sqlite3", ".pyc", ".log", ".zip"}
        and not path.name.endswith(("-wal", "-shm", "-journal"))
        and not path.name.startswith(".sweet-")
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT.parent / "Sweet_Odyssey_Oyun_Projesi.zip")
    args = parser.parse_args()
    if not (ROOT / "frontend" / "dist" / "index.html").is_file():
        parser.error("Hazır oyun yok. Önce frontend klasöründe npm run build çalıştırın.")
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    files = [p for p in sorted(ROOT.rglob("*")) if included(p)]
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            info = zipfile.ZipInfo("sweet-odyssey/" + path.relative_to(ROOT).as_posix(), (2026, 10, 19, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o755 if path.suffix == ".sh" else 0o644) << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(output) as archive:
        corrupt = archive.testzip()
        if corrupt:
            raise RuntimeError(f"ZIP doğrulaması başarısız: {corrupt}")
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    print(f"ZIP: {output}\nFiles: {len(files)}\nBytes: {output.stat().st_size}\nSHA256: {digest}")


if __name__ == "__main__":
    main()
